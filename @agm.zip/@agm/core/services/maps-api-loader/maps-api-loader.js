import { Injectable } from '@angular/core';
var MapsAPILoader = /** @class */ (function () {
    function MapsAPILoader() {
    }
    MapsAPILoader.decorators = [
        { type: Injectable },
    ];
    return MapsAPILoader;
}());
export { MapsAPILoader };
//# sourceMappingURL=maps-api-loader.js.map