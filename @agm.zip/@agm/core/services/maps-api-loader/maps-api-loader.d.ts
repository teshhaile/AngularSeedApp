export declare abstract class MapsAPILoader {
    abstract load(): Promise<void>;
}
