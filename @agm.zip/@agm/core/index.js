export * from './directives';
export * from './services';
export { AgmCoreModule } from './core.module';
//# sourceMappingURL=index.js.map