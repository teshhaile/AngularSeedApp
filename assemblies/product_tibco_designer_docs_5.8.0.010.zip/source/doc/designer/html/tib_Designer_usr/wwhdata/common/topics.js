function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="aboutdesigner.welcome.helpurl")C="designer.5.03.htm#1885340";
if(P=="ae.unknownfileres.helpurl")C="designer.5.05.htm#1890542";
if(P=="archive.builder.folder.helpurl")C="designer.5.41.htm";
if(P=="adapter.archive.resource.helpurl")C="designer.5.44.htm";
if(P=="process.archive.resource.helpurl")C="designer.5.45.htm";
if(P=="shared.archive.resource.helpurl")C="designer.5.46.htm";
if(P=="ae.ssl.trustedcert.helpurl")C="designer.5.54.htm#1947394";
return C;
}
