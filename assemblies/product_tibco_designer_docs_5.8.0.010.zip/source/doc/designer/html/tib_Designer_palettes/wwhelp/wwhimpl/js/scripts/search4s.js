// Copyright (c) 2000-2012 Quadralay Corporation.  All rights reserved.
//

// Search complete
//
WWHFrame.WWHSearch.fSearchWordsComplete();
