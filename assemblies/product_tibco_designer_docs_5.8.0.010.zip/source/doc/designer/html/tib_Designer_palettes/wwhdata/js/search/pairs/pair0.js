function FileData_Pairs(x)
{
x.t("designer","tibco");
x.t("designer","palette");
x.t("2012","tibco");
x.t("software","release");
x.t("software","tibco");
x.t("release","5.8.0");
x.t("reference","software");
x.t("tibco","designer");
x.t("tibco","software");
x.t("5.8.0","november");
x.t("november","2012");
x.t("palette","reference");
}
