function  WWHBookData_Title()
{
  return "Palette Reference";
}
