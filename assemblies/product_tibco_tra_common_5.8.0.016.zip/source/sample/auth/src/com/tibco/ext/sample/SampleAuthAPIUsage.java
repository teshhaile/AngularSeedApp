package com.tibco.ext.sample;

//(c) Copyright 2009, TIBCO Software Inc.  All rights reserved.
//LEGAL NOTICE:  This source code is provided to specific authorized end
//users pursuant to a separate license agreement.  You MAY NOT use this
//source code if you do not have a separate license from TIBCO Software
//Inc.  Except as expressly set forth in such license agreement, this
//source code, or any portion thereof, may not be used, modified,
//reproduced, transmitted, or distributed in any form or by any means,
//electronic or mechanical, without written permission from  TIBCO
//Software Inc.

import com.tibco.ext.utils.AuthenticationSubject;
import com.tibco.ext.model.authorization.User;
import com.tibco.ext.model.authorization.*;
import com.tibco.ext.model.common.EntityNotFoundException;
import com.tibco.ext.utils.AuthUtils;

import java.util.*;

/**
 * This is a collection of code snippets that illustrate the usage patterns for
 * the exposed TIBCO Administrator Authentication API.
 * <p>
 * There is a main method in this sample that runs each of these snippets one by one.
 * In order to get a meaningful output from the main method, you will need to create
 * few sample roles and users in your Domain as follows:
 * <UL>
 *   <LI>Create a TIBCO Domain that integrates with a test LDAP.</LI>
 *   <LI>The few test users such as nu1, nu2, nu3 and nu4 (with same password as username).</LI>
 *   <LI>Create few standard roles in Domain with few members, as NR1, NR3, NR4, NR5 directly under the system role "Authenticated Users".</LI>
 *   <LI>Create a standard role "NR2" under "NR1", with few members.</LI> 
 *   <LI>The test LDAP will need to have a role LR1 with few members.</LI>
 * </UL>
 * <p>
 * You will also need to change the "user" and "password" for the admin (super user),
 * specified in the main method. 
 */
public class SampleAuthAPIUsage {

    /** Search users */
    public static void searchUsers(String searchString) {
        UserFactory userFactory = UserFactory.getFactory();
        Iterator iter = userFactory.searchUserNames(searchString, 0);
        while (iter.hasNext()) {
            String userName = (String) iter.next();
            User user = userFactory.getUserByName(userName);
            if (user == null) {
                System.out.println("User ("+userName+") NOT found");
                continue;
            }
        	int userSource = UserFactory.USER_SOURCE_LOCAL;
        	try {
        		userSource = userFactory.getUserSource(user);
        	} catch (EntityNotFoundException e) { /* Ignore*/ }
            System.out.println("User ("+userName+") found. User source is " + (userSource == UserFactory.USER_SOURCE_LOCAL? "Local": "Corp LDAP"));
        }
        
    }

    /** Search Roles */
    public static void getRoles() {
        RoleFactory factory = RoleFactory.getFactory();
        Collection roles = factory.getRoles();

        Role superUsersRole = factory.getSuperUsersRole();
        String superUsersRolePath = (superUsersRole != null)? factory.getPath(superUsersRole): null;
        Role authenticatedUsersRole = factory.getAuthenticatedUsersRole();
        String authenticatedUsersRolePath = (authenticatedUsersRole != null)? factory.getPath(authenticatedUsersRole): null;
        Role guestsRole = factory.getGuestsRole();
        String guestsRolePath = (guestsRole != null)? factory.getPath(guestsRole): null;

        Iterator iter = roles.iterator();
        while (iter.hasNext()) {
            Role role = (Role) iter.next();
            RoleMembershipConfig membConfig = factory.getRoleMembershipConfig(role);
            String dispRoleType = null;
            if (factory.getPath(role).equals(superUsersRolePath)) {
                dispRoleType = "Super Users";
            } else if (factory.getPath(role).equals(authenticatedUsersRolePath)) {
                dispRoleType = "Authenticated Users";
            } else if (factory.getPath(role).equals(guestsRolePath)) {
                dispRoleType = "Guests";
            } else if (membConfig instanceof StandardRoleMembershipConfig) {
                dispRoleType = "Standard";
            } else if (membConfig instanceof GroupSyncRoleMembershipConfig) {
                dispRoleType = "Group Synchronzed";
            } else if (membConfig instanceof CustomRoleMembershipConfig) {
                dispRoleType = "Custom - " + ((CustomRoleMembershipConfig) membConfig).getCustomRoleMembershipType();
            } else {
                dispRoleType = "Unknown";
            }
            System.out.println("Role: "+role.getName()+ "; type: "+dispRoleType);
        }
    }

    public static void retrieveUser(String username) {
    	UserFactory userFactory = UserFactory.getFactory();
    	User user = userFactory.getUserByName(username);
    	if (user == null) {
    		System.out.println("User ("+username+") not found");
    		return;
    	}
    	int userSource = UserFactory.USER_SOURCE_LOCAL;
    	try {
    		userSource = userFactory.getUserSource(user);
    	} catch (EntityNotFoundException e) { /* Ignore*/ }
        System.out.println("User ("+username+") found. User source is " + (userSource == UserFactory.USER_SOURCE_LOCAL? "Local": "Corp LDAP"));
    }
    
    public static void matchUserPassword(String username, String password) {
    	UserFactory userFactory = UserFactory.getFactory();
    	User user = userFactory.getUserByName(username);
    	if (user == null) {
    		System.out.println("User ("+username+") not found");
    		return;
    	}
    	boolean matched = false;
    	try {
    		matched = user.matchPassword(password.toCharArray());
    	} catch (Exception e) {
    		System.out.println("While matching password for User ("+username+"): " + e);
    		// e.printStackTrace();
    		return;
    	}
    	System.out.println("User ("+username+") password " + (matched? "": "NOT ") + "matched");
    }
    
    public static void getRoleByPath(String rolePath) {
        RoleFactory factory = RoleFactory.getFactory();
        Role role = factory.getRoleByPath(rolePath);
        System.out.println();
        if (role == null) {
            System.out.println("Role ("+rolePath+") not found");
            return;
        }

        System.out.println("Role ("+rolePath+") found");
        System.out.println("    Name                            ="+role.getName());
        System.out.println("    Path                            ="+factory.getPath(role));
        System.out.println("    Description                     ="+role.getDescription());
        System.out.println("    InheritFromChildRolesMembership ="+role.getInheritFromChildRolesMembership());

        RoleMembershipConfig roleMembershipConfig = factory.getRoleMembershipConfig(role);
        if (roleMembershipConfig instanceof StandardRoleMembershipConfig) {
            StandardRoleMembershipConfig stdMemb = (StandardRoleMembershipConfig)roleMembershipConfig;
            System.out.println("    User Members: " + stdMemb.getUserNames());

            System.out.print  ("    Role Members: ");
            Iterator iter = stdMemb.getRoles().iterator();
            boolean first = true;
            while (iter.hasNext()) {
                if (first) first = false;
                else System.out.print(", ");
                System.out.print(((Role)iter.next()).getName());
            }
            System.out.println();
        }
    }

    public static void isMember(String rolePath, AuthenticationSubject authSubject) {

        RoleFactory factory = RoleFactory.getFactory();
        Role role = factory.getRoleByPath(rolePath);

        boolean isMember = AuthUtils.instance().isMember(role, authSubject);
        System.out.println("User ("+authSubject.getUsername()+") is " + (isMember? "a": "not a") + " member of Role ("+rolePath+")");
    }

    public static void searchMembers(String rolePath) {

        RoleFactory factory = RoleFactory.getFactory();
        Role role = factory.getRoleByPath(rolePath);

        if (role != null) {
            Iterator iter = AuthUtils.instance().searchMembers(role, null, 0).iterator();
            System.out.println();
            System.out.println("Members of Role ("+rolePath+") are: ");
            System.out.print("    ");
            boolean first = true;
            while (iter.hasNext()) {
                if (first) first = false;
                else System.out.print(", ");
                System.out.print(iter.next());
            }
            System.out.println();
        } else {
            System.out.println("Could not find Role with path: " + rolePath);
        }
    }

    public static Collection getRolesForUser(AuthenticationSubject authSubject) {
        RoleFactory factory = RoleFactory.getFactory();
        Iterator iter = factory.getRoles().iterator();
        Role role; List<Role> rolesForUser = new ArrayList<Role>();
        AuthUtils authUtils = AuthUtils.instance();
        while (iter.hasNext()) {
            role = (Role) iter.next();
            if (authUtils.isMember(role, authSubject)) {
                rolesForUser.add(role);
            }
        }
        return rolesForUser;
    }

    public static void main(String[] args) throws Exception {
        AuthenticationSubject authSubject = new AuthenticationSubject("admin", "admin".toCharArray(), true);

        // Search for all users (NOTE: RUN THIS ONLY IF THERE ARE HANDFUL OF USERS)
        System.out.println();
        System.out.println("SEARCHING FOR ALL USERS");
        System.out.println("-----------------------");

        searchUsers(null);

        System.out.println();
        System.out.println("RETRIEVING INDIVIDUAL USERS");
        System.out.println("---------------------------");

        retrieveUser("nu1");
        retrieveUser("nu2");
        retrieveUser("nu3");
        retrieveUser("nu4");

        System.out.println();
        System.out.println("MATCHING USER PASSWORD");
        System.out.println("----------------------");

        matchUserPassword("nu1", "nu1");
        matchUserPassword("nu2", "wrongpassword");
        matchUserPassword("nu3", "nu3");
        matchUserPassword("nu4", "nu4");

        System.out.println();
        System.out.println("GETTING ALL ROLES");
        System.out.println("-----------------");

        getRoles();

        // create and get roles
        System.out.println();
        System.out.println("GETTING INDIVIDUAL ROLES");
        System.out.println("------------------------");

        getRoleByPath("/Authenticated Users/NR1");
        getRoleByPath("/Authenticated Users/NR1/NR2");
        getRoleByPath("/Authenticated Users/NR3");
        getRoleByPath("/Authenticated Users/NR4");
        getRoleByPath("/Authenticated Users/NR5");

        getRoleByPath("dn://cn=LR1,ou=groups,dc=tibco,dc=com");

        // Check membership of user
        System.out.println();
        System.out.println("CHECKING MEMBERSHIP OF USERS");
        System.out.println("----------------------------");

        isMember("/Authenticated Users/NR1", new AuthenticationSubject("nu1", null, true));
        isMember("/Authenticated Users/NR1", new AuthenticationSubject("nu2", null, true));
        isMember("/Authenticated Users/NR1", new AuthenticationSubject("nu3", null, true));
        isMember("/Authenticated Users/NR1", new AuthenticationSubject("nu4", null, true));

        // search all members of a role
        System.out.println();
        System.out.println("SEARCHING ALL MEMBERS OF ROLE");
        System.out.println("-----------------------------");

        searchMembers("/Authenticated Users/NR1");
        searchMembers("dn://cn=LR1,ou=groups,dc=tibco,dc=com");

        // get all Roles for a user
        System.out.println();
        System.out.println("GETTING ALL ROLES FOR USER");
        System.out.println("----------------------------");

        Collection rolesForUser = getRolesForUser(new AuthenticationSubject("nu2", null, true));
        System.out.println();
        System.out.println("Roles for User (nu2) are: ");
        System.out.print("    ");
        boolean first = true;
        Iterator iter = rolesForUser.iterator();
        Role role;
        while (iter.hasNext()) {
            if (first) first = false;
            else System.out.print(", ");
            role = (Role) iter.next();
            System.out.print(role.getName());
        }
        System.out.println();

        // get all Roles for a user
        rolesForUser = getRolesForUser(new AuthenticationSubject("nu3", null, true));
        System.out.println();
        System.out.println("Roles for User (nu3) are: ");
        System.out.print("    ");
        first = true;
        iter = rolesForUser.iterator();
        while (iter.hasNext()) {
            if (first) first = false;
            else System.out.print(", ");
            role = (Role) iter.next();
            System.out.print(role.getName());
        }
        System.out.println();

        System.out.println();
        System.out.println("--- THE END ----");

        System.exit(0);
    }

}
