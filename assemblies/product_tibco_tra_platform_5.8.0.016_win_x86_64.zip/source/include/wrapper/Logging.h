#ifndef _Logging_h_
	#define _Logging_h_

#include <stdio.h>
#include "Types.h"


//<+++++=======================================================+++++>
class Logging
{
public:
//	Logging();
//	~Logging();

	static void Info( char const * szString );
	static void Debug( char const * szString );
	static void FatalError( char const * szErrorString );
	// this only works in Win32, obviously...
	static void PrintLastErrorInMessageBox();
	static void EnableDebug();
	static void EnableSilent();

	static void CloseHandle();
	static void FlushFiles();

	static void SetChildProcessFlag();


private:
	// explicitly disallowing use of these:
	Logging()   {}
	void operator=( Logging const & rhs)   {}

	static FILE * GetHandle();

	static FILE *		m_hLogFile;
	static bool		s_DebugFlag;
	static bool		s_SilentFlag;
	static bool		s_IsChildProcess;
	static char *		s_szLogFileName;
};
//<+++++=======================================================+++++>


#endif		// _Logging_h_

