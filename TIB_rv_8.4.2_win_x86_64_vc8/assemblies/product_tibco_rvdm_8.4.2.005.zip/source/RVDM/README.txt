Starting RVDM
-------------

1. Java

RVDM requires J2SE 6.0 or later.

If JAVA_HOME is set, then the script runs the Java executable in
JAVA_HOME/bin.

If JAVA_HOME is not set, then the script attempts to find the Java
executable in the user's PATH.


2. Rendezvous

RVDM requires TIBCO Rendezvous 8.0.0 or later.

If TIBRV_HOME is set, then the script adds TIBRV_HOME/bin and
TIBRV_HOME/lib to the user's PATH.  These directories are required for
rvd and the Rendezvous libraries.


3.

To display usage information:

[UNIX]	   RVDM.sh -help

or

[Windows]  RVDM.bat -help

Unless provided on the command line, default values are assumed for
all required parameters.
