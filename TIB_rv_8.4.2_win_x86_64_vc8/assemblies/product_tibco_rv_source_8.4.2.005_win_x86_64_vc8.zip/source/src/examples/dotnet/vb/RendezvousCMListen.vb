' Copyright (c) 2000-$Date: 2013-12-20 09:20:06 -0800 (Fri, 20 Dec 2013) $ TIBCO Software Inc.
' All rights reserved.
' TIB/Rendezvous is protected under US Patent No. 5,187,787.
' For more information, please contact:
' TIBCO Software Inc., Palo Alto, California, USA

'***************************************************************
'
'  Example RendezvousCMListen program.
'  ----------------------------------
'
' This program demonstrates the use of several features of the
' RV .NET interface from within VB.NET.
'
' The program presents a simple form that allows control of
' a simple RV certified message listener.  Default values are
' provided for all fields which allows the application to be
' operated by just pressing the various control buttons.  For
' users who wish to try more sophisticated configurations, the
' form has fields that allow customizations similar to the C
' examples.
'
' The code does not make any effort to catch errors.  If errors
' are encountered, VB.NET will pop up a message box with
' details of the problem.  The most likely reason for errors
' would be incorrectly specified transport parameters
' (i.e. Service, Network and Daemon)
'
' We have made some effort to allow only reasonable calls to be
' made by disabling buttons and text boxes when their use is
' not meaningful or useful.  For example, we disable the destroy
' transports button when no RV mechanism exists, or the subject
' while a listener is active.
'
' One last note: Please consider any programming errors you
' find to have been deliberately included as an exercise...
'
'***************************************************************

Public Class RendezvousCMListen
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_ClearMsgs As System.Windows.Forms.Button
    Friend WithEvents Lbl_MessagesReceived As System.Windows.Forms.Label
    Friend WithEvents Txt_Message_Recvd As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_Subject As System.Windows.Forms.TextBox
    Friend WithEvents Btn_CreateListener As System.Windows.Forms.Button
    Friend WithEvents Lbl_Subject As System.Windows.Forms.Label
    Friend WithEvents Btn_DestroyListener As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_Network As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Daemon As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Daemon As System.Windows.Forms.Label
    Friend WithEvents Lbl_Service As System.Windows.Forms.Label
    Friend WithEvents Lbl_Network As System.Windows.Forms.Label
    Friend WithEvents Btn_DestroyXport As System.Windows.Forms.Button
    Friend WithEvents Btn_Exit As System.Windows.Forms.Button
    Friend WithEvents Txt_Service As System.Windows.Forms.TextBox
    Friend WithEvents Txt_LedgerFileName As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Ledger As System.Windows.Forms.Label
    Friend WithEvents Txt_CmName As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_CMName As System.Windows.Forms.Label
    Friend WithEvents Lbl_Number_Messages_Recvd As System.Windows.Forms.Label
    Friend WithEvents Btn_CreateXport As System.Windows.Forms.Button
    Friend WithEvents Number_Msgs_Received As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Btn_ClearMsgs = New System.Windows.Forms.Button
        Me.Lbl_MessagesReceived = New System.Windows.Forms.Label
        Me.Txt_Message_Recvd = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Number_Msgs_Received = New System.Windows.Forms.TextBox
        Me.Lbl_Number_Messages_Recvd = New System.Windows.Forms.Label
        Me.Txt_Subject = New System.Windows.Forms.TextBox
        Me.Btn_CreateListener = New System.Windows.Forms.Button
        Me.Lbl_Subject = New System.Windows.Forms.Label
        Me.Btn_DestroyListener = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Txt_LedgerFileName = New System.Windows.Forms.TextBox
        Me.Lbl_Ledger = New System.Windows.Forms.Label
        Me.Txt_CmName = New System.Windows.Forms.TextBox
        Me.Lbl_CMName = New System.Windows.Forms.Label
        Me.Txt_Network = New System.Windows.Forms.TextBox
        Me.Txt_Daemon = New System.Windows.Forms.TextBox
        Me.Lbl_Daemon = New System.Windows.Forms.Label
        Me.Lbl_Service = New System.Windows.Forms.Label
        Me.Btn_CreateXport = New System.Windows.Forms.Button
        Me.Lbl_Network = New System.Windows.Forms.Label
        Me.Btn_DestroyXport = New System.Windows.Forms.Button
        Me.Btn_Exit = New System.Windows.Forms.Button
        Me.Txt_Service = New System.Windows.Forms.TextBox
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Btn_ClearMsgs)
        Me.GroupBox3.Controls.Add(Me.Lbl_MessagesReceived)
        Me.GroupBox3.Controls.Add(Me.Txt_Message_Recvd)
        Me.GroupBox3.Location = New System.Drawing.Point(0, 240)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(368, 168)
        Me.GroupBox3.TabIndex = 22
        Me.GroupBox3.TabStop = False
        '
        'Btn_ClearMsgs
        '
        Me.Btn_ClearMsgs.Location = New System.Drawing.Point(240, 11)
        Me.Btn_ClearMsgs.Name = "Btn_ClearMsgs"
        Me.Btn_ClearMsgs.Size = New System.Drawing.Size(120, 24)
        Me.Btn_ClearMsgs.TabIndex = 16
        Me.Btn_ClearMsgs.Text = "Clear Messages"
        '
        'Lbl_MessagesReceived
        '
        Me.Lbl_MessagesReceived.Location = New System.Drawing.Point(16, 16)
        Me.Lbl_MessagesReceived.Name = "Lbl_MessagesReceived"
        Me.Lbl_MessagesReceived.Size = New System.Drawing.Size(112, 16)
        Me.Lbl_MessagesReceived.TabIndex = 4
        Me.Lbl_MessagesReceived.Text = "Messages Received"
        '
        'Txt_Message_Recvd
        '
        Me.Txt_Message_Recvd.Location = New System.Drawing.Point(8, 40)
        Me.Txt_Message_Recvd.Multiline = True
        Me.Txt_Message_Recvd.Name = "Txt_Message_Recvd"
        Me.Txt_Message_Recvd.ReadOnly = True
        Me.Txt_Message_Recvd.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.Txt_Message_Recvd.Size = New System.Drawing.Size(344, 120)
        Me.Txt_Message_Recvd.TabIndex = 9
        Me.Txt_Message_Recvd.Text = ""
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Number_Msgs_Received)
        Me.GroupBox2.Controls.Add(Me.Lbl_Number_Messages_Recvd)
        Me.GroupBox2.Controls.Add(Me.Txt_Subject)
        Me.GroupBox2.Controls.Add(Me.Btn_CreateListener)
        Me.GroupBox2.Controls.Add(Me.Lbl_Subject)
        Me.GroupBox2.Controls.Add(Me.Btn_DestroyListener)
        Me.GroupBox2.Location = New System.Drawing.Point(0, 144)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(368, 88)
        Me.GroupBox2.TabIndex = 21
        Me.GroupBox2.TabStop = False
        '
        'Number_Msgs_Received
        '
        Me.Number_Msgs_Received.Location = New System.Drawing.Point(152, 56)
        Me.Number_Msgs_Received.Name = "Number_Msgs_Received"
        Me.Number_Msgs_Received.Size = New System.Drawing.Size(64, 20)
        Me.Number_Msgs_Received.TabIndex = 17
        Me.Number_Msgs_Received.Text = "0"
        '
        'Lbl_Number_Messages_Recvd
        '
        Me.Lbl_Number_Messages_Recvd.Location = New System.Drawing.Point(16, 57)
        Me.Lbl_Number_Messages_Recvd.Name = "Lbl_Number_Messages_Recvd"
        Me.Lbl_Number_Messages_Recvd.Size = New System.Drawing.Size(128, 16)
        Me.Lbl_Number_Messages_Recvd.TabIndex = 16
        Me.Lbl_Number_Messages_Recvd.Text = "# of Messages Received"
        '
        'Txt_Subject
        '
        Me.Txt_Subject.Location = New System.Drawing.Point(88, 24)
        Me.Txt_Subject.Name = "Txt_Subject"
        Me.Txt_Subject.Size = New System.Drawing.Size(128, 20)
        Me.Txt_Subject.TabIndex = 8
        Me.Txt_Subject.Text = "VB.NET.example.certified"
        '
        'Btn_CreateListener
        '
        Me.Btn_CreateListener.Location = New System.Drawing.Point(240, 16)
        Me.Btn_CreateListener.Name = "Btn_CreateListener"
        Me.Btn_CreateListener.Size = New System.Drawing.Size(120, 24)
        Me.Btn_CreateListener.TabIndex = 12
        Me.Btn_CreateListener.Text = "Create CM Listener"
        '
        'Lbl_Subject
        '
        Me.Lbl_Subject.Location = New System.Drawing.Point(16, 24)
        Me.Lbl_Subject.Name = "Lbl_Subject"
        Me.Lbl_Subject.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Subject.TabIndex = 3
        Me.Lbl_Subject.Text = "Subject"
        '
        'Btn_DestroyListener
        '
        Me.Btn_DestroyListener.Location = New System.Drawing.Point(240, 56)
        Me.Btn_DestroyListener.Name = "Btn_DestroyListener"
        Me.Btn_DestroyListener.Size = New System.Drawing.Size(120, 24)
        Me.Btn_DestroyListener.TabIndex = 15
        Me.Btn_DestroyListener.Text = "Destroy CM Listener"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txt_LedgerFileName)
        Me.GroupBox1.Controls.Add(Me.Lbl_Ledger)
        Me.GroupBox1.Controls.Add(Me.Txt_CmName)
        Me.GroupBox1.Controls.Add(Me.Lbl_CMName)
        Me.GroupBox1.Controls.Add(Me.Txt_Network)
        Me.GroupBox1.Controls.Add(Me.Txt_Daemon)
        Me.GroupBox1.Controls.Add(Me.Lbl_Daemon)
        Me.GroupBox1.Controls.Add(Me.Lbl_Service)
        Me.GroupBox1.Controls.Add(Me.Btn_CreateXport)
        Me.GroupBox1.Controls.Add(Me.Lbl_Network)
        Me.GroupBox1.Controls.Add(Me.Btn_DestroyXport)
        Me.GroupBox1.Controls.Add(Me.Btn_Exit)
        Me.GroupBox1.Controls.Add(Me.Txt_Service)
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(368, 144)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        '
        'Txt_LedgerFileName
        '
        Me.Txt_LedgerFileName.Location = New System.Drawing.Point(240, 112)
        Me.Txt_LedgerFileName.Name = "Txt_LedgerFileName"
        Me.Txt_LedgerFileName.Size = New System.Drawing.Size(112, 20)
        Me.Txt_LedgerFileName.TabIndex = 18
        Me.Txt_LedgerFileName.Text = ""
        '
        'Lbl_Ledger
        '
        Me.Lbl_Ledger.Location = New System.Drawing.Point(192, 112)
        Me.Lbl_Ledger.Name = "Lbl_Ledger"
        Me.Lbl_Ledger.Size = New System.Drawing.Size(40, 16)
        Me.Lbl_Ledger.TabIndex = 17
        Me.Lbl_Ledger.Text = "Ledger"
        '
        'Txt_CmName
        '
        Me.Txt_CmName.Location = New System.Drawing.Point(88, 112)
        Me.Txt_CmName.Name = "Txt_CmName"
        Me.Txt_CmName.Size = New System.Drawing.Size(96, 20)
        Me.Txt_CmName.TabIndex = 16
        Me.Txt_CmName.Text = "CmListen"
        '
        'Lbl_CMName
        '
        Me.Lbl_CMName.Location = New System.Drawing.Point(8, 112)
        Me.Lbl_CMName.Name = "Lbl_CMName"
        Me.Lbl_CMName.Size = New System.Drawing.Size(56, 16)
        Me.Lbl_CMName.TabIndex = 15
        Me.Lbl_CMName.Text = "CmName"
        '
        'Txt_Network
        '
        Me.Txt_Network.Location = New System.Drawing.Point(88, 48)
        Me.Txt_Network.Name = "Txt_Network"
        Me.Txt_Network.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Network.TabIndex = 6
        Me.Txt_Network.Text = ""
        '
        'Txt_Daemon
        '
        Me.Txt_Daemon.Location = New System.Drawing.Point(88, 80)
        Me.Txt_Daemon.Name = "Txt_Daemon"
        Me.Txt_Daemon.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Daemon.TabIndex = 7
        Me.Txt_Daemon.Text = ""
        '
        'Lbl_Daemon
        '
        Me.Lbl_Daemon.Location = New System.Drawing.Point(16, 80)
        Me.Lbl_Daemon.Name = "Lbl_Daemon"
        Me.Lbl_Daemon.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Daemon.TabIndex = 2
        Me.Lbl_Daemon.Text = "Daemon"
        '
        'Lbl_Service
        '
        Me.Lbl_Service.Location = New System.Drawing.Point(16, 16)
        Me.Lbl_Service.Name = "Lbl_Service"
        Me.Lbl_Service.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Service.TabIndex = 0
        Me.Lbl_Service.Text = "Service"
        '
        'Btn_CreateXport
        '
        Me.Btn_CreateXport.Location = New System.Drawing.Point(232, 16)
        Me.Btn_CreateXport.Name = "Btn_CreateXport"
        Me.Btn_CreateXport.Size = New System.Drawing.Size(128, 24)
        Me.Btn_CreateXport.TabIndex = 10
        Me.Btn_CreateXport.Text = "Create CM Transport"
        '
        'Lbl_Network
        '
        Me.Lbl_Network.Location = New System.Drawing.Point(16, 48)
        Me.Lbl_Network.Name = "Lbl_Network"
        Me.Lbl_Network.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Network.TabIndex = 1
        Me.Lbl_Network.Text = "Network"
        '
        'Btn_DestroyXport
        '
        Me.Btn_DestroyXport.Location = New System.Drawing.Point(232, 48)
        Me.Btn_DestroyXport.Name = "Btn_DestroyXport"
        Me.Btn_DestroyXport.Size = New System.Drawing.Size(128, 24)
        Me.Btn_DestroyXport.TabIndex = 11
        Me.Btn_DestroyXport.Text = "Destroy CM Transport"
        '
        'Btn_Exit
        '
        Me.Btn_Exit.ForeColor = System.Drawing.Color.Firebrick
        Me.Btn_Exit.Location = New System.Drawing.Point(288, 80)
        Me.Btn_Exit.Name = "Btn_Exit"
        Me.Btn_Exit.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Exit.TabIndex = 14
        Me.Btn_Exit.Text = "Exit"
        '
        'Txt_Service
        '
        Me.Txt_Service.Location = New System.Drawing.Point(88, 16)
        Me.Txt_Service.Name = "Txt_Service"
        Me.Txt_Service.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Service.TabIndex = 5
        Me.Txt_Service.Text = ""
        '
        'RendezvousCMListen
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 413)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "RendezvousCMListen"
        Me.Text = "Rendezvous CM Listen Application Using .NET library"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    'Global data shared among several action routines

    ' The transport that we will use to contact the daemon
    Dim transport As TIBCO.Rendezvous.Transport

    ' The cm transport we will use for certified messages
    Dim cmtransport As TIBCO.Rendezvous.CMTransport

    ' A timer object we will use to send multiple messages
    Dim timer As System.Timers.Timer

    ' A CM Message object to get the Certified Messages
    Dim msg As TIBCO.Rendezvous.CMMessage

    'A CM Listener to listen to the events
    Dim mylistener As TIBCO.Rendezvous.CMListener

    'A dispatcher to dispatch events
    Dim dispatcher As TIBCO.Rendezvous.Dispatcher

    ' This will be the timer interval in seconds
    Dim interval As Double

    ' To count number of messages received
    Dim displayCount As Double
    Dim nNumMsgs As Int32


    '**********************************************************
    ' This subroutine is invoked when VB.NET tries to load our form.
    ' We will open the RV system, set up access to buttons and textboxes.

    Private Sub RendezvousCMListen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'First, open the RV system.  This method creates all the underlying
        ' mechanisms that will be used to handle events and send messages.
        TIBCO.Rendezvous.Environment.Open()
        ' Call the routines to enable / disable buttons
        Enable_Create_Transport()
        Disable_Destroy_Transport()

    End Sub
    '**********************************************************
    ' This routine fires when the create transport button is clicked
    ' The values are taken from the repective text boxes in GUI

    Private Sub Btn_CreateXport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CreateXport.Click

        ' The other parameters may be null or absent.  If the cmname
        ' parameter is null, RV supplies a unique non-reusable name.

        'If the ledgerfilename is null then we use memory based ledger file
        'else we create the file based ledger file with the old messages require flag set to true.
        'If the CMname is null then we need to specify vbNull for CMname and false for Syncledger

        Try
            transport = New TIBCO.Rendezvous.NetTransport(Txt_Service.Text, Txt_Network.Text, Txt_Daemon.Text)

            If Txt_LedgerFileName.Text = vbNullString Then

                If Txt_CmName.Text = vbNullString Then
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, vbNull, False)
                Else
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, Txt_CmName.Text, True)
                End If

            Else
                If Txt_CmName.Text = vbNullString Then
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, vbNull, False, Txt_LedgerFileName.Text, True)
                Else
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, Txt_CmName.Text, True, Txt_LedgerFileName.Text, True)
                End If
            End If

            Enable_Destroy_Transport()  ' Allow transport destroy, lis add/disallow/allow
            Disable_Create_Transport()  ' Lock options, disable create
            Enable_Create_Listener()    ' Allow listener create

        Catch exception As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Create CM Transport,  Reason :  " + exception.Message)

        End Try

    End Sub
    '**********************************************************
    ' The "Destroy Transport" button invokes this routine.
    ' We undo the setup here and clean up RV objects.

    Private Sub Btn_DestroyXport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DestroyXport.Click
        ' Destroy our transport and set to nothing.
        If Not cmtransport Is Nothing Then
            cmtransport.Destroy()
            cmtransport = Nothing
        End If

        If Not transport Is Nothing Then
            transport.Destroy()
            transport = Nothing
        End If

        '****************************************************************
        ' Everything else in this function is not directly related to RV.

        Number_Msgs_Received.Text = 0
        nNumMsgs = 0
        Txt_Message_Recvd.Clear()

        ' Disable the "Destroy Transport" button - we do not have something to destroy
        Enable_Create_Transport()
        Disable_Destroy_Transport()

    End Sub
    '**********************************************************
    ' The "EXIT" button invokes this subroutine.
    ' If needed, we clean up RV stuff and then exit the application.

    Private Sub Btn_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Exit.Click
        ' Before we go, let's clean up

        ' This subroutine will do the transport cleanup.
        ' Close and free up the RV mechanisms. 

        TIBCO.Rendezvous.Environment.Close()
        End

    End Sub

    Private Sub Btn_CreateListener_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CreateListener.Click

        ' Allocate the listener object
        ' Set up the listener mechanism.
        Try

            If (Txt_Subject.Text = "") Then
                Txt_Message_Recvd.Text += "Please enter a valid subject name ..." & vbCrLf
                Return
            End If

            mylistener = New TIBCO.Rendezvous.CMListener(TIBCO.Rendezvous.Queue.Default, _
                                                                   cmtransport, Txt_Subject.Text, 0)
            dispatcher = New TIBCO.Rendezvous.Dispatcher(TIBCO.Rendezvous.Queue.Default)
            AddHandler mylistener.MessageReceived, AddressOf OnMessageReceived

            '****************************************************************
            ' Everything else in this function is not directly related to RV.

            ' Clear out any left-over counts and data from a previously created
            ' and destroyed listener.
            'Txt_Message_Recvd.Text += "Created Listener ..." & vbCrLf

            Disable_Create_Listener()   ' Disable subject, disable create button
            Enable_Destroy_Listener()   ' Enable destroy listener function

        Catch ex As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Create CM Listener,  Reason :  " + ex.Message)

        End Try

        nNumMsgs = 0
        Number_Msgs_Received.Text = nNumMsgs.ToString

    End Sub

    '**********************************************************
    ' This subroutine is invoked each a message arrives on the
    ' subject we are listening too.  We are going to process the
    ' message in this function.  The processing is rather
    ' simpleminded but should serve to illustrate the general
    ' principles.
    Private Sub OnMessageReceived(ByVal listener As Object, _
                        ByVal messageReceivedEventArgs As TIBCO.Rendezvous.MessageReceivedEventArgs)

        Dim message As TIBCO.Rendezvous.Message
        Dim cmMessage As TIBCO.Rendezvous.CMMessage
        Dim seqno As UInt64


        message = messageReceivedEventArgs.Message

        Txt_Message_Recvd.Text += message.ToString & vbCrLf
        nNumMsgs = nNumMsgs + 1
        Number_Msgs_Received.Text = nNumMsgs.ToString

        If (TypeOf message Is TIBCO.Rendezvous.CMMessage) Then
            cmMessage = messageReceivedEventArgs.Message

            Try
                seqno = cmMessage.SequenceNumber
                Txt_Message_Recvd.Text += "Confirmed message with Seq No " + seqno.ToString & vbCrLf

            Catch Ex As TIBCO.Rendezvous.RendezvousException
                If (Ex.Status = TIBCO.Rendezvous.Status.NotFound) Then
                    Txt_Message_Recvd.Text += "Received First message" & vbCrLf
                End If

            End Try

        End If

    End Sub
    Private Sub Btn_DestroyListener_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DestroyListener.Click
        ' Destroy our listener.  This will drop our interest in
        ' messages that may arrive on this subject.
        If Not mylistener Is Nothing Then
            mylistener.Destroy()
            mylistener = Nothing
        End If

        '****************************************************************
        ' Everything else in this function is not directly related to RV.
        Disable_Destroy_Listener()  ' Disable destroy listener.
        Enable_Create_Listener()    ' Allow listener create

    End Sub

    Private Sub Btn_ClearMsgs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ClearMsgs.Click
        Txt_Message_Recvd.Clear()
    End Sub
    '============================================================
    ' This routine sets the buttons and colors for when we have
    ' destroyed or not yet created a transport.  At this point,
    ' we can set the options for the transport and can create it.

    Private Sub Enable_Create_Transport()
        ' Unlock the text boxes so that the user can change the transport
        ' arguments if desired.  Restore the color.
        Txt_Service.Enabled = True
        Txt_Network.Enabled = True
        Txt_Daemon.Enabled = True
        Txt_LedgerFileName.Enabled = True
        Txt_CmName.Enabled = True
        Lbl_Service.Enabled = True
        Lbl_Network.Enabled = True
        Lbl_Daemon.Enabled = True
        Lbl_Ledger.Enabled = True
        Lbl_CMName.Enabled = True

        ' Change button states (can/cannot be pressed) and colors to disallow
        ' operations that are no longer possible after destroying support RV.
        Btn_CreateXport.Enabled = True       ' We can now call the initialization function.

        ' Don't allow listener add/allow/disallow with no cm transport.
        Btn_CreateListener.Enabled = False
        Btn_DestroyListener.Enabled = False

    End Sub
    '**********************************************************
    ' This routine disables the button for the
    ' transport destroy function when we have destroyed or not
    ' yet created a transport.

    Private Sub Disable_Create_Transport()  ' Lock options, disable create
        ' Disable the following text boxes, since changing them will
        ' have no effect unless the transport is recreated.
        Txt_Service.Enabled = False
        Txt_Network.Enabled = False
        Txt_Daemon.Enabled = False
        Lbl_Service.Enabled = False
        Lbl_Network.Enabled = False
        Lbl_Daemon.Enabled = False

        ' Disable the "Create Transport" button
        Btn_CreateXport.Enabled = False

        ' Allow listener add/allow/disallow with no cm transport.
        Btn_CreateListener.Enabled = True
    End Sub
    '**********************************************************
    ' This routine enables the button when we have created
    ' a transport and listener.

    Private Sub Enable_Destroy_Transport()  ' Allow transport destroy, lis add/disallow/allow
        ' Enable the "Destroy Transport" button - we now have something to destroy
        Btn_DestroyXport.Enabled = True
    End Sub
    '============================================================
    ' This routine sets the buttons and colors for when we have
    ' destroyed or not yet created a transport.

    Private Sub Disable_Destroy_Transport()
        Btn_DestroyXport.Enabled = False     ' We can't destroy what doesn't exist
    End Sub
    '**********************************************************
    ' This routine enables the button when we have created a transport
    ' but have not created or have destroyed a listener.  At this
    ' point, we can set the subject and can create the listener
    ' to register interest in the subject.
    Private Sub Enable_Create_Listener()    ' Allow listener create
        ' Enable the following text box.  The user may want to change them
        ' in preparation for creating another listener.  Restore the color.
        Txt_Subject.Enabled = True
        Lbl_Subject.Enabled = True

        ' Enable the "Create Listener" button - we may want to subscribe again
        Btn_CreateListener.Enabled = True

    End Sub
    '**********************************************************
    ' This routine disables the button and sets colors for the
    ' create listener function when we have already created a
    ' listener.  At this point, we can wait for messages and we
    ' can destroy the listener or the transport.
    Private Sub Disable_Create_Listener()   ' Disable subject, disable create button
        ' Disable the subjet text box, since changing it will have no
        ' effect unless the subscriber is recreated.  Gray the textbox.
        ' If we allowed a create action with the listener active, it would
        ' have destroy the current listener in the process of creating another.

        Txt_Subject.Enabled = False
        Lbl_Subject.Enabled = False

        ' Disable the "Create Listener" button
        Btn_CreateListener.Enabled = False

    End Sub
    '**********************************************************
    ' This routine enables the button destroy listener when we have created a listener.
    Private Sub Enable_Destroy_Listener()   ' Enable destroy listener function
        ' Enable the "Destroy Listener" button - we now have something to destroy
        Btn_DestroyListener.Enabled = True

    End Sub
    '**********************************************************
    ' This routine disables the button for the
    ' listener destroy function when we have destroyed or not
    ' yet created a listener.
    Private Sub Disable_Destroy_Listener()      ' Disable destroy listener.
        ' Disable the "Destroy Listener" button.  Nothing to destroy.
        Btn_DestroyListener.Enabled = False

    End Sub
    '**********************************************************
    'If the RendezvousCMListen is closed using the X button at the 
    'top of dialog box then we handle it here.

    Private Sub RendezvousCMListen_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        Btn_Exit_Click(Me, New EventArgs)
    End Sub
End Class
