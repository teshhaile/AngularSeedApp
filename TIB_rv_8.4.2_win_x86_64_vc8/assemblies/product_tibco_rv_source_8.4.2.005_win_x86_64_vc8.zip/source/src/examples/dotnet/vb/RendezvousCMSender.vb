' Copyright (c) 2000-$Date: 2013-12-20 09:20:06 -0800 (Fri, 20 Dec 2013) $ TIBCO Software Inc.
' All rights reserved.
' TIB/Rendezvous is protected under US Patent No. 5,187,787.
' For more information, please contact:
' TIBCO Software Inc., Palo Alto, California, USA

'***************************************************************
'
'  Example RendezvousCMSender program.
'  -----------------------------------
'
' This program demonstrates the use of several features of the
' RV .NET interface from within VB.NET.
'
' The program presents a simple form that allows control of
' a simple RV certified message publisher.  Default values are
' provided for all ields which allows the application to be
' operated by just pressing the various control buttons.  For
' users who wish to try more sophisticated configurations, the
' form has fields that allow customizations similar to the C
' examples.
'
' The code does not make any effort to catch errors.  If errors
' are encountered, VB.NET will pop up a message box with
' details of the problem.  The most likely reason for errors
' would be incorrectly specified transport parameters
' (i.e. Service, Network and Daemon)
'
' We have made some effort to allow only reasonable calls to be
' made by disabling buttons and text boxes when their use is
' not meaningful or useful.  For example, we disable the send
' buttons when no RV mechanism exists, or the send count while
' a "Send Many" operation is in progress.
'
' We do allow the message field information to be changed at
' any time.  This makes it easy to change messages on the fly
' while sending a stream of messages.
'
' One last note: Please consider any programming errors you
' find to have been deliberately included as an exercise...
'
'***************************************************************
Imports System.Timers

Public Class RendezvousCMSender
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Grp_Box3 As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_FieldValue As System.Windows.Forms.TextBox
    Friend WithEvents Txt_FieldName As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_FieldValue As System.Windows.Forms.Label
    Friend WithEvents Lbl_FieldName As System.Windows.Forms.Label
    Friend WithEvents Grp_Box1 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Exit As System.Windows.Forms.Button
    Friend WithEvents Btn_DestroyXport As System.Windows.Forms.Button
    Friend WithEvents Btn_CreateXport As System.Windows.Forms.Button
    Friend WithEvents Txt_Service As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Daemon As System.Windows.Forms.Label
    Friend WithEvents Lbl_Network As System.Windows.Forms.Label
    Friend WithEvents Lbl_Service As System.Windows.Forms.Label
    Friend WithEvents Txt_Daemon As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Network As System.Windows.Forms.TextBox
    Friend WithEvents Grp_Box2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_MessageSentCount As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_NoMsgs As System.Windows.Forms.Label
    Friend WithEvents Btn_SendOne As System.Windows.Forms.Button
    Friend WithEvents Btn_SendMany As System.Windows.Forms.Button
    Friend WithEvents Lbl_Subject As System.Windows.Forms.Label
    Friend WithEvents Txt_Count As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Count As System.Windows.Forms.Label
    Friend WithEvents Txt_Subject As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Interval As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Interval As System.Windows.Forms.Label
    Friend WithEvents Lbl_CMName As System.Windows.Forms.Label
    Friend WithEvents Txt_CmName As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Ledger As System.Windows.Forms.Label
    Friend WithEvents Txt_LedgerFileName As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_ListenerCMNAme As System.Windows.Forms.Label
    Friend WithEvents Txt_ListenerCMName As System.Windows.Forms.TextBox
    Friend WithEvents Btn_DisallowListener As System.Windows.Forms.Button
    Friend WithEvents Btn_AllowListener As System.Windows.Forms.Button
    Friend WithEvents Btn_AddListener As System.Windows.Forms.Button
    Friend WithEvents Txt_SeqNo As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_SeqNo As System.Windows.Forms.Label
    Friend WithEvents Lbl_ListenerAction As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Grp_Box3 = New System.Windows.Forms.GroupBox
        Me.Txt_FieldValue = New System.Windows.Forms.TextBox
        Me.Txt_FieldName = New System.Windows.Forms.TextBox
        Me.Lbl_FieldValue = New System.Windows.Forms.Label
        Me.Lbl_FieldName = New System.Windows.Forms.Label
        Me.Grp_Box1 = New System.Windows.Forms.GroupBox
        Me.Txt_LedgerFileName = New System.Windows.Forms.TextBox
        Me.Lbl_Ledger = New System.Windows.Forms.Label
        Me.Txt_CmName = New System.Windows.Forms.TextBox
        Me.Lbl_CMName = New System.Windows.Forms.Label
        Me.Btn_Exit = New System.Windows.Forms.Button
        Me.Btn_DestroyXport = New System.Windows.Forms.Button
        Me.Btn_CreateXport = New System.Windows.Forms.Button
        Me.Txt_Service = New System.Windows.Forms.TextBox
        Me.Lbl_Daemon = New System.Windows.Forms.Label
        Me.Lbl_Network = New System.Windows.Forms.Label
        Me.Lbl_Service = New System.Windows.Forms.Label
        Me.Txt_Daemon = New System.Windows.Forms.TextBox
        Me.Txt_Network = New System.Windows.Forms.TextBox
        Me.Grp_Box2 = New System.Windows.Forms.GroupBox
        Me.Lbl_ListenerAction = New System.Windows.Forms.Label
        Me.Btn_DisallowListener = New System.Windows.Forms.Button
        Me.Btn_AllowListener = New System.Windows.Forms.Button
        Me.Btn_AddListener = New System.Windows.Forms.Button
        Me.Txt_ListenerCMName = New System.Windows.Forms.TextBox
        Me.Lbl_ListenerCMNAme = New System.Windows.Forms.Label
        Me.Lbl_Subject = New System.Windows.Forms.Label
        Me.Txt_Subject = New System.Windows.Forms.TextBox
        Me.Txt_MessageSentCount = New System.Windows.Forms.TextBox
        Me.Lbl_NoMsgs = New System.Windows.Forms.Label
        Me.Btn_SendOne = New System.Windows.Forms.Button
        Me.Btn_SendMany = New System.Windows.Forms.Button
        Me.Txt_Count = New System.Windows.Forms.TextBox
        Me.Lbl_Count = New System.Windows.Forms.Label
        Me.Txt_Interval = New System.Windows.Forms.TextBox
        Me.Lbl_Interval = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Txt_SeqNo = New System.Windows.Forms.TextBox
        Me.Lbl_SeqNo = New System.Windows.Forms.Label
        Me.Grp_Box3.SuspendLayout()
        Me.Grp_Box1.SuspendLayout()
        Me.Grp_Box2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grp_Box3
        '
        Me.Grp_Box3.Controls.Add(Me.Txt_FieldValue)
        Me.Grp_Box3.Controls.Add(Me.Txt_FieldName)
        Me.Grp_Box3.Controls.Add(Me.Lbl_FieldValue)
        Me.Grp_Box3.Controls.Add(Me.Lbl_FieldName)
        Me.Grp_Box3.Location = New System.Drawing.Point(0, 352)
        Me.Grp_Box3.Name = "Grp_Box3"
        Me.Grp_Box3.Size = New System.Drawing.Size(368, 80)
        Me.Grp_Box3.TabIndex = 29
        Me.Grp_Box3.TabStop = False
        '
        'Txt_FieldValue
        '
        Me.Txt_FieldValue.Location = New System.Drawing.Point(88, 48)
        Me.Txt_FieldValue.Name = "Txt_FieldValue"
        Me.Txt_FieldValue.Size = New System.Drawing.Size(240, 20)
        Me.Txt_FieldValue.TabIndex = 21
        Me.Txt_FieldValue.Text = "Rendezvous CM Sender Example Message"
        '
        'Txt_FieldName
        '
        Me.Txt_FieldName.Location = New System.Drawing.Point(88, 16)
        Me.Txt_FieldName.Name = "Txt_FieldName"
        Me.Txt_FieldName.Size = New System.Drawing.Size(240, 20)
        Me.Txt_FieldName.TabIndex = 19
        Me.Txt_FieldName.Text = "Text Field"
        '
        'Lbl_FieldValue
        '
        Me.Lbl_FieldValue.Location = New System.Drawing.Point(8, 48)
        Me.Lbl_FieldValue.Name = "Lbl_FieldValue"
        Me.Lbl_FieldValue.Size = New System.Drawing.Size(64, 16)
        Me.Lbl_FieldValue.TabIndex = 20
        Me.Lbl_FieldValue.Text = "Field Value"
        '
        'Lbl_FieldName
        '
        Me.Lbl_FieldName.Location = New System.Drawing.Point(8, 16)
        Me.Lbl_FieldName.Name = "Lbl_FieldName"
        Me.Lbl_FieldName.Size = New System.Drawing.Size(64, 16)
        Me.Lbl_FieldName.TabIndex = 18
        Me.Lbl_FieldName.Text = "Field Name"
        '
        'Grp_Box1
        '
        Me.Grp_Box1.Controls.Add(Me.Txt_LedgerFileName)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Ledger)
        Me.Grp_Box1.Controls.Add(Me.Txt_CmName)
        Me.Grp_Box1.Controls.Add(Me.Lbl_CMName)
        Me.Grp_Box1.Controls.Add(Me.Btn_Exit)
        Me.Grp_Box1.Controls.Add(Me.Btn_DestroyXport)
        Me.Grp_Box1.Controls.Add(Me.Btn_CreateXport)
        Me.Grp_Box1.Controls.Add(Me.Txt_Service)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Daemon)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Network)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Service)
        Me.Grp_Box1.Controls.Add(Me.Txt_Daemon)
        Me.Grp_Box1.Controls.Add(Me.Txt_Network)
        Me.Grp_Box1.Location = New System.Drawing.Point(0, 0)
        Me.Grp_Box1.Name = "Grp_Box1"
        Me.Grp_Box1.Size = New System.Drawing.Size(368, 144)
        Me.Grp_Box1.TabIndex = 28
        Me.Grp_Box1.TabStop = False
        '
        'Txt_LedgerFileName
        '
        Me.Txt_LedgerFileName.Location = New System.Drawing.Point(240, 112)
        Me.Txt_LedgerFileName.Name = "Txt_LedgerFileName"
        Me.Txt_LedgerFileName.Size = New System.Drawing.Size(112, 20)
        Me.Txt_LedgerFileName.TabIndex = 13
        Me.Txt_LedgerFileName.Text = ""
        '
        'Lbl_Ledger
        '
        Me.Lbl_Ledger.Location = New System.Drawing.Point(192, 112)
        Me.Lbl_Ledger.Name = "Lbl_Ledger"
        Me.Lbl_Ledger.Size = New System.Drawing.Size(40, 16)
        Me.Lbl_Ledger.TabIndex = 12
        Me.Lbl_Ledger.Text = "Ledger"
        '
        'Txt_CmName
        '
        Me.Txt_CmName.Location = New System.Drawing.Point(80, 112)
        Me.Txt_CmName.Name = "Txt_CmName"
        Me.Txt_CmName.Size = New System.Drawing.Size(96, 20)
        Me.Txt_CmName.TabIndex = 11
        Me.Txt_CmName.Text = "CmSend"
        '
        'Lbl_CMName
        '
        Me.Lbl_CMName.Location = New System.Drawing.Point(8, 112)
        Me.Lbl_CMName.Name = "Lbl_CMName"
        Me.Lbl_CMName.Size = New System.Drawing.Size(56, 16)
        Me.Lbl_CMName.TabIndex = 10
        Me.Lbl_CMName.Text = "CmName"
        '
        'Btn_Exit
        '
        Me.Btn_Exit.ForeColor = System.Drawing.Color.Firebrick
        Me.Btn_Exit.Location = New System.Drawing.Point(280, 80)
        Me.Btn_Exit.Name = "Btn_Exit"
        Me.Btn_Exit.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Exit.TabIndex = 9
        Me.Btn_Exit.Text = "Exit"
        '
        'Btn_DestroyXport
        '
        Me.Btn_DestroyXport.Location = New System.Drawing.Point(224, 48)
        Me.Btn_DestroyXport.Name = "Btn_DestroyXport"
        Me.Btn_DestroyXport.Size = New System.Drawing.Size(128, 24)
        Me.Btn_DestroyXport.TabIndex = 8
        Me.Btn_DestroyXport.Text = "Destroy CM Transport"
        '
        'Btn_CreateXport
        '
        Me.Btn_CreateXport.Location = New System.Drawing.Point(224, 16)
        Me.Btn_CreateXport.Name = "Btn_CreateXport"
        Me.Btn_CreateXport.Size = New System.Drawing.Size(128, 24)
        Me.Btn_CreateXport.TabIndex = 7
        Me.Btn_CreateXport.Text = "Create CM Transport"
        '
        'Txt_Service
        '
        Me.Txt_Service.Location = New System.Drawing.Point(80, 16)
        Me.Txt_Service.Name = "Txt_Service"
        Me.Txt_Service.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Service.TabIndex = 2
        Me.Txt_Service.Text = ""
        '
        'Lbl_Daemon
        '
        Me.Lbl_Daemon.Location = New System.Drawing.Point(8, 80)
        Me.Lbl_Daemon.Name = "Lbl_Daemon"
        Me.Lbl_Daemon.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Daemon.TabIndex = 5
        Me.Lbl_Daemon.Text = "Daemon"
        '
        'Lbl_Network
        '
        Me.Lbl_Network.Location = New System.Drawing.Point(8, 48)
        Me.Lbl_Network.Name = "Lbl_Network"
        Me.Lbl_Network.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Network.TabIndex = 3
        Me.Lbl_Network.Text = "Network"
        '
        'Lbl_Service
        '
        Me.Lbl_Service.Location = New System.Drawing.Point(8, 16)
        Me.Lbl_Service.Name = "Lbl_Service"
        Me.Lbl_Service.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Service.TabIndex = 1
        Me.Lbl_Service.Text = "Service"
        '
        'Txt_Daemon
        '
        Me.Txt_Daemon.Location = New System.Drawing.Point(80, 80)
        Me.Txt_Daemon.Name = "Txt_Daemon"
        Me.Txt_Daemon.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Daemon.TabIndex = 6
        Me.Txt_Daemon.Text = ""
        '
        'Txt_Network
        '
        Me.Txt_Network.Location = New System.Drawing.Point(80, 48)
        Me.Txt_Network.Name = "Txt_Network"
        Me.Txt_Network.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Network.TabIndex = 4
        Me.Txt_Network.Text = ""
        '
        'Grp_Box2
        '
        Me.Grp_Box2.Controls.Add(Me.Lbl_ListenerAction)
        Me.Grp_Box2.Controls.Add(Me.Btn_DisallowListener)
        Me.Grp_Box2.Controls.Add(Me.Btn_AllowListener)
        Me.Grp_Box2.Controls.Add(Me.Btn_AddListener)
        Me.Grp_Box2.Controls.Add(Me.Txt_ListenerCMName)
        Me.Grp_Box2.Controls.Add(Me.Lbl_ListenerCMNAme)
        Me.Grp_Box2.Controls.Add(Me.Lbl_Subject)
        Me.Grp_Box2.Controls.Add(Me.Txt_Subject)
        Me.Grp_Box2.Location = New System.Drawing.Point(0, 144)
        Me.Grp_Box2.Name = "Grp_Box2"
        Me.Grp_Box2.Size = New System.Drawing.Size(368, 120)
        Me.Grp_Box2.TabIndex = 27
        Me.Grp_Box2.TabStop = False
        '
        'Lbl_ListenerAction
        '
        Me.Lbl_ListenerAction.Location = New System.Drawing.Point(248, 56)
        Me.Lbl_ListenerAction.Name = "Lbl_ListenerAction"
        Me.Lbl_ListenerAction.Size = New System.Drawing.Size(104, 16)
        Me.Lbl_ListenerAction.TabIndex = 17
        '
        'Btn_DisallowListener
        '
        Me.Btn_DisallowListener.Location = New System.Drawing.Point(240, 88)
        Me.Btn_DisallowListener.Name = "Btn_DisallowListener"
        Me.Btn_DisallowListener.Size = New System.Drawing.Size(104, 23)
        Me.Btn_DisallowListener.TabIndex = 16
        Me.Btn_DisallowListener.Text = "Disallow Listener"
        '
        'Btn_AllowListener
        '
        Me.Btn_AllowListener.Location = New System.Drawing.Point(128, 88)
        Me.Btn_AllowListener.Name = "Btn_AllowListener"
        Me.Btn_AllowListener.Size = New System.Drawing.Size(104, 23)
        Me.Btn_AllowListener.TabIndex = 15
        Me.Btn_AllowListener.Text = "Allow Listener"
        '
        'Btn_AddListener
        '
        Me.Btn_AddListener.Location = New System.Drawing.Point(16, 88)
        Me.Btn_AddListener.Name = "Btn_AddListener"
        Me.Btn_AddListener.Size = New System.Drawing.Size(104, 23)
        Me.Btn_AddListener.TabIndex = 14
        Me.Btn_AddListener.Text = "Add Listener"
        '
        'Txt_ListenerCMName
        '
        Me.Txt_ListenerCMName.Location = New System.Drawing.Point(128, 56)
        Me.Txt_ListenerCMName.Name = "Txt_ListenerCMName"
        Me.Txt_ListenerCMName.TabIndex = 13
        Me.Txt_ListenerCMName.Text = "CmListen"
        '
        'Lbl_ListenerCMNAme
        '
        Me.Lbl_ListenerCMNAme.Location = New System.Drawing.Point(8, 56)
        Me.Lbl_ListenerCMNAme.Name = "Lbl_ListenerCMNAme"
        Me.Lbl_ListenerCMNAme.Size = New System.Drawing.Size(104, 16)
        Me.Lbl_ListenerCMNAme.TabIndex = 12
        Me.Lbl_ListenerCMNAme.Text = "Listener CM Name"
        '
        'Lbl_Subject
        '
        Me.Lbl_Subject.Location = New System.Drawing.Point(8, 24)
        Me.Lbl_Subject.Name = "Lbl_Subject"
        Me.Lbl_Subject.Size = New System.Drawing.Size(48, 24)
        Me.Lbl_Subject.TabIndex = 10
        Me.Lbl_Subject.Text = "Subject"
        '
        'Txt_Subject
        '
        Me.Txt_Subject.Location = New System.Drawing.Point(80, 24)
        Me.Txt_Subject.Name = "Txt_Subject"
        Me.Txt_Subject.Size = New System.Drawing.Size(248, 20)
        Me.Txt_Subject.TabIndex = 11
        Me.Txt_Subject.Text = "VB.NET.example.certified"
        '
        'Txt_MessageSentCount
        '
        Me.Txt_MessageSentCount.Location = New System.Drawing.Point(208, 48)
        Me.Txt_MessageSentCount.Name = "Txt_MessageSentCount"
        Me.Txt_MessageSentCount.ReadOnly = True
        Me.Txt_MessageSentCount.Size = New System.Drawing.Size(56, 20)
        Me.Txt_MessageSentCount.TabIndex = 23
        Me.Txt_MessageSentCount.Text = "0"
        '
        'Lbl_NoMsgs
        '
        Me.Lbl_NoMsgs.Location = New System.Drawing.Point(152, 48)
        Me.Lbl_NoMsgs.Name = "Lbl_NoMsgs"
        Me.Lbl_NoMsgs.Size = New System.Drawing.Size(40, 16)
        Me.Lbl_NoMsgs.TabIndex = 22
        Me.Lbl_NoMsgs.Text = "# Sent"
        '
        'Btn_SendOne
        '
        Me.Btn_SendOne.Location = New System.Drawing.Point(280, 48)
        Me.Btn_SendOne.Name = "Btn_SendOne"
        Me.Btn_SendOne.TabIndex = 17
        Me.Btn_SendOne.Text = "Send One"
        '
        'Btn_SendMany
        '
        Me.Btn_SendMany.Location = New System.Drawing.Point(280, 16)
        Me.Btn_SendMany.Name = "Btn_SendMany"
        Me.Btn_SendMany.TabIndex = 16
        Me.Btn_SendMany.Text = "Send Many"
        '
        'Txt_Count
        '
        Me.Txt_Count.Location = New System.Drawing.Point(80, 16)
        Me.Txt_Count.Name = "Txt_Count"
        Me.Txt_Count.Size = New System.Drawing.Size(56, 20)
        Me.Txt_Count.TabIndex = 13
        Me.Txt_Count.Text = "10"
        '
        'Lbl_Count
        '
        Me.Lbl_Count.Location = New System.Drawing.Point(8, 16)
        Me.Lbl_Count.Name = "Lbl_Count"
        Me.Lbl_Count.Size = New System.Drawing.Size(40, 23)
        Me.Lbl_Count.TabIndex = 12
        Me.Lbl_Count.Text = "Count"
        '
        'Txt_Interval
        '
        Me.Txt_Interval.Location = New System.Drawing.Point(208, 16)
        Me.Txt_Interval.Name = "Txt_Interval"
        Me.Txt_Interval.Size = New System.Drawing.Size(56, 20)
        Me.Txt_Interval.TabIndex = 15
        Me.Txt_Interval.Text = "500"
        '
        'Lbl_Interval
        '
        Me.Lbl_Interval.Location = New System.Drawing.Point(152, 16)
        Me.Lbl_Interval.Name = "Lbl_Interval"
        Me.Lbl_Interval.Size = New System.Drawing.Size(48, 23)
        Me.Lbl_Interval.TabIndex = 14
        Me.Lbl_Interval.Text = "Interval"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txt_SeqNo)
        Me.GroupBox1.Controls.Add(Me.Lbl_SeqNo)
        Me.GroupBox1.Controls.Add(Me.Btn_SendMany)
        Me.GroupBox1.Controls.Add(Me.Txt_Interval)
        Me.GroupBox1.Controls.Add(Me.Txt_Count)
        Me.GroupBox1.Controls.Add(Me.Lbl_Count)
        Me.GroupBox1.Controls.Add(Me.Txt_MessageSentCount)
        Me.GroupBox1.Controls.Add(Me.Lbl_NoMsgs)
        Me.GroupBox1.Controls.Add(Me.Btn_SendOne)
        Me.GroupBox1.Controls.Add(Me.Lbl_Interval)
        Me.GroupBox1.Location = New System.Drawing.Point(0, 272)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(368, 80)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        '
        'Txt_SeqNo
        '
        Me.Txt_SeqNo.Location = New System.Drawing.Point(80, 48)
        Me.Txt_SeqNo.Name = "Txt_SeqNo"
        Me.Txt_SeqNo.Size = New System.Drawing.Size(56, 20)
        Me.Txt_SeqNo.TabIndex = 25
        Me.Txt_SeqNo.Text = ""
        '
        'Lbl_SeqNo
        '
        Me.Lbl_SeqNo.Location = New System.Drawing.Point(8, 48)
        Me.Lbl_SeqNo.Name = "Lbl_SeqNo"
        Me.Lbl_SeqNo.Size = New System.Drawing.Size(40, 23)
        Me.Lbl_SeqNo.TabIndex = 24
        Me.Lbl_SeqNo.Text = "Seq #"
        '
        'RendezvousCMSender
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 437)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Grp_Box3)
        Me.Controls.Add(Me.Grp_Box1)
        Me.Controls.Add(Me.Grp_Box2)
        Me.Name = "RendezvousCMSender"
        Me.Text = "Rendezvous CmSend application using .NET Library"
        Me.Grp_Box3.ResumeLayout(False)
        Me.Grp_Box1.ResumeLayout(False)
        Me.Grp_Box2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Global data shared among several action routines

    ' The transport that we will use to contact the daemon
    Dim transport As TIBCO.Rendezvous.Transport

    ' The cm transport we will use for certified messages
    Dim cmtransport As TIBCO.Rendezvous.CMTransport

    ' A timer object we will use to send multiple messages
    Dim timer As System.Timers.Timer

    ' A message object
    Dim msg As TIBCO.Rendezvous.CMMessage

    ' This will be the timer interval in seconds
    Dim interval As Double

    ' We will use this to track progress when sending multiple messages.
    Dim msgcount As Long
    '**********************************************************
    ' This subroutine is invoked when VB.NET tries to load our form.
    ' We will open the RV system, set up for dispatching events,
    ' and set up access to buttons and textboxes.

    Private Sub RendezvousCMSender_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'First, open the RV system.  This method creates all the underlying
        ' mechanisms that will be used to handle events and send messages.
        TIBCO.Rendezvous.Environment.Open()

        ' Create the message object we'll use for sending messages in
        ' the SendOne_Click routine.  We can re-use this object for all
        ' our send actions.
        msg = New TIBCO.Rendezvous.CMMessage

        ' Call the routines to set colors and buttons
        Enable_Create_Transport()
        Disable_Destroy_Transport()

    End Sub
    '**********************************************************
    ' This routine is executed if the user closes the form.
    ' It executes the Exit button routine before quitting.
    Private Sub RendezvousCMSender_Unload(ByVal Cancel As Integer)
        End
    End Sub
    '**********************************************************
    ' The "EXIT" button invokes this subroutine.
    ' If needed, we clean up RV stuff and then exit the application.
    Private Sub Btn_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Exit.Click
        ' Before we go, let's clean up.

        Btn_DestroyXport_Click(Me, e) ' This subroutine will do the transport cleanup.

        ' Close and free up the RV mechanisms.  This method destroys
        ' any currently valid Tibrv objects, in the proper order,
        ' allowing any active callbacks to complete.
        ' Close and free up the RV mechanisms.
        TIBCO.Rendezvous.Environment.Close()
        End
    End Sub
    '**********************************************************
    ' This routine fires when the create transport button is clicked
    ' The values are taken from the repective text boxes in GUI

    Private Sub Btn_CreateXport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CreateXport.Click

        ' The other parameters may be null or absent.  If the cmname
        ' parameter is null, RV supplies a unique non-reusable name.

        'If the ledgerfilename is null then we use memory based ledger file
        'else we create the file based ledger file with the old messages require flag set to true.
        'If the CMname is null then we need to specify vbNull for CMname and false for Syncledger

        Try

            transport = New TIBCO.Rendezvous.NetTransport(Txt_Service.Text, Txt_Network.Text, Txt_Daemon.Text)

            If Txt_LedgerFileName.Text = vbNullString Then

                If Txt_CmName.Text = vbNullString Then
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, vbNull, False)
                Else
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, Txt_CmName.Text, True)
                End If

            Else
                If Txt_CmName.Text = vbNullString Then
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, vbNull, False, Txt_LedgerFileName.Text, True)
                Else
                    cmtransport = New TIBCO.Rendezvous.CMTransport(transport, Txt_CmName.Text, True, Txt_LedgerFileName.Text, True)
                End If
            End If

            Txt_MessageSentCount.Text = 0          ' Initialize sent count for this transport
            Txt_SeqNo.Text = ""             ' Clear the sequence number
            Enable_Destroy_Transport()  ' Allow transport destroy, lis add/disallow/allow
            Disable_Create_Transport()  ' Lock options, disable create

        Catch exception As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Create CM Transport,  Reason :  " + exception.Message)

        End Try


    End Sub
    '**********************************************************
    ' The "Destroy Transport" button invokes this routine.
    ' We undo the setup here and clean up RV objects.

    Private Sub Btn_DestroyXport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DestroyXport.Click
        ' Destroy our transport and set to nothing.
        If Not cmtransport Is Nothing Then
            cmtransport.Destroy()
            cmtransport = Nothing
        End If

        If Not transport Is Nothing Then
            transport.Destroy()
            transport = Nothing
        End If

        '****************************************************************
        ' Everything else in this function is not directly related to RV.

        msgcount = 0                ' Reset our messages-to-send counter to zero.
        Txt_ListenerCMName.Clear()  ' Reset our pre-registered listener name to null.
        ' Disable the "Destroy Transport" button - we do not have something to destroy
        Enable_Create_Transport()
        Disable_Destroy_Transport()

    End Sub
    '**********************************************************
    ' The "Add Listener" button invokes this subroutine.

    Private Sub Btn_AddListener_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AddListener.Click
        ' To pre-register a cm listener with our cm transport,
        ' we use the add listener method.  This method requires
        ' the cm name of the listener and the (non-wildcard)
        ' subject.  Here we use the subject entered in the
        ' message subject text box.  This method is illegal while
        ' the listener is disallowed.
        If Txt_ListenerCMName.Text = vbNullString Then
            MessageBox.Show("You must enter a valid CM name for Listener", "Entry Error", _
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        Else
            cmtransport.AddListener(Txt_ListenerCMName.Text, Txt_Subject.Text)
            Lbl_ListenerAction.Text = "Added"
        End If

    End Sub
    '**********************************************************
    ' The "Allow Listener" button invokes this subroutine.

    Private Sub Btn_AllowListener_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AllowListener.Click
        ' To permit a certified listener to create an agreement
        ' with our cm transport, we use the allow listener
        ' method.  This method explicit overrides any previous
        ' disallow listener execution for the listener cmname.

        If Txt_ListenerCMName.Text = vbNullString Then
            MessageBox.Show("You must enter a valid CM name for Listener", "Entry Error", _
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        Else
            cmtransport.AllowListener(Txt_ListenerCMName.Text)
            Lbl_ListenerAction.Text = "Allowed"
        End If

    End Sub
    '**********************************************************
    ' The "Disallow Listener" button invokes this subroutine.

    Private Sub Btn_DisallowListener_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DisallowListener.Click
        ' If we want to prevent the listener from receiving certified
        ' messages from our cm transport, we use the disallow method.
        ' Any existing certified agreement with the specified listener
        ' is terminated, and the listener is not allowed to create
        ' a new agreement.  The listener may still receive messages,
        ' but they will not be certified.  When a listener is first
        ' notified that it is disallowed, the message may be lost by
        ' the listener if it did not previously have an agreement.

        If Txt_ListenerCMName.Text = vbNullString Then
            MessageBox.Show("You must enter a valid CM name for Listener", "Entry Error", _
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        Else
            cmtransport.DisallowListener(Txt_ListenerCMName.Text)
            Lbl_ListenerAction.Text = "Disallowed"
        End If


    End Sub
    '**********************************************************
    ' This subroutine is invoked when the user clicks the "Send Many"
    ' button.  To accomplish sending many messages, we are going to
    ' create an repeating timer and have the timer's callback
    ' routine send a message each time it is called.

    Private Sub Btn_SendMany_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SendMany.Click
        ' Make a note of how many times we should send this msg.
        msgcount = Txt_Count.Text

        ' Get the timer interval.
        interval = Txt_Interval.Text

        ' If the count is greater than zero, send one message immediately
        ' using the SendOne button routine and decrement the counter.
        If (msgcount > 0) Then
            Btn_SendOne_Click(Me, e)
            msgcount = msgcount - 1
        End If

        ' If the counter is still greater than one, set up a timer with the
        ' interval specified on the form.  The remaining messages will be
        ' sent each time the timer is fired.
        If msgcount > 0 Then
            timer = New System.Timers.Timer(interval)
            AddHandler timer.Elapsed, AddressOf OnTimer
            timer.Enabled = True
            Disable_Send_Many()
        End If

    End Sub
    '**********************************************************
    ' This subroutine is invoked when the user clicks the "Send One"
    ' button.  We put the data into the message and then use our
    ' transport to send it.

    Private Sub Btn_SendOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SendOne.Click
        ' Reset the message in case it's been used before.  This removes
        ' all fields from a message and also the send subject.
        msg.Reset()

        ' Add the field to the msg.  We're doing a little data parsing
        ' here, specifying a DATETIME type if the data is recognizable by
        ' VB as a date, an I32 long integer type if it's a numeric value
        ' with no decimal point, an F62 double precision if it's numeric
        ' with a decimal point, or defaulting to a STRING type otherwise.
        ' If both the field name and the value are empty, we'll skip the
        ' field and send the message with no fields.

        If IsNumeric(Txt_FieldValue.Text) Then
            If InStr(Txt_FieldValue.Text, ".") = 0 Then
                ' If it's a numeric string with no decimal point, add as I32
                msg.AddField(Txt_FieldName.Text, CInt(Txt_FieldValue.Text))
            Else
                ' If it's numeric with decimal point, add as F64
                msg.AddField(Txt_FieldName.Text, CDbl(Txt_FieldValue.Text))
            End If
        ElseIf IsDate(Txt_FieldValue.Text) Then
            ' If the field is a recognizable date, we'll add it as a date
            msg.AddField(Txt_FieldName.Text, CDate(Txt_FieldValue.Text))

        ElseIf Txt_FieldValue.Text = vbNullString Then
            ' If the text is null string, and there is a field name,
            ' substitute explicit empty string.  Null is not a valid
            ' field value.
            If Txt_FieldName.Text <> vbNullString Then msg.AddField(Txt_FieldName.Text, "")
        Else
            ' It's not numeric and not a date, so we'll add it as a string
            msg.AddField(Txt_FieldName.Text, Txt_FieldValue.Text)
        End If

        ' Set the subject we will use to send this msg.
        Try

            msg.SendSubject = Txt_Subject.Text

            ' Pass the message to the transport to get it sent.
            cmtransport.Send(msg)


            ' Display the sequence number of the message.  The value is
            ' returned as a TibrvInt64 object, so we use the appropriate
            ' method to obtain it as an unsigned string.
            Txt_SeqNo.Text = msg.SequenceNumber.ToString

            ' Count the message we have just sent.
            Txt_MessageSentCount.Text = Txt_MessageSentCount.Text + 1

        Catch ex As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Send Message,  Reason :  " + ex.Message)

        End Try


    End Sub
    '**********************************************************
    ' This callback subroutine is invoked each time the recurring
    ' timer is fired.  So, it should be invoked about once per
    ' interval (1 second default) WHILE we are busy sending many
    ' messages.  We are going to call the "SendOne_Click" function
    ' when we need the actual message sent because it does exactly
    ' what we need done each time we need to send a msg.

    Public Sub OnTimer(ByVal source As Object, ByVal e As ElapsedEventArgs)
        ' When the counter reaches 0 we are done with this request.  We destroy
        ' the timer so we won't be called again.  This stops the timer.  Enable
        ' the send many function so we can call it again.

        If (msgcount <= 0) Then
            timer.Enabled = False
            Enable_Send_Many()
            Exit Sub
        End If

        ' Decrement our count of messages left to send.
        msgcount = msgcount - 1

        ' Call SendOne's routine to send a single message for us.
        Btn_SendOne_Click(Me, e)

    End Sub
    '============================================================
    ' This routine sets the buttons and colors for when we have
    ' destroyed or not yet created a transport.  At this point,
    ' we can set the options for the transport and can create it.
    Private Sub Enable_Create_Transport()
        ' Unlock the text boxes so that the user can change the transport
        ' arguments if desired.  Restore the color.
        Txt_Service.Enabled = True
        Txt_Network.Enabled = True
        Txt_Daemon.Enabled = True
        Txt_LedgerFileName.Enabled = True
        Txt_CmName.Enabled = True
        Lbl_Service.Enabled = True
        Lbl_Network.Enabled = True
        Lbl_Daemon.Enabled = True
        Lbl_Ledger.Enabled = True
        Lbl_CMName.Enabled = True

        ' Change button states (can/cannot be pressed) and colors to disallow
        ' operations that are no longer possible after destroying support RV.
        Btn_CreateXport.Enabled = True       ' We can now call the initialization function.
        Btn_SendMany.Enabled = False    ' Can't send messages now.
        Btn_SendOne.Enabled = False     ' Can't send messages now.

        ' Allow changes to the send counter and interval-
        ' With no transport, timer is not running.
        Txt_MessageSentCount.Enabled = True
        Txt_Count.Enabled = True
        Txt_Interval.Enabled = True
        Lbl_Interval.Enabled = True


        ' Don't allow listener add/allow/disallow with no cm transport.
        Btn_AddListener.Enabled = False
        Btn_AllowListener.Enabled = False
        Btn_DisallowListener.Enabled = False
    End Sub

    '**********************************************************
    ' This routine disables the button for the
    ' transport destroy function when we have destroyed or not
    ' yet created a transport.

    Private Sub Disable_Create_Transport()  ' Lock options, disable create
        ' Disable the following text boxes, since changing them will
        ' have no effect unless the transport is recreated.
        Txt_Service.Enabled = False
        Txt_Network.Enabled = False
        Txt_Daemon.Enabled = False
        Lbl_Service.Enabled = False
        Lbl_Network.Enabled = False
        Lbl_Daemon.Enabled = False

        ' Disable the "Create Transport" button
        Btn_CreateXport.Enabled = False

        ' Allow listener add/allow/disallow with no cm transport.
        Btn_AddListener.Enabled = True
        Btn_AllowListener.Enabled = True
        Btn_DisallowListener.Enabled = True
        Enable_Send_Many()
        Btn_SendOne.Enabled = True

    End Sub

    '**********************************************************
    ' This routine enables the button when we have created
    ' a transport and listener.
    Private Sub Enable_Destroy_Transport()

        ' Enable the "Destroy Transport" button - we now have something to destroy
        Btn_DestroyXport.Enabled = True

    End Sub

    '============================================================
    ' This routine sets the buttons and colors for when we have
    ' destroyed or not yet created a transport.
    Private Sub Disable_Destroy_Transport()
        Btn_DestroyXport.Enabled = False     ' We can't destroy what doesn't exist
    End Sub
    '============================================================
    ' This routine enables the textboxes and button for Send Many.

    Private Sub Enable_Send_Many()
        ' Allow changes to the "Send Count" and interval.
        Txt_Count.Enabled = True
        Lbl_Count.Enabled = True
        Txt_Interval.Enabled = True
        Lbl_Interval.Enabled = True

        ' Allow the "Send Many" button to work.
        Btn_SendMany.Enabled = True

    End Sub
    '============================================================
    ' This routine disables the textboxes and button for Send Many
    ' so they cannot be changed while the option is active.

    Private Sub Disable_Send_Many()
        Txt_Count.Enabled = False
        Lbl_Count.Enabled = False
        Txt_Interval.Enabled = False
        Lbl_Interval.Enabled = False

        ' Disable the "Send Many" button.  We do this mostly because
        ' we are using a global variable for the timer object...
        Btn_SendMany.Enabled = False

    End Sub
    '**********************************************************
    'If the RendezvousCMSender is closed using the X button at the 
    'top of dialog box then we handle it here.

    Private Sub RendezvousCMSender_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        Btn_Exit_Click(Me, New EventArgs)
    End Sub
End Class
