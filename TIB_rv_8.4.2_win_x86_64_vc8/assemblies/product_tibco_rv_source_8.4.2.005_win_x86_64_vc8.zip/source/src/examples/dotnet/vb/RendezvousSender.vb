' Copyright (c) 2000-$Date: 2013-12-20 09:20:06 -0800 (Fri, 20 Dec 2013) $ TIBCO Software Inc.
' All rights reserved.
' TIB/Rendezvous is protected under US Patent No. 5,187,787.
' For more information, please contact:
' TIBCO Software Inc., Palo Alto, California, USA

'***************************************************************
'
'  Example TibrvSend program.
'  -------------------------
'
' This program demonstrates the use of several features of the
' RV .NET interface from within VB.NET
'
' The program presents a simple form that allows control of
' a simple RV publisher.  Default values are provided for all
' fields which allows the application to be operated by just
' pressing the various control buttons.  For users who wish
' to try more sophisticated configurations, the Form has fields
' that allow customization similar to the C examples.
'
' The code does not make any effort to catch errors.  If errors
' are encountered, VB.NET will pop up a message box with
' details of the problem.  The most likely reason for errors
' would be incorrectly specified transport parameters
' (i.e. Service, Network and Daemon)
'
' We have made some effort to allow only reasonable calls to be
' made by disabling buttons and text boxes when their use is
' not meaningful or useful.  For example, we disable the send
' buttons when no RV mechanism exists, or the send count while
' a "Send Many" operation is in progress.
'
' We do allow the message field information to be changed at
' any time.  This makes it easy to change messages on the fly
' while sending a stream of messages.
'
' One last note: Please consider any programming errors you
' find to have been deliberately included as an exercise...
'
'***************************************************************
Imports System.Threading
Imports System.Timers

Public Class RendezvousSender
    Inherits System.Windows.Forms.Form

    'Global data shared among several action routines
    ' The transport that we will use to contact the daemon
    Dim transport As TIBCO.Rendezvous.NetTransport

    ' Timer for send many option
    Dim timer As System.Timers.Timer

    ' A message object
    Dim msg As TIBCO.Rendezvous.Message

    ' This will be the timer interval in seconds
    Dim interval As Double

    ' We will use this to track progress when sending multiple messages.
    Dim msgcount As Long

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Btn_Exit As System.Windows.Forms.Button
    Friend WithEvents Btn_DestroyXport As System.Windows.Forms.Button
    Friend WithEvents Btn_CreateXport As System.Windows.Forms.Button
    Friend WithEvents Lbl_Subject As System.Windows.Forms.Label
    Friend WithEvents Lbl_Daemon As System.Windows.Forms.Label
    Friend WithEvents Lbl_Network As System.Windows.Forms.Label
    Friend WithEvents Lbl_Service As System.Windows.Forms.Label
    Friend WithEvents Lbl_Count As System.Windows.Forms.Label
    Friend WithEvents Txt_Count As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Interval As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Interval As System.Windows.Forms.Label
    Friend WithEvents Btn_SendMany As System.Windows.Forms.Button
    Friend WithEvents Btn_SendOne As System.Windows.Forms.Button
    Friend WithEvents Lbl_NoMsgs As System.Windows.Forms.Label
    Friend WithEvents Grp_Box2 As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_Box1 As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_Box3 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_FieldName As System.Windows.Forms.Label
    Friend WithEvents Lbl_FieldValue As System.Windows.Forms.Label
    Friend WithEvents Txt_FieldName As System.Windows.Forms.TextBox
    Friend WithEvents Txt_FieldValue As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Subject As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Daemon As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Network As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Service As System.Windows.Forms.TextBox
    Friend WithEvents Txt_MessageSentCount As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Txt_Subject = New System.Windows.Forms.TextBox
        Me.Txt_Daemon = New System.Windows.Forms.TextBox
        Me.Txt_Network = New System.Windows.Forms.TextBox
        Me.Txt_Service = New System.Windows.Forms.TextBox
        Me.Lbl_Subject = New System.Windows.Forms.Label
        Me.Lbl_Daemon = New System.Windows.Forms.Label
        Me.Lbl_Network = New System.Windows.Forms.Label
        Me.Lbl_Service = New System.Windows.Forms.Label
        Me.Btn_Exit = New System.Windows.Forms.Button
        Me.Btn_DestroyXport = New System.Windows.Forms.Button
        Me.Btn_CreateXport = New System.Windows.Forms.Button
        Me.Lbl_Count = New System.Windows.Forms.Label
        Me.Txt_Count = New System.Windows.Forms.TextBox
        Me.Txt_Interval = New System.Windows.Forms.TextBox
        Me.Lbl_Interval = New System.Windows.Forms.Label
        Me.Grp_Box2 = New System.Windows.Forms.GroupBox
        Me.Txt_MessageSentCount = New System.Windows.Forms.TextBox
        Me.Lbl_NoMsgs = New System.Windows.Forms.Label
        Me.Btn_SendOne = New System.Windows.Forms.Button
        Me.Btn_SendMany = New System.Windows.Forms.Button
        Me.Grp_Box1 = New System.Windows.Forms.GroupBox
        Me.Grp_Box3 = New System.Windows.Forms.GroupBox
        Me.Txt_FieldValue = New System.Windows.Forms.TextBox
        Me.Txt_FieldName = New System.Windows.Forms.TextBox
        Me.Lbl_FieldValue = New System.Windows.Forms.Label
        Me.Lbl_FieldName = New System.Windows.Forms.Label
        Me.Grp_Box2.SuspendLayout()
        Me.Grp_Box1.SuspendLayout()
        Me.Grp_Box3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Txt_Subject
        '
        Me.Txt_Subject.Location = New System.Drawing.Point(80, 24)
        Me.Txt_Subject.Name = "Txt_Subject"
        Me.Txt_Subject.Size = New System.Drawing.Size(248, 20)
        Me.Txt_Subject.TabIndex = 11
        Me.Txt_Subject.Text = "VB.NET.example.reliable"
        '
        'Txt_Daemon
        '
        Me.Txt_Daemon.Location = New System.Drawing.Point(80, 80)
        Me.Txt_Daemon.Name = "Txt_Daemon"
        Me.Txt_Daemon.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Daemon.TabIndex = 6
        Me.Txt_Daemon.Text = ""
        '
        'Txt_Network
        '
        Me.Txt_Network.Location = New System.Drawing.Point(80, 48)
        Me.Txt_Network.Name = "Txt_Network"
        Me.Txt_Network.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Network.TabIndex = 4
        Me.Txt_Network.Text = ""
        '
        'Txt_Service
        '
        Me.Txt_Service.Location = New System.Drawing.Point(80, 16)
        Me.Txt_Service.Name = "Txt_Service"
        Me.Txt_Service.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Service.TabIndex = 2
        Me.Txt_Service.Text = ""
        '
        'Lbl_Subject
        '
        Me.Lbl_Subject.Location = New System.Drawing.Point(8, 24)
        Me.Lbl_Subject.Name = "Lbl_Subject"
        Me.Lbl_Subject.Size = New System.Drawing.Size(48, 24)
        Me.Lbl_Subject.TabIndex = 10
        Me.Lbl_Subject.Text = "Subject"
        '
        'Lbl_Daemon
        '
        Me.Lbl_Daemon.Location = New System.Drawing.Point(8, 80)
        Me.Lbl_Daemon.Name = "Lbl_Daemon"
        Me.Lbl_Daemon.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Daemon.TabIndex = 5
        Me.Lbl_Daemon.Text = "Daemon"
        '
        'Lbl_Network
        '
        Me.Lbl_Network.Location = New System.Drawing.Point(8, 48)
        Me.Lbl_Network.Name = "Lbl_Network"
        Me.Lbl_Network.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Network.TabIndex = 3
        Me.Lbl_Network.Text = "Network"
        '
        'Lbl_Service
        '
        Me.Lbl_Service.Location = New System.Drawing.Point(8, 16)
        Me.Lbl_Service.Name = "Lbl_Service"
        Me.Lbl_Service.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Service.TabIndex = 1
        Me.Lbl_Service.Text = "Service"
        '
        'Btn_Exit
        '
        Me.Btn_Exit.ForeColor = System.Drawing.Color.Firebrick
        Me.Btn_Exit.Location = New System.Drawing.Point(275, 80)
        Me.Btn_Exit.Name = "Btn_Exit"
        Me.Btn_Exit.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Exit.TabIndex = 9
        Me.Btn_Exit.Text = "Exit"
        '
        'Btn_DestroyXport
        '
        Me.Btn_DestroyXport.Location = New System.Drawing.Point(235, 48)
        Me.Btn_DestroyXport.Name = "Btn_DestroyXport"
        Me.Btn_DestroyXport.Size = New System.Drawing.Size(112, 24)
        Me.Btn_DestroyXport.TabIndex = 8
        Me.Btn_DestroyXport.Text = "Destroy Transport"
        '
        'Btn_CreateXport
        '
        Me.Btn_CreateXport.Location = New System.Drawing.Point(235, 16)
        Me.Btn_CreateXport.Name = "Btn_CreateXport"
        Me.Btn_CreateXport.Size = New System.Drawing.Size(112, 24)
        Me.Btn_CreateXport.TabIndex = 7
        Me.Btn_CreateXport.Text = "Create Transport"
        '
        'Lbl_Count
        '
        Me.Lbl_Count.Location = New System.Drawing.Point(8, 56)
        Me.Lbl_Count.Name = "Lbl_Count"
        Me.Lbl_Count.Size = New System.Drawing.Size(40, 23)
        Me.Lbl_Count.TabIndex = 12
        Me.Lbl_Count.Text = "Count"
        '
        'Txt_Count
        '
        Me.Txt_Count.Location = New System.Drawing.Point(80, 56)
        Me.Txt_Count.Name = "Txt_Count"
        Me.Txt_Count.Size = New System.Drawing.Size(56, 20)
        Me.Txt_Count.TabIndex = 13
        Me.Txt_Count.Text = "10"
        '
        'Txt_Interval
        '
        Me.Txt_Interval.Location = New System.Drawing.Point(208, 56)
        Me.Txt_Interval.Name = "Txt_Interval"
        Me.Txt_Interval.Size = New System.Drawing.Size(56, 20)
        Me.Txt_Interval.TabIndex = 15
        Me.Txt_Interval.Text = "1"
        '
        'Lbl_Interval
        '
        Me.Lbl_Interval.Location = New System.Drawing.Point(152, 56)
        Me.Lbl_Interval.Name = "Lbl_Interval"
        Me.Lbl_Interval.Size = New System.Drawing.Size(48, 23)
        Me.Lbl_Interval.TabIndex = 14
        Me.Lbl_Interval.Text = "Interval"
        '
        'Grp_Box2
        '
        Me.Grp_Box2.Controls.Add(Me.Txt_MessageSentCount)
        Me.Grp_Box2.Controls.Add(Me.Lbl_NoMsgs)
        Me.Grp_Box2.Controls.Add(Me.Btn_SendOne)
        Me.Grp_Box2.Controls.Add(Me.Btn_SendMany)
        Me.Grp_Box2.Controls.Add(Me.Txt_Interval)
        Me.Grp_Box2.Controls.Add(Me.Lbl_Subject)
        Me.Grp_Box2.Controls.Add(Me.Lbl_Interval)
        Me.Grp_Box2.Controls.Add(Me.Txt_Count)
        Me.Grp_Box2.Controls.Add(Me.Lbl_Count)
        Me.Grp_Box2.Controls.Add(Me.Txt_Subject)
        Me.Grp_Box2.Location = New System.Drawing.Point(0, 128)
        Me.Grp_Box2.Name = "Grp_Box2"
        Me.Grp_Box2.Size = New System.Drawing.Size(360, 120)
        Me.Grp_Box2.TabIndex = 24
        Me.Grp_Box2.TabStop = False
        '
        'Txt_MessageSentCount
        '
        Me.Txt_MessageSentCount.Location = New System.Drawing.Point(208, 88)
        Me.Txt_MessageSentCount.Name = "Txt_MessageSentCount"
        Me.Txt_MessageSentCount.ReadOnly = True
        Me.Txt_MessageSentCount.Size = New System.Drawing.Size(56, 20)
        Me.Txt_MessageSentCount.TabIndex = 23
        Me.Txt_MessageSentCount.Text = "0"
        '
        'Lbl_NoMsgs
        '
        Me.Lbl_NoMsgs.Location = New System.Drawing.Point(72, 88)
        Me.Lbl_NoMsgs.Name = "Lbl_NoMsgs"
        Me.Lbl_NoMsgs.Size = New System.Drawing.Size(120, 16)
        Me.Lbl_NoMsgs.TabIndex = 22
        Me.Lbl_NoMsgs.Text = "# of Messages Sent"
        '
        'Btn_SendOne
        '
        Me.Btn_SendOne.Location = New System.Drawing.Point(272, 88)
        Me.Btn_SendOne.Name = "Btn_SendOne"
        Me.Btn_SendOne.TabIndex = 17
        Me.Btn_SendOne.Text = "Send One"
        '
        'Btn_SendMany
        '
        Me.Btn_SendMany.Location = New System.Drawing.Point(272, 56)
        Me.Btn_SendMany.Name = "Btn_SendMany"
        Me.Btn_SendMany.TabIndex = 16
        Me.Btn_SendMany.Text = "Send Many"
        '
        'Grp_Box1
        '
        Me.Grp_Box1.Controls.Add(Me.Btn_Exit)
        Me.Grp_Box1.Controls.Add(Me.Btn_DestroyXport)
        Me.Grp_Box1.Controls.Add(Me.Btn_CreateXport)
        Me.Grp_Box1.Controls.Add(Me.Txt_Service)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Daemon)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Network)
        Me.Grp_Box1.Controls.Add(Me.Lbl_Service)
        Me.Grp_Box1.Controls.Add(Me.Txt_Daemon)
        Me.Grp_Box1.Controls.Add(Me.Txt_Network)
        Me.Grp_Box1.Location = New System.Drawing.Point(0, 8)
        Me.Grp_Box1.Name = "Grp_Box1"
        Me.Grp_Box1.Size = New System.Drawing.Size(360, 112)
        Me.Grp_Box1.TabIndex = 25
        Me.Grp_Box1.TabStop = False
        '
        'Grp_Box3
        '
        Me.Grp_Box3.Controls.Add(Me.Txt_FieldValue)
        Me.Grp_Box3.Controls.Add(Me.Txt_FieldName)
        Me.Grp_Box3.Controls.Add(Me.Lbl_FieldValue)
        Me.Grp_Box3.Controls.Add(Me.Lbl_FieldName)
        Me.Grp_Box3.Location = New System.Drawing.Point(0, 256)
        Me.Grp_Box3.Name = "Grp_Box3"
        Me.Grp_Box3.Size = New System.Drawing.Size(360, 100)
        Me.Grp_Box3.TabIndex = 26
        Me.Grp_Box3.TabStop = False
        '
        'Txt_FieldValue
        '
        Me.Txt_FieldValue.Location = New System.Drawing.Point(88, 56)
        Me.Txt_FieldValue.Name = "Txt_FieldValue"
        Me.Txt_FieldValue.Size = New System.Drawing.Size(240, 20)
        Me.Txt_FieldValue.TabIndex = 21
        Me.Txt_FieldValue.Text = "Rendezvous Sender Example Message Value"
        '
        'Txt_FieldName
        '
        Me.Txt_FieldName.Location = New System.Drawing.Point(88, 24)
        Me.Txt_FieldName.Name = "Txt_FieldName"
        Me.Txt_FieldName.Size = New System.Drawing.Size(240, 20)
        Me.Txt_FieldName.TabIndex = 19
        Me.Txt_FieldName.Text = "Text Field"
        '
        'Lbl_FieldValue
        '
        Me.Lbl_FieldValue.Location = New System.Drawing.Point(8, 56)
        Me.Lbl_FieldValue.Name = "Lbl_FieldValue"
        Me.Lbl_FieldValue.Size = New System.Drawing.Size(64, 16)
        Me.Lbl_FieldValue.TabIndex = 20
        Me.Lbl_FieldValue.Text = "Field Value"
        '
        'Lbl_FieldName
        '
        Me.Lbl_FieldName.Location = New System.Drawing.Point(8, 24)
        Me.Lbl_FieldName.Name = "Lbl_FieldName"
        Me.Lbl_FieldName.Size = New System.Drawing.Size(64, 16)
        Me.Lbl_FieldName.TabIndex = 18
        Me.Lbl_FieldName.Text = "Field Name"
        '
        'RendezvousSender
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(367, 373)
        Me.Controls.Add(Me.Grp_Box3)
        Me.Controls.Add(Me.Grp_Box1)
        Me.Controls.Add(Me.Grp_Box2)
        Me.Name = "RendezvousSender"
        Me.Text = "Rendezvous Sender Application using .NET library"
        Me.Grp_Box2.ResumeLayout(False)
        Me.Grp_Box1.ResumeLayout(False)
        Me.Grp_Box3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' This routine fires when the create transport button is clicked
    ' The values are taken from the repective text boxes in GUI
    Private Sub Btn_CreateXport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CreateXport.Click

        Try
            transport = New TIBCO.Rendezvous.NetTransport(Txt_Service.Text, Txt_Network.Text, Txt_Daemon.Text)
            Disable_Create_Transport()  ' Disable create transport function
            Enable_Destroy_Transport()  ' Enable destroy transport function
            Enable_Send_Many()
            Btn_SendOne.Enabled = True
            Txt_MessageSentCount.Text = 0

        Catch exception As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Create Transport,  Reason :  " + exception.Message)

        End Try

    End Sub
    '**********************************************************
    ' The "Destroy Transport" button invokes this routine.
    ' We undo the setup here and clean up RV objects.

    Private Sub Btn_DestroyXport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DestroyXport.Click

        ' Destroy our transport and set to nothing.
        If Not transport Is Nothing Then
            transport.Destroy()
            transport = Nothing
        End If

        msgcount = 0                ' Reset our messages-to-send counter to zero.
        ' Disable the "Destroy Transport" button - we do not have something to destroy
        Disable_Destroy_Transport()
        Enable_Create_Transport()

    End Sub
    '**********************************************************
    ' The "Exit" button invokes this routine.
    ' Do the Environment close here.

    Private Sub Btn_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Exit.Click

        ' This subroutine will do the transport cleanup.
        ' Close and free up the RV mechanisms.
        TIBCO.Rendezvous.Environment.Close()
        End

    End Sub
    '**********************************************************
    ' The "Send Many" button invokes this routine.
    ' To accomplish sending many messages, we are going to
    ' create an repeating timer and have the timer's callback
    ' routine send a message each time it is called.

    Private Sub Btn_SendMany_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SendMany.Click
        ' Make a note of how many times we should send this msg.
        msgcount = Txt_Count.Text

        ' Get the timer interval.
        interval = Txt_Interval.Text

        ' If the count is greater than zero, send one message immediately
        ' using the SendOne button routine and decrement the counter.
        If (msgcount > 0) Then
            Btn_SendOne_Click(Me, e)
            msgcount = msgcount - 1
        End If

        ' If the counter is still greater than one, set up a timer with the
        ' interval specified on the form.  The remaining messages will be
        ' sent each time the timer is fired.
        If msgcount > 0 Then
            timer = New System.Timers.Timer(interval)
            AddHandler timer.Elapsed, AddressOf OnTimer
            timer.Enabled = True
            Disable_Send_Many()
        End If
    End Sub
    '**********************************************************
    ' This callback subroutine is invoked each time the recurring
    ' timer is fired.  So, it should be invoked about once per
    ' interval (1 second default) WHILE we are busy sending many
    ' messages.  We are going to call the "SendOne_Click" function
    ' when we need the actual message sent because it does exactly
    ' what we need done each time we need to send a msg.

    Public Sub OnTimer(ByVal source As Object, ByVal e As ElapsedEventArgs)
        ' When the counter reaches 0 we are done with this request.  We destroy
        ' the timer so we won't be called again.  This stops the timer.  Enable
        ' the send many function so we can call it again.

        If (msgcount <= 0) Then
            timer.Enabled = False
            Enable_Send_Many()
            Exit Sub
        End If

        ' Decrement our count of messages left to send.
        msgcount = msgcount - 1

        ' Call SendOne's routine to send a single message for us.
        Btn_SendOne_Click(Me, e)

    End Sub
    '**********************************************************
    ' This subroutine is invoked when the user clicks the "Send One"
    ' button.  We put the data into the message and then use our
    ' transport to send it.

    Private Sub Btn_SendOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SendOne.Click

        ' Reset the message in case it's been used before.  This removes
        ' all fields from a message and also the send subject.
        msg.Reset()

        ' Add the field to the msg.  We're doing a little data parsing
        ' here, specifying a DATETIME type if the data is recognizable by
        ' VB as a date, an I32 long integer type if it's a numeric value
        ' with no decimal point, an F62 double precision if it's numeric
        ' with a decimal point, or defaulting to a STRING type otherwise.
        ' If both the field name and the value are empty, we'll skip the
        ' field and send the message with no fields.

        If IsNumeric(Txt_FieldValue.Text) Then
            If InStr(Txt_FieldValue.Text, ".") = 0 Then
                ' If it's a numeric string with no decimal point, add as I32
                msg.AddField(Txt_FieldName.Text, CInt(Txt_FieldValue.Text))
            Else
                ' If it's numeric with decimal point, add as F64
                msg.AddField(Txt_FieldName.Text, CDbl(Txt_FieldValue.Text))
            End If
        ElseIf IsDate(Txt_FieldValue.Text) Then
            ' If the field is a recognizable date, we'll add it as a date
            msg.AddField(Txt_FieldName.Text, CDate(Txt_FieldValue.Text))

        ElseIf Txt_FieldValue.Text = vbNullString Then
            ' If the text is null string, and there is a field name,
            ' substitute explicit empty string.  Null is not a valid
            ' field value.
            If Txt_FieldName.Text <> vbNullString Then msg.AddField(Txt_FieldName.Text, "")
        Else
            ' It's not numeric and not a date, so we'll add it as a string
            msg.AddField(Txt_FieldName.Text, Txt_FieldValue.Text)
        End If

        Try

            ' Set the subject we will use to send this msg.
            msg.SendSubject = Txt_Subject.Text

            ' Pass the message to the transport to get it sent.
            transport.Send(msg)

            ' Count the message we have just sent.
            Txt_MessageSentCount.Text = Txt_MessageSentCount.Text + 1

        Catch ex As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Send Message,  Reason :  " + ex.Message)

        End Try


    End Sub
    '**********************************************************
    ' This subroutine is invoked when VB tries to load our form.
    ' We will open the RV system, access the queue objects,
    ' and set up access to buttons and textboxes.

    Private Sub RendezvousSender_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'initialise TIBCO Rendezvous machinery...
        TIBCO.Rendezvous.Environment.Open()
        msg = New TIBCO.Rendezvous.Message
        Enable_Create_Transport()
        Disable_Destroy_Transport()
        Disable_Send_Many()
        Btn_SendOne.Enabled = False
        transport = Nothing
    End Sub

    '**********************************************************
    ' This routine enables the button for create transport function
    ' when we have destroyed or not yet created a transport.
    ' At this point, we can set the options for the transport 
    ' and can create the transport.
    Private Sub Enable_Create_Transport()
        ' Enable the following text boxes.  The user may want to change them
        ' in preparation for creating another listener.  Restore the color.
        Txt_Service.Enabled = True
        Txt_Network.Enabled = True
        Txt_Daemon.Enabled = True
        Txt_Subject.Enabled = True
        Lbl_Service.Enabled = True
        Lbl_Network.Enabled = True
        Lbl_Daemon.Enabled = True
        Lbl_Subject.Enabled = True

        Disable_Send_Many()
        Btn_SendOne.Enabled = False

        ' Enable the "Create Transport" button - we may want to subscribe again
        Btn_CreateXport.Enabled = True
    End Sub

    '**********************************************************
    ' This routine disables the button when we have already created a
    ' transport.  At this point, we can create a listener or we
    ' can destroy the transport.
    Private Sub Disable_Create_Transport()
        ' Disable the following text boxes, since changing them will
        ' have no effect unless the transport is recreated.
        Txt_Service.Enabled = False
        Txt_Network.Enabled = False
        Txt_Daemon.Enabled = False
        Lbl_Service.Enabled = False
        Lbl_Network.Enabled = False
        Lbl_Daemon.Enabled = False

        ' Disable the "Create Transport" button
        Btn_CreateXport.Enabled = False
    End Sub

    '**********************************************************
    ' This routine enables the button when we have created
    ' a transport and listener.
    Private Sub Enable_Destroy_Transport()

        ' Enable the "Destroy Transport" button - we now have something to destroy
        Btn_DestroyXport.Enabled = True

    End Sub

    '**********************************************************
    ' This routine disables the button for the
    ' transport destroy function when we have destroyed or not
    ' yet created a transport.
    Private Sub Disable_Destroy_Transport()
        ' Disable the "Destroy Transport" button.  Nothing to destroy.
        Btn_DestroyXport.Enabled = False
    End Sub
    '============================================================
    ' This routine disables the textboxes and button for Send Many
    ' so they cannot be changed while the option is active.
    Private Sub Disable_Send_Many()
        Txt_Count.Enabled = False
        Lbl_Count.Enabled = False
        Txt_Interval.Enabled = False
        Lbl_Interval.Enabled = False

        ' Disable the "Send Many" button.  We do this mostly because
        ' we are using a global variable for the timer object...
        Btn_SendMany.Enabled = False
    End Sub

    '============================================================
    ' This routine enables the textboxes and button for Send Many.
    Private Sub Enable_Send_Many()
        ' Allow changes to the "Send Count" and interval.
        Txt_Count.Enabled = True
        Lbl_Count.Enabled = True
        Txt_Interval.Enabled = True
        Lbl_Interval.Enabled = True

        ' Allow the "Send Many" button to work.
        Btn_SendMany.Enabled = True

    End Sub
    '**********************************************************
    'If the RendezvousSender is closed using the X button at the 
    'top of dialog box then we handle it here.

    Private Sub RendezvousSender_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        Btn_Exit_Click(Me, New EventArgs)
    End Sub
End Class

