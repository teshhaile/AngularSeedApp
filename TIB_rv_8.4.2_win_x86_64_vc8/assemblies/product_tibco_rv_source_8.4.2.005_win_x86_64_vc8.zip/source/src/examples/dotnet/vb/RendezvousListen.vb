' Copyright (c) 2000-$Date: 2013-12-20 09:20:06 -0800 (Fri, 20 Dec 2013) $ TIBCO Software Inc.
' All rights reserved.
' TIB/Rendezvous is protected under US Patent No. 5,187,787.
' For more information, please contact:
' TIBCO Software Inc., Palo Alto, California, USA

'***************************************************************
'
'  Example RendezvousListen program.
'  ------------------------------
'
' This program demonstrates the use of several features of the
' RV .NET interface from within VisualBasic.NET .
'
' The program presents a simple form that allows control of
' a simple RV listener.  Default values are
' provided for all fields which allows the application to be
' operated by just pressing the various control buttons.  For
' users who wish to try more sophisticated configurations, the
' form has fields that allow customizations similar to the C
' examples.
'
' The code does not make any effort to catch errors.  If errors
' are encountered, VisualBasic.NET will pop up a message box with
' details of the problem.  The most likely reason for errors
' would be incorrectly specified transport parameters
' (i.e. Service, Network and Daemon)
'
' We have made some effort to allow only reasonable calls to be
' made by disabling buttons and text boxes when their use is
' not meaningful or useful.  For example, we disable the destroy
' transports button when no RV mechanism exists, or the subject
' while a listener is active.
'
' One last note: Please consider any programming errors you
' find to have been deliberately included as an exercise...
'
'***************************************************************

Public Class RendezvousListen
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Btn_CreateXport As System.Windows.Forms.Button
    Friend WithEvents Btn_DestroyXport As System.Windows.Forms.Button
    Friend WithEvents Btn_CreateListener As System.Windows.Forms.Button
    Friend WithEvents Btn_Exit As System.Windows.Forms.Button
    Friend WithEvents Btn_DestroyListener As System.Windows.Forms.Button
    Friend WithEvents Lbl_Service As System.Windows.Forms.Label
    Friend WithEvents Lbl_Network As System.Windows.Forms.Label
    Friend WithEvents Lbl_Daemon As System.Windows.Forms.Label
    Friend WithEvents Lbl_Subject As System.Windows.Forms.Label
    Friend WithEvents Lbl_MessagesReceived As System.Windows.Forms.Label
    Friend WithEvents Txt_Service As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Network As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Daemon As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Subject As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Message_Recvd As System.Windows.Forms.TextBox
    Friend WithEvents Btn_ClearMsgs As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_MsgCount As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Lbl_Service = New System.Windows.Forms.Label
        Me.Lbl_Network = New System.Windows.Forms.Label
        Me.Lbl_Daemon = New System.Windows.Forms.Label
        Me.Lbl_Subject = New System.Windows.Forms.Label
        Me.Lbl_MessagesReceived = New System.Windows.Forms.Label
        Me.Txt_Service = New System.Windows.Forms.TextBox
        Me.Txt_Network = New System.Windows.Forms.TextBox
        Me.Txt_Daemon = New System.Windows.Forms.TextBox
        Me.Txt_Subject = New System.Windows.Forms.TextBox
        Me.Txt_Message_Recvd = New System.Windows.Forms.TextBox
        Me.Btn_CreateXport = New System.Windows.Forms.Button
        Me.Btn_DestroyXport = New System.Windows.Forms.Button
        Me.Btn_CreateListener = New System.Windows.Forms.Button
        Me.Btn_Exit = New System.Windows.Forms.Button
        Me.Btn_DestroyListener = New System.Windows.Forms.Button
        Me.Btn_ClearMsgs = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Txt_MsgCount = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Lbl_Service
        '
        Me.Lbl_Service.Location = New System.Drawing.Point(16, 16)
        Me.Lbl_Service.Name = "Lbl_Service"
        Me.Lbl_Service.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Service.TabIndex = 0
        Me.Lbl_Service.Text = "Service"
        '
        'Lbl_Network
        '
        Me.Lbl_Network.Location = New System.Drawing.Point(16, 48)
        Me.Lbl_Network.Name = "Lbl_Network"
        Me.Lbl_Network.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Network.TabIndex = 1
        Me.Lbl_Network.Text = "Network"
        '
        'Lbl_Daemon
        '
        Me.Lbl_Daemon.Location = New System.Drawing.Point(16, 80)
        Me.Lbl_Daemon.Name = "Lbl_Daemon"
        Me.Lbl_Daemon.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Daemon.TabIndex = 2
        Me.Lbl_Daemon.Text = "Daemon"
        '
        'Lbl_Subject
        '
        Me.Lbl_Subject.Location = New System.Drawing.Point(16, 24)
        Me.Lbl_Subject.Name = "Lbl_Subject"
        Me.Lbl_Subject.Size = New System.Drawing.Size(56, 24)
        Me.Lbl_Subject.TabIndex = 3
        Me.Lbl_Subject.Text = "Subject"
        '
        'Lbl_MessagesReceived
        '
        Me.Lbl_MessagesReceived.Location = New System.Drawing.Point(16, 16)
        Me.Lbl_MessagesReceived.Name = "Lbl_MessagesReceived"
        Me.Lbl_MessagesReceived.Size = New System.Drawing.Size(112, 16)
        Me.Lbl_MessagesReceived.TabIndex = 4
        Me.Lbl_MessagesReceived.Text = "Messages Received"
        '
        'Txt_Service
        '
        Me.Txt_Service.Location = New System.Drawing.Point(88, 16)
        Me.Txt_Service.Name = "Txt_Service"
        Me.Txt_Service.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Service.TabIndex = 5
        Me.Txt_Service.Text = ""
        '
        'Txt_Network
        '
        Me.Txt_Network.Location = New System.Drawing.Point(88, 48)
        Me.Txt_Network.Name = "Txt_Network"
        Me.Txt_Network.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Network.TabIndex = 6
        Me.Txt_Network.Text = ""
        '
        'Txt_Daemon
        '
        Me.Txt_Daemon.Location = New System.Drawing.Point(88, 80)
        Me.Txt_Daemon.Name = "Txt_Daemon"
        Me.Txt_Daemon.Size = New System.Drawing.Size(120, 20)
        Me.Txt_Daemon.TabIndex = 7
        Me.Txt_Daemon.Text = ""
        '
        'Txt_Subject
        '
        Me.Txt_Subject.Location = New System.Drawing.Point(88, 24)
        Me.Txt_Subject.Name = "Txt_Subject"
        Me.Txt_Subject.Size = New System.Drawing.Size(128, 20)
        Me.Txt_Subject.TabIndex = 8
        Me.Txt_Subject.Text = "VB.NET.example.reliable"
        '
        'Txt_Message_Recvd
        '
        Me.Txt_Message_Recvd.Location = New System.Drawing.Point(8, 40)
        Me.Txt_Message_Recvd.Multiline = True
        Me.Txt_Message_Recvd.Name = "Txt_Message_Recvd"
        Me.Txt_Message_Recvd.ReadOnly = True
        Me.Txt_Message_Recvd.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.Txt_Message_Recvd.Size = New System.Drawing.Size(336, 120)
        Me.Txt_Message_Recvd.TabIndex = 9
        Me.Txt_Message_Recvd.Text = ""
        '
        'Btn_CreateXport
        '
        Me.Btn_CreateXport.Location = New System.Drawing.Point(240, 16)
        Me.Btn_CreateXport.Name = "Btn_CreateXport"
        Me.Btn_CreateXport.Size = New System.Drawing.Size(112, 24)
        Me.Btn_CreateXport.TabIndex = 10
        Me.Btn_CreateXport.Text = "Create Transport"
        '
        'Btn_DestroyXport
        '
        Me.Btn_DestroyXport.Location = New System.Drawing.Point(240, 48)
        Me.Btn_DestroyXport.Name = "Btn_DestroyXport"
        Me.Btn_DestroyXport.Size = New System.Drawing.Size(112, 24)
        Me.Btn_DestroyXport.TabIndex = 11
        Me.Btn_DestroyXport.Text = "Destroy Transport"
        '
        'Btn_CreateListener
        '
        Me.Btn_CreateListener.Location = New System.Drawing.Point(240, 16)
        Me.Btn_CreateListener.Name = "Btn_CreateListener"
        Me.Btn_CreateListener.Size = New System.Drawing.Size(112, 24)
        Me.Btn_CreateListener.TabIndex = 12
        Me.Btn_CreateListener.Text = "Create Listener"
        '
        'Btn_Exit
        '
        Me.Btn_Exit.ForeColor = System.Drawing.Color.Firebrick
        Me.Btn_Exit.Location = New System.Drawing.Point(280, 80)
        Me.Btn_Exit.Name = "Btn_Exit"
        Me.Btn_Exit.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Exit.TabIndex = 14
        Me.Btn_Exit.Text = "Exit"
        '
        'Btn_DestroyListener
        '
        Me.Btn_DestroyListener.Location = New System.Drawing.Point(240, 56)
        Me.Btn_DestroyListener.Name = "Btn_DestroyListener"
        Me.Btn_DestroyListener.Size = New System.Drawing.Size(112, 24)
        Me.Btn_DestroyListener.TabIndex = 15
        Me.Btn_DestroyListener.Text = "Destroy Listener"
        '
        'Btn_ClearMsgs
        '
        Me.Btn_ClearMsgs.Location = New System.Drawing.Point(240, 11)
        Me.Btn_ClearMsgs.Name = "Btn_ClearMsgs"
        Me.Btn_ClearMsgs.Size = New System.Drawing.Size(112, 24)
        Me.Btn_ClearMsgs.TabIndex = 16
        Me.Btn_ClearMsgs.Text = "Clear Messages"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txt_Network)
        Me.GroupBox1.Controls.Add(Me.Txt_Daemon)
        Me.GroupBox1.Controls.Add(Me.Lbl_Daemon)
        Me.GroupBox1.Controls.Add(Me.Lbl_Service)
        Me.GroupBox1.Controls.Add(Me.Btn_CreateXport)
        Me.GroupBox1.Controls.Add(Me.Lbl_Network)
        Me.GroupBox1.Controls.Add(Me.Btn_DestroyXport)
        Me.GroupBox1.Controls.Add(Me.Btn_Exit)
        Me.GroupBox1.Controls.Add(Me.Txt_Service)
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(368, 112)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Txt_Subject)
        Me.GroupBox2.Controls.Add(Me.Btn_CreateListener)
        Me.GroupBox2.Controls.Add(Me.Lbl_Subject)
        Me.GroupBox2.Controls.Add(Me.Btn_DestroyListener)
        Me.GroupBox2.Location = New System.Drawing.Point(0, 112)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(368, 88)
        Me.GroupBox2.TabIndex = 18
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Txt_MsgCount)
        Me.GroupBox3.Controls.Add(Me.Btn_ClearMsgs)
        Me.GroupBox3.Controls.Add(Me.Lbl_MessagesReceived)
        Me.GroupBox3.Controls.Add(Me.Txt_Message_Recvd)
        Me.GroupBox3.Location = New System.Drawing.Point(0, 200)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(368, 168)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        '
        'Txt_MsgCount
        '
        Me.Txt_MsgCount.Location = New System.Drawing.Point(136, 11)
        Me.Txt_MsgCount.Name = "Txt_MsgCount"
        Me.Txt_MsgCount.Size = New System.Drawing.Size(32, 20)
        Me.Txt_MsgCount.TabIndex = 17
        Me.Txt_MsgCount.Text = "0"
        Me.Txt_MsgCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RendezvousListen
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(367, 373)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "RendezvousListen"
        Me.Text = "Rendezvous Listen Application using .NET library"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    '**********************************************************
    'Declarations...
    'Event msgReceive As TIBCO.Rendezvous.MessageReceivedEventHandler
    Dim transport As TIBCO.Rendezvous.NetTransport
    Dim mylistener As TIBCO.Rendezvous.Listener
    Dim dispatcher As TIBCO.Rendezvous.Dispatcher
    Dim nNumMsgs As Int32


    '**********************************************************
    ' This subroutine is invoked each a message arrives on the
    ' subject we are listening too.  We are going to process the
    ' message in this function.  The processing is rather
    ' simpleminded but should serve to illustrate the general
    ' principles.
    Private Sub OnMessageReceived(ByVal listener As Object, _
                        ByVal MsgReceivehandler As TIBCO.Rendezvous.MessageReceivedEventArgs)

        Dim message As TIBCO.Rendezvous.Message
        Dim msgdata As String

        ' Update the display, showing that we have received another message
        nNumMsgs = nNumMsgs + 1
        Txt_MsgCount.Text = nNumMsgs.ToString

        Txt_Message_Recvd.Text += "In OnMessageReceived ..." & vbCrLf
        message = MsgReceivehandler.Message

        msgdata = msgdata + DateTime.Now.ToString() + message.SendSubject _
                  + message.ReplySubject + message.ToString() + vbCrLf

        Txt_Message_Recvd.Text += msgdata

    End Sub

    '**********************************************************
    ' The "Create Transport" button invokes this subroutine.
    ' We have placed the RV transport create method call code
    ' in this function.  The transport is needed before we can
    ' register interest in a subject.
    Private Sub Btn_CreateXport_Click(ByVal sender As System.Object, _
                        ByVal e As System.EventArgs) Handles Btn_CreateXport.Click
        ' First, we create a Transport.  A transport is the object which
        ' manages network connections to the daemon.  The parameters
        ' can be blank (i.e. "" or vbNullString) for default values or
        ' explicitly specified.  In this case, we get the values from
        ' textboxes on this applications form.

        Try

            transport = New TIBCO.Rendezvous.NetTransport(Txt_Service.Text, Txt_Network.Text, Txt_Daemon.Text)

            Disable_Create_Transport()  ' Disable create transport function
            Enable_Destroy_Transport()  ' Enable destroy transport function
            Enable_Create_Listener()    ' Enable create listener function

        Catch exception As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Create Transport,  Reason :  " + exception.Message)

        End Try

    End Sub

    '**********************************************************
    ' The "Destroy Transport" button invokes this subroutine.
    ' We undo the setup here and clean up RV objects.
    Private Sub Btn_DestroyXport_Click(ByVal sender As System.Object, _
                        ByVal e As System.EventArgs) Handles Btn_DestroyXport.Click
        ' Destroy our listener.  When we destroy a tranpsort,
        ' objects which depend on it (listeners, cmtransports) are
        ' destroyed as well.  We will call the destroy listener
        ' routine to do this explicitly here, dropping our interest
        ' in any messages which arrive on this subject.

        Btn_DestroyListener_Click(sender, e)

        ' Destroy our transport.  This will cause any outstanding events,
        ' like timers or waiting messages, to be destroyed.
        If Not transport Is Nothing Then
            If (transport.Equals(Nothing)) Then transport.Destroy()
        End If

        '****************************************************************
        ' Everything else in this function is not directly related to RV.
        Disable_Destroy_Transport() ' Disable transport destroy
        Disable_Create_Listener()   ' Disable create listener
        Enable_Create_Transport()   ' Allow transport create

    End Sub

    Public Sub Btn_CreateListener_Click(ByVal sender As System.Object, _
                        ByVal e As System.EventArgs) Handles Btn_CreateListener.Click

        ' Allocate the listener object
        ' Set up the listener mechanism.

        nNumMsgs = 0

        Try

            If (Txt_Subject.Text = "") Then
                Txt_Message_Recvd.Text += "Please enter a valid subject name ..." & vbCrLf
                Return
            End If

            mylistener = New TIBCO.Rendezvous.Listener(TIBCO.Rendezvous.Queue.Default, _
                                                                   transport, Txt_Subject.Text, 0)
            dispatcher = New TIBCO.Rendezvous.Dispatcher(TIBCO.Rendezvous.Queue.Default)
            AddHandler mylistener.MessageReceived, AddressOf OnMessageReceived

            '****************************************************************
            ' Everything else in this function is not directly related to RV.

            ' Clear out any left-over counts and data from a previously created
            ' and destroyed listener.

            Txt_MsgCount.Text = 0
            Disable_Create_Listener()   ' Disable subject, disable create button
            Enable_Destroy_Listener()   ' Enable destroy listener function

        Catch ex As TIBCO.Rendezvous.RendezvousException

            MsgBox("Unable to Create Listener,  Reason :  " + ex.Message)

        End Try

    End Sub

    '**********************************************************
    ' The "Destroy Listener" button invokes this subroutine.
    ' We cancel interest in our subject and clean up RV objects.
    Private Sub Btn_DestroyListener_Click(ByVal sender As System.Object, _
                        ByVal e As System.EventArgs) Handles Btn_DestroyListener.Click
        ' Destroy our listener.  This will drop our interest in
        ' messages that may arrive on this subject.
        If Not mylistener Is Nothing Then
            mylistener.Destroy()
            mylistener = Nothing
        End If

        '****************************************************************
        ' Everything else in this function is not directly related to RV.
        Disable_Destroy_Listener()  ' Disable destroy listener.
        Enable_Create_Listener()    ' Allow listener create
    End Sub

    '**********************************************************
    ' This subroutine is invoked when VB tries to load our form.
    ' We will open the RV system, access the queue objects,
    ' and set up access to buttons and textboxes.
    Private Sub RendezvousListen_Load(ByVal sender As System.Object, _
                        ByVal e As System.EventArgs) Handles MyBase.Load
        'initialise TIBCO Rendezvous machinery...
        TIBCO.Rendezvous.Environment.Open()

        ' Call the routines to enable / disable buttons
        Enable_Create_Transport()
        Disable_Destroy_Transport()

        Txt_Message_Recvd.Text = ""
    End Sub

    '**********************************************************
    'It executes the Exit button routine before quitting.
    Private Sub RendezvousListen_Unload(ByVal Cancel As Integer)
        Btn_Exit_Click(Me, New EventArgs)

    End Sub

    '**********************************************************
    ' The "EXIT" button invokes this subroutine.
    ' If needed, we clean up RV stuff and then exit the application
    Private Sub Btn_Exit_Click(ByVal sender As System.Object, _
                                ByVal e As System.EventArgs) Handles Btn_Exit.Click
        ' Before we go, let's clean up

        Btn_DestroyListener_Click(Me, e)

        ' This subroutine will do the transport cleanup.
        ' Close and free up the RV mechanisms.  This method destroys
        ' any currently valid Tibrv objects, in the proper order,
        ' allowing any active callbacks to complete.
        TIBCO.Rendezvous.Environment.Close()
        ' Exit
        End

    End Sub
    '**********************************************************
    ' This routine is called when the Clear Messages Button is 
    ' clicked.

    Private Sub Btn_ClearMsgs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ClearMsgs.Click

        Txt_Message_Recvd.Clear()
    End Sub

    '**********************************************************
    ' This routine enables the button for create transport function
    ' when we have destroyed or not yet created a transport.
    ' At this point, we can set the options for the transport 
    ' and can create the transport.
    Private Sub Enable_Create_Transport()
        ' Enable the following text boxes.  The user may want to change them
        ' in preparation for creating another listener.  Restore the color.
        Txt_Service.Enabled = True
        Txt_Network.Enabled = True
        Txt_Daemon.Enabled = True
        Txt_Subject.Enabled = True
        Lbl_Service.Enabled = True
        Lbl_Network.Enabled = True
        Lbl_Daemon.Enabled = True
        Lbl_Subject.Enabled = True

        ' Enable the "Create Transport" button - we may want to subscribe again
        Btn_CreateXport.Enabled = True

        ' Don't allow listener add/allow/disallow with no cm transport.
        Btn_CreateListener.Enabled = False
        Btn_DestroyListener.Enabled = False

    End Sub

    '**********************************************************
    ' This routine disables the button when we have already created a
    ' transport.  At this point, we can create a listener or we
    ' can destroy the transport.
    Private Sub Disable_Create_Transport()
        ' Disable the following text boxes, since changing them will
        ' have no effect unless the transport is recreated.
        Txt_Service.Enabled = False
        Txt_Network.Enabled = False
        Txt_Daemon.Enabled = False
        Lbl_Service.Enabled = False
        Lbl_Network.Enabled = False
        Lbl_Daemon.Enabled = False

        ' Disable the "Create Transport" button
        Btn_CreateXport.Enabled = False
    End Sub

    '**********************************************************
    ' This routine enables the button when we have created
    ' a transport and listener.
    Private Sub Enable_Destroy_Transport()

        ' Enable the "Destroy Transport" button - we now have something to destroy
        Btn_DestroyXport.Enabled = True

    End Sub

    '**********************************************************
    ' This routine disables the button for the
    ' transport destroy function when we have destroyed or not
    ' yet created a transport.
    Private Sub Disable_Destroy_Transport()
        ' Disable the "Destroy Transport" button.  Nothing to destroy.
        Btn_DestroyXport.Enabled = False
    End Sub

    '**********************************************************
    ' This routine enables the button when we have created a transport
    ' but have not created or have destroyed a listener.  At this
    ' point, we can set the subject and can create the listener
    ' to register interest in the subject.
    Private Sub Enable_Create_Listener()
        ' Enable the following text box.  The user may want to change them
        ' in preparation for creating another listener.  Restore the color.
        Txt_Subject.Enabled = True
        Lbl_Subject.Enabled = True

        ' Enable the "Create Listener" button - we may want to subscribe again
        Btn_CreateListener.Enabled = True
    End Sub

    '**********************************************************
    ' This routine disables the button and sets colors for the
    ' create listener function when we have already created a
    ' listener.  At this point, we can wait for messages and we
    ' can destroy the listener or the transport.
    Private Sub Disable_Create_Listener()
        ' Disable the subjet text box, since changing it will have no
        ' effect unless the subscriber is recreated.  Gray the textbox.
        ' If we allowed a create action with the listener active, it would
        ' have destroy the current listener in the process of creating another.

        Txt_Subject.Enabled = False
        Lbl_Subject.Enabled = False

        ' Disable the "Create Listener" button
        Btn_CreateListener.Enabled = False

    End Sub

    '**********************************************************
    ' This routine enables the button destroy listener when we have created a listener.
    Private Sub Enable_Destroy_Listener()
        ' Enable the "Destroy Listener" button - we now have something to destroy
        Btn_DestroyListener.Enabled = True

    End Sub

    '**********************************************************
    ' This routine disables the button for the
    ' listener destroy function when we have destroyed or not
    ' yet created a listener.
    Private Sub Disable_Destroy_Listener()
        ' Disable the "Destroy Listener" button.  Nothing to destroy.
        Btn_DestroyListener.Enabled = False
    End Sub
    '**********************************************************
    'If the RendezvousListener is closed using the X button at the 
    'top of dialog box then we handle it here.

    Private Sub RendezvousListen_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        Btn_Exit_Click(Me, New EventArgs)
    End Sub
End Class
