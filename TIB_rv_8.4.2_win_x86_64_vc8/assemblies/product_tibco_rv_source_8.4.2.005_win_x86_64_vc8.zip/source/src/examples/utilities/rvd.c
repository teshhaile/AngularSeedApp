/*
 * Copyright (c) 1998-2007 TIBCO Software Inc.
 * All rights reserved.
 * TIB/Rendezvous is protected under US Patent No. 5,187,787.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 */

/*
 * Utility program to allow TIBCO Rendezvous programs to spawn a customized
 * daemon process instead of rvd
 *
 * This program will attempt to start a daemon executable using parameters
 * obtained from command line or an entire command string stored
 * in a file.
 *
 * Examples:
 *
 * 1) rvd
 * 2) rvd -cmdfile cmdfile.txt
 * 3) rvd -listen 7500
 * 4) rvd -cmdfile cmdfile.txt -listen 7600
 *
 * Options on command line will be appended to the command string found in cmdfile.txt.
 *
 *
 * NOTE: Make sure the command string stored in cmdfile.txt does not end with a newline character.
 *
 * This program can be built using:
 *
 * cl rvd.c /link Advapi32.lib
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <Winbase.h>


#define MAX_COMMAND_LENGTH  (1024)
#define MAX_PATH_LENGTH     (512)
#define COMMAND_FILENAME    "cmdfile.txt"


void
readCommandFile (char *filename, char *commandString)
{
    HANDLE fileHandle;
    DWORD numberOfBytesWritten;
    DWORD numberOfBytesRead;

    fileHandle = CreateFile (filename,
                             GENERIC_READ | GENERIC_WRITE, 0,
                             0, OPEN_EXISTING, 0, 0);
    if (fileHandle == INVALID_HANDLE_VALUE) {
        fprintf (stderr, "Unable to open file '%s'\n", filename);

        exit (1);
    }

    if (strlen (commandString) > 0) {
        SetFilePointer (fileHandle, 0, NULL, FILE_END);

        if (WriteFile (fileHandle, commandString, strlen (commandString),
                       &numberOfBytesWritten, NULL) == 0) {
            fprintf (stderr, "Error writing file '%s'\n", filename);

            CloseHandle (fileHandle);

            exit (1);
        }
    }

    SetFilePointer (fileHandle, 0, NULL, FILE_BEGIN);

    if (ReadFile (fileHandle, commandString, MAX_COMMAND_LENGTH, &numberOfBytesRead, 0) != 0) {
        commandString[numberOfBytesRead] = '\0';

        CloseHandle (fileHandle);

        return;
    } else {
        fprintf (stderr, "Failed to read file '%s'\n", filename);

        CloseHandle (fileHandle);

        exit (1);
    }
}

static void
usage (void)
{
    fprintf (stderr, "rvd [-cmdfile      <filename>]\n");
    fprintf (stderr, "    [-rvdm         <control channel specification>]\n");
    fprintf (stderr, "    [-store        <filename>]\n");
    fprintf (stderr, "    [-http         [<IP address>:]<port>]\n");
    fprintf (stderr, "    [-https        [<IP address>:]<port>]\n");
    fprintf (stderr, "    [-http-only]\n");
    fprintf (stderr, "    [-no-http]\n");
    fprintf (stderr, "    [-listen       [<IP address>:]<port>]\n");
    fprintf (stderr, "    [-reliability  <interval>]\n");
    fprintf (stderr, "    [-logfile      <filename>]\n");

    exit (1);
}

static void
getParameters (int argc, char *argv[], char *commandString)
{
    char path[MAX_PATH_LENGTH];
    int i = 1;
    unsigned int remainingSpace = MAX_COMMAND_LENGTH;
    char *filePart;

    memset (commandString, 0, MAX_COMMAND_LENGTH);
    memset (path, 0, MAX_PATH_LENGTH);

    if (i < argc) {
        if ((strcmp (argv[i], "-h") == 0)
                || (strcmp (argv[i], "-help") == 0)
                || (strcmp (argv[i], "/?") == 0)) {
            usage ();
        } else if (strcmp (argv[i], "-cmdfile") == 0) {
            if (++i < argc) {
                _snprintf (path, MAX_PATH_LENGTH, "%s", argv[i]);

                i++;
            } else {
                usage ();
            }
        }

        for (; i < argc && remainingSpace > strlen (argv[i]) + 2; i++) {
            sprintf (commandString + MAX_COMMAND_LENGTH - remainingSpace, " %s",
                     argv[i]);

            remainingSpace -= strlen (argv[i]) + 1;
        }
    }

    if (path[0] == '\0') {
        if (SearchPath (NULL, COMMAND_FILENAME, NULL,
                        MAX_PATH_LENGTH, path, &filePart) == 0) {
            fprintf (stderr, "Unable to determine real path of '%s'\n",
                     COMMAND_FILENAME);

            exit (1);
        }
    }

    readCommandFile (path, commandString);
}


int
main (int argc, char **argv)
{
    char securityDescriptorBuffer[SECURITY_DESCRIPTOR_MIN_LENGTH];
    PSECURITY_DESCRIPTOR securityDescriptor = (PSECURITY_DESCRIPTOR) & securityDescriptorBuffer;
    SECURITY_ATTRIBUTES *securityAttributes = NULL;
    SECURITY_ATTRIBUTES securityAttributesBuffer;
    char commandString[MAX_COMMAND_LENGTH];

    STARTUPINFO startUpInfo;
    PROCESS_INFORMATION processInformation;

    if (InitializeSecurityDescriptor (securityDescriptor, SECURITY_DESCRIPTOR_REVISION) != 0
        && SetSecurityDescriptorDacl (securityDescriptor, TRUE, (PACL) NULL, FALSE) != 0) {
        securityAttributes = &securityAttributesBuffer;

        securityAttributes->nLength = sizeof (securityAttributesBuffer);
        securityAttributes->lpSecurityDescriptor = securityDescriptor;
        securityAttributes->bInheritHandle = FALSE;
    }

    getParameters (argc, argv, commandString);

    ZeroMemory (&startUpInfo, sizeof (startUpInfo));
    startUpInfo.cb = sizeof (startUpInfo);
    ZeroMemory (&processInformation, sizeof (processInformation));

    if (CreateProcess (NULL,
                       commandString,
                       securityAttributes,
                       securityAttributes,
                       FALSE,
                       DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP |
                       CREATE_DEFAULT_ERROR_MODE, NULL, NULL, &startUpInfo, &processInformation) == 0) {
        fprintf (stderr, "CreateProcess failed\n");

        exit (1);
    }

    /*
     * Uncomment the following lines to wait for the daemon process to exit
     */

    /*
     *
     * WaitForSingleObject(processInformation.hProcess, INFINITE);
     *
     * CloseHandle(processInformation.hProcess); CloseHandle(processInformation.hThread);
     *
     */

    exit (0);
}

