
/*
 * Copyright (c) 1995-2000 TIBCO Software Inc.
 * All rights reserved.
 * TIB/Rendezvous is protected under US Patent No. 5,187,787.
 * For more information, please contact:
 * TIBCO Software, Inc., Palo Alto, California, USA
 *
 * $Id: testcpp.cpp 12313 2005-11-23 18:08:58Z dleshc $
 *
 */


#include <time.h>
#include <stdlib.h>

#include "tibrvcpp.h"
#include "cmcpp.h"



char* serviceStr = NULL;
char* networkStr = NULL;
char* daemonStr  = NULL;

const char* subject = "_LOCAL.test.cpp";

TibrvMsg* lastMessage = NULL;

class MyTimerCallback: public TibrvTimerCallback
{
public:

    MyTimerCallback()
    {
        count = 0;
    }

    void onTimer(TibrvTimer* timer)
    {
        count++;
        printf("Timer: received timer No. %d at %d\n",count,(int)time(0));

        if (count > 10) {
            // close
            timer->getQueue()->destroy();
            return;
        }

        TibrvTransport* tport = (TibrvTransport*) timer->getClosure();

        // send a message
        TibrvMsg msg;
        msg.addI32("count",(tibrv_i32)count);
        msg.addString("str","value");
        msg.setSendSubject(subject);
        tport->send(msg);
    }

private:
    int count;
};

class MyMsgCallback: public TibrvMsgCallback
{
public:

    MyMsgCallback()
    {
        count = 0;
    }

    void onMsg(TibrvListener* listener, TibrvMsg& msg)
    {
        count++;
        printf("Listener: received message No. %d, closure=%s\n",count,(char*)listener->getClosure());

        // print a message
        const char * str;
        msg.convertToString(str);

        printf("    msg=%s\n",str);

        // detach the message
        lastMessage = msg.detach();
    }

private:
    int count;
};

class MyCmMsgCallback: public TibrvCmMsgCallback
{
public:

    MyCmMsgCallback()
    {
    }

    void onCmMsg(TibrvCmListener* listener, TibrvMsg& msg)
    {
        if (msg.getHandle() == NULL) msg.reset();
        listener = listener;
    }

private:
    int count;
};


int main(int argc, char** argv)
{

    argc=argc;  // avoid warnings if not used
    argv=argv;  // avoid warnings if not used

    TibrvStatus s;
    TibrvQueue queue;
    TibrvTimer timer;
    TibrvNetTransport tport;
    TibrvListener listener;

    TibrvStatus sx1 = TIBRV_OK;
    TibrvStatus sx2 = TIBRV_NOT_FOUND;

    if (sx1 != sx2)
        printf("sx1=%d, sx2=%d\n",(int)sx1,(int)sx2);

    printf("Before opening Tibrv\n");

    Tibrv::open();

    TibrvCmQueueTransport dt;
    TibrvCmListener cml;

    TibrvMsg testmsg;
    const char* testopaque = "opaque string";
    const void* testopaqueget;
    tibrv_u32 opaquesize;
    testmsg.addOpaque("opaque",testopaque,strlen(testopaque));
    testmsg.getOpaque("opaque",testopaqueget,opaquesize);

    tibrvMsgDateTime mdt1;
    TibrvMsgField fieldx;

    if (mdt1 == fieldx.getData().date)
        printf("\n");

    if (mdt1 != fieldx.getData().date)
        printf("\n");


    printf("After opening Tibrv\n");

    if ((s=queue.create()) != TIBRV_OK) {
        printf("Error creating Queue, status=%d, msg=%s\n",(int)s,s.getText());
        exit(0);
    }

    queue.setName("My Queue");

    s = tport.create(serviceStr,networkStr,daemonStr);
    if (s != TIBRV_OK) {
        printf("Error creating Transport, status=%d, msg=%s\n",(int)s,s.getText());
        exit(0);
    }

    dt.create(&tport,"cmname");
    cml.create(&queue,new MyCmMsgCallback(),&dt,"subject");

    s = listener.create(&queue,new MyMsgCallback(),&tport,(char*)subject,(void*)"listener closure");
    if (s != TIBRV_OK) {
        printf("Error creating Listener, status=%d, msg=%s\n",(int)s,s.getText());
        exit(0);
    }

    s = timer.create(&queue,new MyTimerCallback(),2,&tport);
    if (s != TIBRV_OK) {
        printf("Error creating Timer, status=%d, msg=%s\n",(int)s,s.getText());
        exit(0);
    }

    printf("Tibrv opened successfully, started timer every 2 seconds\n");

    // start dispatching

    while((s=queue.dispatch()) == TIBRV_OK) ;

    // check why we ended
    if (s == TIBRV_INVALID_QUEUE)
        printf("Quitting because queue was destroyed\n");
    else
    if (s == TIBRV_NOT_INITIALIZED)
        printf("Quitting because Tibrv was closed\n");
    else
        printf("Error in dispatch(): status=%d, msg=%s\n",(int)s,s.getText());

    // print last detached message to check it's O'k
    const char *str;
    lastMessage->convertToString(str);
    printf("Last Message Received Was:\n   %s\n",str);

    delete lastMessage;

    Tibrv::close();

    return 0;
}
