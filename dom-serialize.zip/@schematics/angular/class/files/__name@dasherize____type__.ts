export class <%= classify(name) %> {
}
