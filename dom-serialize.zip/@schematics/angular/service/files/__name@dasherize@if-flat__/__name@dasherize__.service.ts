import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class <%= classify(name) %>Service {

  constructor() { }
}
