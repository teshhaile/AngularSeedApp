import { Rule } from '@angular-devkit/schematics';
import { Schema as AppShellOptions } from './schema';
export default function (options: AppShellOptions): Rule;
