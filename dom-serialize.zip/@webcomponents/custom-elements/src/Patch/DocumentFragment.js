// DocumentFragment implements ParentNode, but inserting into a DocumentFragment
// can never cause a tree to be upgraded or connected, because DocumentFragments
// are always disconnected.
