-- ****************************************************
--   TIBCO ActiveMatrix BusinessWorks 
--
--   Creates test tables for JDBC transaction example 
--   on Oracle Database
-- ****************************************************

-- Create table-1
DROP TABLE bwTxTest;
CREATE TABLE bwTxTest (
   userData VARCHAR(60)
);

-- Create table-2
DROP TABLE bwTxTest2;
CREATE TABLE bwTxTest2 (
   userData VARCHAR(60)
);

/



COMMIT;
