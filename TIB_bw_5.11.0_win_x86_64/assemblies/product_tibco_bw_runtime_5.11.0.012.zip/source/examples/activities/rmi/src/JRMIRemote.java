package test;

import java.rmi.*;

/**
 * This interface defines some operations that this JRMI client exports.
 * The remote server can call them
 */
public interface JRMIRemote extends Remote {

    /**
     * This call is made in response to a calculation request by the
     * client, the server does the calculation and returns the answer.
     */
    public void answer(String msg) throws RemoteException;

    /**
     * Demonstrates a way to get additional information from the client,
     * the server calls back to the client to get the operator values
     */
    public Integer getOp1() throws RemoteException;
    
    /**
     * Demonstrates a way to get additional information from the client,
     * the server calls back to the client to get the operator values
     */
    public Integer getOp2() throws RemoteException;
}
