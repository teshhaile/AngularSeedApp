package test;

import java.util.*;
import java.lang.reflect.*;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.tibco.im.jrmi.*;


/**
 *  This sample client provides a command line interface to perform some
 *  sample actions.  Each type of request is demonstrated to show how
 *  the client and server interact.
 *
 *  Use -h to get a usage statement.
 */
public class RMIClient extends UnicastRemoteObject implements JRMIRemote {

    private static IntegrationManager theServer = null;  // the IM/BW server

    private int count = 0; // how many replies are we expecting
    
    private static boolean syncCall = false;
    private static boolean sendRequest = false;
    private static boolean sendReply = false;

    private static String remoteName = "";
    private static String hostName = "localhost";
    private static int port = 1099;
    private static boolean imAPI = false;  // use the BW API by default

    /**
     * Just create a client and let it ask the user what to do
     */
    public static void main( String[] args )
    {
        try {

            System.setProperty("java.security.policy","jrmi.policy");
            if (System.getSecurityManager() == null) {
                System.setSecurityManager(new RMISecurityManager());
            }
            RMIClient client = new RMIClient(args);

            if (sendRequest) {
                BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                
                if (!syncCall && !sendReply) {
                    // need to increment the count so the waiting thread doesn't exit
                    client.incrementCount();
                }

                Request request = generateRequest();
                // parse stdin for key : value lines to build a request
                String line = input.readLine();
                while (line != null) {
                    if (line.startsWith("#")) {
                        // skip over comments
                        line = input.readLine();
                        continue;
                    }
                    if (line.trim().equals("-")) {
                        if (syncCall || sendReply) {
                            // create a sync thread to handle the call
                            new SyncThread(client, theServer, request, syncCall).start();
                            
                            // must let the other thread do some work, so it can
                            // increment the count and send out the request
                            Thread.currentThread().yield();
                        } else {
                            theServer.send(request);
                        }
                        request = generateRequest();
                    } else {
                        try {
                            StringTokenizer st = new StringTokenizer(line.trim(), ":");

                            String tag = st.nextToken().trim();
                            String className = st.nextToken().trim();
                            String stringValue = st.nextToken().trim();

                            Class theClass = Class.forName(className);
                            Constructor constructor = null;
                            Object value = null;
                            
                            try {
                                constructor = theClass.getConstructor(new Class[] { java.lang.String.class });
                                value = constructor.newInstance(new Object[] { stringValue });
                            } catch (NoSuchMethodException noSuchConstructor) {
                                constructor = theClass.getConstructor(new Class[] { });
                                value = constructor.newInstance(new Object[] {});
                            }
                            
                            if (value != null) {
                                buildRequest(request, tag, value);
                            }
                        } catch (NoSuchElementException ignore) {
                        }
                    }
                    
                    line = input.readLine();
                }
            } else
            if (sendReply) {
                // let another thread handle the request
                new SyncThread(client, theServer, null, syncCall).start();

                // must let the other thread do some work, so it can
                // increment the count and send out the request
                Thread.currentThread().yield();
            }

            // don't be too hasty to exit, or the server will get a connection
            // refused error when it tries to reply
            new WaitThread(client).start();
            
            if (!syncCall && !sendReply) {
                // ok, we're done sending all the requests
                client.decrementCount();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
            System.exit(-1);
        }

        // this thread continues to wait for replies
    }

    // generate the appropriate request object based on whether they want
    // IM or BW stuff
    private static Request generateRequest() {
        if (imAPI) {
            // use the IM simple request
            return new com.tibco.im.jrmi.SimpleRequest();
        } else {
            // use the enhanced BW request class that provides Serializable return values
            return new com.tibco.bw.rmi.SimpleServerRequest();
        }
    }

        
    private static void buildRequest(Request request, String tag, Object value) {
        int dot = tag.indexOf(".");

        if (dot == -1) {
            // its a simple tag/value so just add it to the request
            request.put(tag, value);
        } else {
            // recursively add this value in a tree
            String subtag = tag.substring(0, dot);
            Object subtree = request.get(subtag);

            if ((subtree != null) && !(subtree instanceof Request)) {
                System.out.println("Invalid input: " + tag + " : " + value);
                return;
            }

            Request tree = (Request) subtree;
            if (tree == null) {
                tree = generateRequest();
                request.put(subtag, tree);
            }

            // recurse into this subtree
            buildRequest(tree, tag.substring(dot+1), value);
        }
    }
    
    // keep track of the number of requests sent out so we don't exit too soon
    public synchronized void incrementCount() {
        count++;
        // System.out.println("INC: " + count);
    }
    
    // keep track of the number of requests sent out so we don't exit too soon
    public synchronized void decrementCount() {
        count--;
        // System.out.println("DEC: " + count);
    }

    // keep track of the number of requests sent out so we don't exit too soon
    public synchronized int getCount() {
        // System.out.println("GET: " + count);
        return count;
    }

    /**
     * The server has my answer, display it
     */
    public synchronized void answer(String msg) throws RemoteException {
        System.out.println("answer:" + msg);
        decrementCount();
        notify();
    }

    /**
     * Return some interesting values
     */
    public Integer getOp1() throws RemoteException { return new Integer(5); }
    
    /**
     * Return some interesting values
     */
    public Integer getOp2() throws RemoteException { return new Integer(12); }

    /**
     *  Initialize the settings and get ready to go
     */
    public RMIClient(String[] args) throws Exception, RemoteException {
        for (int i = 0; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("-h")) {
                System.out.println("usage: [-sync] [-request] [-reply] [-host x] [-port #] [-im | -bw] remoteName");
                System.out.println("  sync        make the call synchronously, i.e. wait for it");
                System.out.println("  request     supply a set of request tag:value lines on stdin");
                System.out.println("  reply       include this client as a reply object");
                System.out.println("  host        host where the registry server is running [default localhost]");
                System.out.println("  port        port the registry server is using [default 1099]");
                System.out.println("  im | bw     use either the IM client API or the BW API [default bw]");
                System.out.println("  remoteName  name of the remote IM/BW server object");
                System.exit(-1);
            } else
            if (args[i].equals("-request")) {
                sendRequest = true;
            } else
            if (args[i].equals("-reply")) {
                sendReply = true;
            } else
            if (args[i].equals("-im")) {
                imAPI = true;
            } else
            if (args[i].equals("-bw")) {
                imAPI = false;
            } else
            if (args[i].equals("-sync")) {
                syncCall = true;
            } else
            if (args[i].equals("-host")) {
                i++;
                if (i < args.length) {
                    hostName = args[i];
                } else {
                    System.out.println("*** invalid host argument");
                }
            } else
            if (args[i].equals("-port")) {
                i++;
                if (i < args.length) {
                    port = new Integer(args[i]).intValue();
                } else {
                    System.out.println("*** invalid port argument");
                }
            } else {
                remoteName = args[i];
            }
        }

        if (remoteName.equals("")) {
            System.out.println("*** Error: no remote name specified");
            System.exit(-1);
        }
        
        Registry reg = LocateRegistry.getRegistry(hostName, port);

        theServer = (IntegrationManager) reg.lookup(remoteName);
    }
}

    /**
     *  This class sends a sync request on its own thread which then
     *  blocks waiting for the response.
     */
    class SyncThread extends Thread {
        private boolean doSync = false;
        private RMIClient client;
        private IntegrationManager server;
        private Request request;
        public SyncThread(RMIClient client, IntegrationManager server, Request request, boolean doSync) {
            this.doSync = doSync;
            this.client = client;
            this.server = server;
            this.request = request;
        }
        public void run() {
            try {
                synchronized(client) {
                    client.incrementCount();
                    if (doSync) {
                        // create a sync client, it will handle the details for
                        // waiting for the engine
                        SyncClient syncClient = new SyncClient(server);

                        // this call waits for the BW engine to finish its work
                        // and call the respond method on the sync client
                        System.out.println("SYNC " + syncClient.send(request));
                        client.decrementCount();
                    } else {
                        if (request == null) {
                            // we have to wait for the server to reply later
                            // they will call our answer method
                            server.send(client);
                        } else {
                            // we have to wait for the server to reply later
                            // they will call our answer method
                            server.send(request, client);
                        }
                    }
                }
            } catch (Exception ignore) { ignore.printStackTrace(); }
        }
    }

    /**
     *  This class sends a sync request on its own thread which then
     *  blocks waiting for the response.
     */
   class WaitThread extends Thread {
        private RMIClient client;
        public WaitThread(RMIClient client) {
            this.client = client;
        }
        public void run() {
            try {
                synchronized(client) {
                    while (client.getCount() > 0) {
                        client.wait();
                    }
                    System.exit(0);
                }
            } catch (Exception ignore) { ignore.printStackTrace(); }
        }
    }

