package jmdbexample;

import jmexample.Balance;
import jmexample.Account;
import jmexample.InvalidAccountException;

import java.util.Hashtable;
import java.util.Collection;
import java.util.Enumeration;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

import com.tibco.plugin.java.JavaConnectionAccessor;

// Copyright 2003 - TIBCO Software Inc.
// ALL RIGHTS RESERVED
public class LocalBank implements java.io.Serializable {

    private Hashtable balanceList = new Hashtable();

    /**
     *Constructor.  Builds bank accounts from code
     */
    public LocalBank() {
        //create balance for customer Smith
        String lastName = "Smith";
        String firstName = "John";
        Balance balance = new Balance(lastName,firstName,"100-5001", 3500, 7400);
        balanceList.put(lastName+firstName, balance);

        //create balance for customer Tanaka
        lastName = "Tanaka";
        firstName = "Ben";
        balance = new Balance(lastName,firstName,"100-5002", 4532, 6934);
        balanceList.put(lastName+firstName, balance);

        //create balance for customer Miller
        lastName = "Miller";
        firstName = "Nancy";
        balance = new Balance(lastName,firstName,"100-5003", 2300, 14234);
        balanceList.put(lastName+firstName, balance);
    }

    /**
     * Constructor used to build bank account from database
     * @param accessor - database connection accessor obtained by JDBCGetDBConnection activity.
     *     this allows java code to utilize connection from BusinessWorks JDBC connection pool
     * @throws SQLException
     */
    public LocalBank(JavaConnectionAccessor accessor) throws SQLException {
        Connection con = accessor.getDBConnection();  // get connection previously obtained via Get Connection Activity
        Statement st = null;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM JMDBEXAMPLE");
            if (null != rs) {
                while (rs.next()) {
                    String lastName = rs.getString("lastName");
                    String firstName = rs.getString("firstName");
                    String acctId = rs.getString("acctId");
                    double checkBal = rs.getDouble("checkBal");
                    double savingBal = rs.getDouble("savingBal");
                    Balance balance = new Balance(lastName, firstName, acctId, checkBal, savingBal);
                    balanceList.put(lastName+firstName, balance);
                }
                rs.close();
            }
        } catch (SQLException ex) {
            accessor.releaseConnection(ex);  // release connection indicating exception so connection status is checked
            con = null;                      // prevents another release connection in finally method
            throw ex;                        // pass up error to Java Method activity
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException e) {
                    // ignore
                }
            }
            if (con!=null) {
                accessor.releaseConnection();  // release connection back to pool. 
            }
        }
    }

    /**
     * get customer balance.
     * @param account
     * @return
     * @throws jmexample.InvalidAccountException
     */
    public Balance getBalance(Account account) throws InvalidAccountException {
        if (account == null)
           throw new InvalidAccountException();

        //get balance for the account
        Balance balance = (Balance)balanceList.get(account.customerLastName+account.customerFirstName);
        if (balance == null)
            throw new InvalidAccountException("Not a valid customer name");

        return balance;
    }

    /**
     * get all the Balance objects contained in this class.
     * @return
     */
    public Collection getAllBalance() {
        Enumeration balanceEnum = balanceList.elements();
        ArrayList balanceArrayList = new ArrayList();

        while (balanceEnum.hasMoreElements()) {
            balanceArrayList.add(balanceEnum.nextElement());
        }

        return balanceArrayList;
    }


}
