import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PeopleComponent } from "./people.component";
import { Directive, NO_ERRORS_SCHEMA, Component, Input } from "@angular/core";
import { USE_VALUE } from "@angular/core/src/di/injector";
import { of } from "rxjs";
import { By } from "@angular/platform-browser";
import { PeopleService } from "../people.service";
import { HttpModule } from '@angular/http';

describe('PeopleComponent (Shallow Test)', ()=>{
    let fixture: ComponentFixture<PeopleComponent>;
    let mockPeopleService;
    let PEOPLE;    
    let service:PeopleService;
   
    beforeEach(()=>{    
           
        PEOPLE = [
            { name: "Teshome Skywalker",hair_color: "blond",eye_color: "blue",birth_year: "19BBY", gender: "male" },
            { name: "Mike Skywalker",hair_color: "blond",eye_color: "blue",birth_year: "19BBY", gender: "male" },
            { name: "Mary Skywalker",hair_color: "blond",eye_color: "blue",birth_year: "19BBY", gender: "male" }
        ]; 
        mockPeopleService = jasmine.createSpyObj(['get', 'getPeople']);
        TestBed.configureTestingModule(
           { declarations:[PeopleComponent],
            schemas:[NO_ERRORS_SCHEMA],
            imports: [
                HttpModule
              ],
            providers:[
                {provide: PeopleService, useValue: mockPeopleService}
            ]
        }
        )

        fixture = TestBed.createComponent(PeopleComponent);
        service = TestBed.get(PeopleService);
    })

    it('should set people correctly from the mock service.', ()=>{
        mockPeopleService.getPeople.and.returnValue(of(PEOPLE))
        fixture.autoDetectChanges();

        expect(fixture.componentInstance.people.length).toBe(2);

    })

    it('should create one li for each hero', () => {
        mockPeopleService.getPeople.and.returnValue(of(PEOPLE))
        fixture.autoDetectChanges();

        expect(fixture.debugElement.queryAll(By.css('li')).length).toBe(2);

    })

    it('should demonstrate the use of mock service', () => {
        service.getPeople().subscribe(people => {
            expect(people.length).toBe(2);
        })
    })

})