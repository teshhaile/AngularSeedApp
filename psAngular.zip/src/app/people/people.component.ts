import { Component, OnInit } from '@angular/core';
import { PeopleService } from '../people.service';
import {ClrDatagridStateInterface} from "@clr/angular";
import { Person } from '../person';

@Component({
  selector: 'app-test',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.css'],
  providers:[ PeopleService]
})
export class PeopleComponent implements OnInit {
  

people: Person[] 

  total = 0;
  
  currentPage = 1;
  loading = true; 
  selected;
  
  constructor(private peopleService:PeopleService) {   
   }
  refresh(){
    //console.log(state);
    this.loading = true;
    this.peopleService.get(this.currentPage).subscribe(data => {
     this.people = data.results;
     
    console.error("Peoples count from refresh is " + this.people.length);
     this.total = data.count;
     this.loading = false;

    });
 }
  ngOnInit() {
    this.getPeople();    
  }
  getPeople(): void {
    this.loading = true;
    this.peopleService.getPeople().subscribe(data => {
     this.people = data.results;
     
    console.error("Peoples count from getPeople is " + this.people.length);

    });
  }

 


}
