import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http'; 
import { PeopleService } from './people.service';
import { Directive, NO_ERRORS_SCHEMA, Component, Input } from "@angular/core";

describe('PeopleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PeopleService],
      
      schemas:[NO_ERRORS_SCHEMA],
      imports: [
          HttpModule
        ],
    });
  });

  it('should be created', inject([PeopleService], (service: PeopleService) => {
    expect(service).toBeTruthy();
  }));
});
