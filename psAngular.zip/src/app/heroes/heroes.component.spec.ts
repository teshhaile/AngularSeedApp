import { HeroComponent } from "../hero/hero.component";
import { HeroesComponent } from "./heroes.component";
import { COMMON_DEPRECATED_I18N_PIPES } from "@angular/common/src/pipes/deprecated";
import { of } from "rxjs";

describe('HeroesComponenet', () => {
    let component: HeroesComponent;
    let HEROES;
    let mockHeroService;

    beforeEach(()=>{
        HEROES = [
            {id:1, name: 'SpiderDude', strength:8},
            {id:2, name: 'Wonderful Woman', strength:24},
            {id:3, name: 'SuperDude', strength:55}
        ]

        mockHeroService = jasmine.createSpyObj(['getHeroes', 'addHero', 'deleteHero'])
        component =  new HeroesComponent(mockHeroService);
    })

    describe('delete', ()=>{
        it('should remove the indicated hero from the heroes list',() =>{
            mockHeroService.deleteHero.and.returnValue(of(true)) //making mockHeroService Observable
            component.heroes = HEROES;

            component.delete(HEROES[1]);

            expect(component.heroes.length).toBe(2);
            expect(component.heroes[1].strength).toBe(55);
        })

        it('should call deleteHero from mockHeroService with HEROES[1] as a prameter value',() =>{
            mockHeroService.deleteHero.and.returnValue(of(true)) //making mockHeroService Observable
            component.heroes = HEROES;

            component.delete(HEROES[1]);

            expect(mockHeroService.deleteHero).toHaveBeenCalledWith(HEROES[1]);
        })
    })
})