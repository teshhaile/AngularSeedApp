import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from'rxjs/operators';
import { Person } from './person';
//import { throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PeopleService {
  private peopleURL = `https://swapi.co/api/people/?page=2`;

  constructor(private http: Http) {    
   }
   get(page = 2){
    let url = `https://swapi.co/api/people/?page=${page}`;
    return this.http.get(url).pipe(map(data => data.json()));

   }
   /** GET heroes from the server */
  getPeople () {
    return this.http.get(`file://localhost/C:/Apps/angularTutorials/PSAngularUnitTestingCourse/src/app/person.json`)
    .pipe(map(data => data.json()));
  }
  
}
