import { MessageService } from "./message.service";

describe('Apps=>MessageService', () => {
    let service: MessageService
    beforeEach(()=>{
        service = new MessageService();
    })

    it('should have no messages to start', () => {
        expect(service.messages.length).toBe(0);
    })

    it('should add a message when add is called', () => {
        service.add('this message');
        expect(service.messages.length).toBe(1);
    })
    
    it('should clear all messages when clear is called', () => {
        service.add('and this message');
        service.add('another message');
        expect(service.messages.length).toBe(2);
        service.clear();
        expect(service.messages.length).toBe(0);
    })
})