describe('my first test',() =>
{
    let sut;
    beforeEach(() => {
            sut = {}            
        })

    it('should be false if false', ()=>{
        //arrange
        sut.a = true;

        //act
        sut.a = false;

        //assert
        expect(sut.a).toBe(false);
    })
})

