export class Person {
    name: string;
    birth_year: string;
    gender: string;
    hair_color: string;
    eye_color: string;
  }