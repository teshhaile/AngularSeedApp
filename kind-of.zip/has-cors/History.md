
1.1.0 / 2014-11-12
==================

  * remove "global" module dependency (#2, @achingbrain)

1.0.2 / 2013-08-27
==================

  * explicitly use `global` instead of being implicit
  * pin "component/global" to v2.0.1

1.0.1 / 2013-08-23
==================

  * package: add "component" section

1.0.0 / 2013-08-22
==================

  * Initial release
