module.exports = require('./globals.json');
