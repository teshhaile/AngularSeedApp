import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError, map, tap } from'rxjs/operators';
import { Http } from '@angular/http';
import { VSRRecord } from './vibe/VSRRecord';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'JSON to Table Example';
  constructor (private httpService: HttpClient,  private http: Http) { }

  resultObject: VSRRecord [];
  people: Person[]; 

  ngOnInit () {
    let vsURL = './assets/vsrRecord.json';
    let personURL = './assets/person.json';    
    let personHttpURL = `https://swapi.co/api/people/?page=2`;

    this.getPeopleFromWeb(personHttpURL);
    this.getVSRDataFromFile(vsURL);
    this.getOtherDataFromFile(personURL);
  }

  //'./assets/person.json'
  getPeopleFromWeb(url){  
    this.getPeople(url).subscribe(data => {
    this.people = data.results;
    console.log("data returned from web service call successfully.");   
    console.log("Peoples count from the web service call is " + this.people.length);
    });
  }

  //only the response object should be in the Json file (everything after "results":)
  getVSRDataFromFile(url){
    this.httpService.get(url).subscribe(
      data => {
        this.resultObject = data as VSRRecord [];	 // FILL THE ARRAY WITH DATA.        
          console.log("there are few records: " +  this.resultObject.length);
          console.log("first elment: " + this.resultObject[0].receiptNumber);
          console.log(this.resultObject);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

  //the url should point to http address: e.g `https://swapi.co/api/people/?page=2`;
  getPeople(url){
  return this.http.get(url).pipe(
      map(data => 
        data.json()
      ));    
  } 

  getOtherDataFromFile(url){
    this.httpService.get(url).subscribe(
      data => {
        this.people = data as Person [];	 // FILL THE ARRAY WITH DATA.          
        console.log("there are few people records: " +  this.people.length);
        console.log("first elment: " + this.people[0].name);
        console.log(this.people);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

}

export interface Person {
  name: string,
  birth_year: string,
  gender: string,
  hair_color: string,
  eye_color: string
}
export interface PetitionInfo{
  ReceiptNumber: string,
  PetitionVisaType: string,
  PetitionType: string,
  ReceiptDate: string,
  RecordTimeStamp: string,
  OrganizationDataSource: string,
  OrganizationName: string
}