export interface DNBCompanyFinancialInformation {

}
