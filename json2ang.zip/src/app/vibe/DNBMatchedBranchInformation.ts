import { AddressT } from "src/app/vibe/AddressT";

export interface DNBMatchedBranchInformation {
		agnID: String,
	    address: AddressT,
	    organizationDUNSNumber: string
	}

