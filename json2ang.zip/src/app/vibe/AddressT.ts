export interface AddressT {
	addressID: String,						   
	organizationName: String,
	telephoneNumberFullID: String,
	streetFullText: String,
	streetExtensionText: String,
	locationCityName: String,
	locationPostalCode: String,
	locationStateName: String,
	locationCountryName: String
}
