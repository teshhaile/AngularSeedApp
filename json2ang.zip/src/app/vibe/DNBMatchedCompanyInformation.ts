import { AddressT } from "src/app/vibe/AddressT";

export interface DNBMatchedCompanyInformation {
	organizationName: String,
	address: AddressT,
	locationType: String,
	municipalZoningCode: String,
	organizationPhone: String,
	organizationDUNSNumber: String,
	globalUltimateDUNSNumber: String,
	globalUltimateCompanyName: String,
	relationshipToGlobal: String,
	foreignRelationshipIndicator: String,
	ownershipStatus: String
}
