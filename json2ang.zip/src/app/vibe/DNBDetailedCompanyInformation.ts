export interface DNBDetailedCompanyInformation {
    ceoName: String,
    legalStatusCode: String,
    importExport: String,
    berOfRelatedEntities: String,
    numberOfCorroboratingSources: number,
    totalTradePayments: String,
    numberOfEmployeesInUSA: String,
    numberOfEmployeesWorldWide: String,
    yearEstablished: String,
    managementControlYear: String,
    severeRisk: String,
    historyType: String,
    outOfBusinessIndicator: String,
    naicCodes: String,
    tradeStyleCodes: String,
    nonProfitIndicator: String,
    taxExemptIndicator: String
}
