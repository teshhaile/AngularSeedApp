import { AddressT } from "src/app/vibe/AddressT";

export interface aPetitionInfo {
	receiptNumber: String,
	petitionVisaType: String,
	petitionType: String,
	receiptDate: String,
	recordTimeStamp: String,
	organizationDataSource: String,
	organizationName: String,
	address: AddressT,
	dolEtaCaseNumber: String
}
