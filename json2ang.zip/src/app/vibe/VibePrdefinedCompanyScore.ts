export interface VibePrdefinedCompanyScore {
	 	overrideScore: String,
	 	overrideScoreSource: String,
	 	ScoreValidUntil: String,
	 	organizationRelationship: String,
	 	comment: String
}
