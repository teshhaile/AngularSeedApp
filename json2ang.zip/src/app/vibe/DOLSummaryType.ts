export interface DOLSummaryType {
petitionID: String,
etaStatus: String,
etaCaseNumber: String,
filingDate: String,
etaVisaType: String,
employerName: String,
fein: String,
jobTitle: String,
totalWorkerPositions: String,
validStartDate: String,
validEndDate: String,
previousEtaFilings: String
}
