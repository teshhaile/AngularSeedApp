export interface DNBCompanyExecutiveBio {
    executive1: String,
    executive2: String,
    executive3: String
}
