export interface ManualSearchInfo {
	organizationName: String,
    address: String,
    relatedToPetitioner: String
}
