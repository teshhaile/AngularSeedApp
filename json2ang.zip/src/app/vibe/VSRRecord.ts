import { aPetitionInfo } from "./PetitionInfo";
import { ManualSearchInfo } from "./ManualSearchInfo";
import { VIBEScoreResult } from "./VIBEScoreResult";
import { VibePrdefinedCompanyScore } from "./VibePrdefinedCompanyScore";
import { DNBMatchedBranchInformation } from "./DNBMatchedBranchInformation";
import { DNBDetailedCompanyInformation } from "./DNBDetailedCompanyInformation";
import { DNBCompanyExecutiveBio } from "./DNBCompanyExecutiveBio";
import { DNBCompanyFinancialInformation } from "src/app/vibe/DNBCompanyFinancialInformation";
import { DOLSummaryType } from "src/app/vibe/DOLSummaryType";
import { DNBMatchedCompanyInformation }  from "src/app/vibe/DNBMatchedCompanyInformation";

export interface VSRRecord {
    scoreID: string,
    adjudicativeStatus: string,
    dataInquiryStatus: string,
    receiptNumber: string,
    petitionInformation: aPetitionInfo,
    manualSearchInfo: ManualSearchInfo,
    vibeScoreResult: VIBEScoreResult,
    vibePreDefinedCompanyScore: VibePrdefinedCompanyScore,
    dnbMatchedBranchInformation: DNBMatchedBranchInformation,
    dnbMatchedCompanyInformation: DNBMatchedCompanyInformation,
    dnbDetailedCompanyInformation: DNBDetailedCompanyInformation,
    dnbCompanyExecutiveBio: DNBCompanyExecutiveBio,
    dnbCompanyFinancialInformation: DNBCompanyFinancialInformation,
    dolSummary: DOLSummaryType
}
