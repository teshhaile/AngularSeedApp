export interface VIBEScoreResult {
    score: String,
    scoreRunTimeStamp: String,
    matched: String,
    confidenceFactor: number,
    i140CountInLast12Month: number,
    i129CountInLast12Month: number,
    i360CountInLast12Month: number,
    i485JCountInLast12Month: number
}
