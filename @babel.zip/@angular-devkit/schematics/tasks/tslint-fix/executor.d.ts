import { TaskExecutor } from '../../src';
import { TslintFixTaskOptions } from './options';
export default function (): TaskExecutor<TslintFixTaskOptions>;
