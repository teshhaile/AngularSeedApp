import { Type } from '@angular/core';
export declare const CLR_LOADING_BUTTON_DIRECTIVES: Type<any>[];
export declare class ClrLoadingButtonModule {
}
