import { Type } from '@angular/core';
export declare const CLR_BUTTON_GROUP_DIRECTIVES: Type<any>[];
export declare class ClrButtonGroupModule {
}
