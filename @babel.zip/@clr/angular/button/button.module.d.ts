export declare class ClrButtonModule {
}
