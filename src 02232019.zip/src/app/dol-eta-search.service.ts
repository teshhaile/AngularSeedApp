import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { DolProxy } from './shared/dol_proxy';
import { GetDolDetailByPetitionIDResponseProxy} from './shared/dolPetitionResponse_proxy'
import { GetDolDetailByPetitionIDResponseProxy as dol9035v1Proxy} from './shared/9035v1_proxies'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { AppSettings } from './shared/app-settings'
import { Component, Input, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DolEtaSearchService {

  private petitionURL = '/vibe-plus/rest/dol/petition-id/';
  private caseURL = '/vibe-plus/rest/dol/case-id/';
  constructor(private http: HttpClient) { }

  getDolByCaseId(caseId: string): Observable<DolProxy> {
    const url = `${this.caseURL}${caseId}`;
    return this.http.get<DolProxy>(url).pipe(
      tap(_ => console.log(`get Case #=${caseId}`)),
      catchError(this.handleError<DolProxy>(`error get Case # ${caseId}`))
    );
  }
  getDolByPettitionId(petitionId: string): Observable<GetDolDetailByPetitionIDResponseProxy> {
    const url = `${this.petitionURL}${petitionId}`;
    return this.http.get<GetDolDetailByPetitionIDResponseProxy>(url).pipe(
      tap(_ => console.log(`get Case #=${petitionId}`)),
      catchError(this.handleError<GetDolDetailByPetitionIDResponseProxy>(`error get Case # ${petitionId}`))
    );
  }
  getDolByPettitionId9035v1(petitionId: string): Observable<dol9035v1Proxy> {
    const url = `${this.petitionURL}${petitionId}`;
    return this.http.get<dol9035v1Proxy>(url).pipe(
      tap(_ => console.log(`get Case #=${petitionId}`)),
      catchError(this.handleError<dol9035v1Proxy>(`error get Case # ${petitionId}`))
    );
  }
  getDolByCaseIdFile(petitionId: string): Observable<DolProxy>  {

    const url = AppSettings.DOL_DATA_JSON;
    return this.http.get<DolProxy>(url).pipe(
      tap(data =>
        this.log("The fetched ETA CASE SourceTransactionID is: " + data)
      ));
  }
   /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  private log(message: string) {
    console.log(`ETA: ${message}`);

  }
}
