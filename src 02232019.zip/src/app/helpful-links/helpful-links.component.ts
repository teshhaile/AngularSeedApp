import { Component, OnInit } from '@angular/core';
import { SmartSearchService }  from "../smart-search.service"
import { SmartSearchModel }  from "../shared/smart-search-model"

@Component({
  selector: 'app-helpful-links',
  templateUrl: './helpful-links.component.html',
  styleUrls: ['./helpful-links.component.css']
})

export class HelpfulLinksComponent implements OnInit {

  message: SmartSearchModel; 
  constructor(private ssb: SmartSearchService) { }
  ngOnInit() {
    this.ssb.currentMessage.subscribe(message => this.message = message);
  }
}
