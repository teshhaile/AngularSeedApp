import { TestBed } from '@angular/core/testing';

import { VsrManualSearchService } from './vsr-manual-search.service';

describe('VsrManualSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VsrManualSearchService = TestBed.get(VsrManualSearchService);
    expect(service).toBeTruthy();
  });
});
