export class SearchFunctions{
    //public searchType: string;
    public id: string; 
    public display: string; 
    public description: string;
}
