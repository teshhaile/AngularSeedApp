import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { SearchTypes } from './search-types';

@Component({
  selector: 'app-smart-search-box',
  templateUrl: './smart-search-box.component.html',
  styleUrls: ['./smart-search-box.component.css']
})
export class SmartSearchBoxComponent implements OnInit {
  @Output() duns = new EventEmitter<string>();
  loading = false;
  appsAlert = "";
  

  model = {
    searchById: "", 
    searchByIdRegex: "", 
    selectedSearchType: "",
    selectedSearchTypeIndex: 0,
    selectedSearchFunction: "",
    helperText:"",
    functionDescription:""
  }

                    
  @ViewChild("inputBox") _el: ElementRef;

  constructor(private router: Router) {
    console.log("in constructor");
  }


  setFocus() {
    //this._el.nativeElement.focus();
  }
  ngAfterViewInit() {
    //this._el.nativeElement.focus();
  }

  searchTypes : SearchTypes[]; 

  ngOnInit() {
    console.log("in ngInit");
    this.searchTypes = [
        {id: "vsr", display: "VSR", functions: [ {id: "receiptNumber", display: "Receipt Number", description: "VIBE Status Report Search"}]},
        {id: "previousFilings", display: "Previous Filings", functions: [ {id: "pfDuns", display: "DUNS Number", description: "3-year USCIS previous filings associated with the input DUNS if the result returned with a cc > 6"},
                                                                          {id: "pfFein", display: "FEIN Number", description: "3-year USCIS previous filings associated with the input FEIN based on the C3 data"},
                                                                          {id: "pfBA", display: "Business Name and Address", description: "3-year USCIS previous filings associated with the input Business Name/Address if the result returned with a cc > 6"},
                                                                        ]},
        {id: "prevEtaFilings", display: "Previous ETA Filings", functions: [ {id: "pfEta", display: "DOL ETA Case Number", description: "USCIS filings associated with the input ETA case Number (Except for ETA9089)"}]}
      ];
 

    if (this.router.url.startsWith('/vsr')) {
      console.log("VSR URL LOADED"); 
      this.model.selectedSearchType="vsr";
      this.model.selectedSearchTypeIndex=0; 
      this.model.selectedSearchFunction="receiptNumber";
      this.model.functionDescription=this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;

    }else if (this.router.url.startsWith('/previous-filings')) {
      console.log("PREVIOUS FILINGS URL LOADED"); 
      this.model.selectedSearchType="previousFilings";
      this.model.selectedSearchTypeIndex=1; 
      this.model.selectedSearchFunction="pfDuns";
      this.model.functionDescription=this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
      
    }else if (this.router.url.startsWith('/previous-eta-filings')) {
      console.log("PREVIOUS ETA FILINGS URL LOADED"); 
      this.model.selectedSearchType="prevEtaFilings";
      this.model.selectedSearchTypeIndex=2; 
      this.model.selectedSearchFunction="pfEta";
      this.model.functionDescription=this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
    }
  }

  private onSelectFunction(selectedOption) {
    console.log("searchFunction="+selectedOption.value); 
    switch (selectedOption.value) {
      case "receiptNumber":
        this.model.functionDescription = "VIBE Status Report";
        this.model.selectedSearchFunction="vsr";
        this.model.searchByIdRegex="[A-Z]{3}\d{10}";

        break;
      case "pfDuns":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input DUNS if the result returned with a cc > 6";
        this.model.selectedSearchFunction="pfDuns";
        break;
      case "pfBA":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input Business Name/Address if the result returned with a cc > 6";
        this.model.selectedSearchFunction="pfBA";
        break;
      case "pfFein":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input FEIN based on the C3 data";
        this.model.selectedSearchFunction="pfFein";
        break;
      case "pfEta":
        this.model.functionDescription = "USCIS filings associated with the input ETA case Number (Except for ETA9089)";
        this.model.selectedSearchFunction="pfEta";
        break;

      default:
        this.model.functionDescription = "Receipt Number";
        this.model.selectedSearchFunction="vsr";
        break;
        this.setFocus();
        
    }

    //this.functionDescription = this.searchCriteriaDescriptions[fn.selectedIndex];
    this.setFocus();
  }


  onSearchTypeSelect(selectedOption) {
    console.log("searchType="+selectedOption.target.value); 
    switch (selectedOption.target.value) {
      case "vsr":
        this.model.selectedSearchType="vsr";
        this.model.selectedSearchTypeIndex=0; 
        this.model.selectedSearchFunction="receiptNumber";
        this.model.functionDescription=this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        break;
      case "previousFilings":
        console.log("in prev filings");
        this.model.selectedSearchType="previousFilings";
        this.model.selectedSearchTypeIndex=1; 
        this.model.selectedSearchFunction="pfDuns";
        this.model.functionDescription=this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        break;
      case "prevEtaFilings":
        this.model.selectedSearchType="prevEtaFilings";
        this.model.selectedSearchTypeIndex=2; 
        this.model.selectedSearchFunction="pfEta";
        this.model.functionDescription=this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        break;


      /*
        //Future functionality
        case "ETA Lookup":
        this.searchFunctions = ["DOL ETA Case Number"];
        this.functionDescription = "The actual ETA document in the VIBE template (Except for ETA9089)  ";
        break;
        */
      default:
       
        break;
        
    }

    this.setFocus();
    this.model.searchById = "";
  }


  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  searchButtonClicked(): void {
    console.log("Search button clicked: " + JSON.stringify(this.model)); 
    switch(this.model.selectedSearchFunction){
      case "receiptNumber":
        this.model.functionDescription="vsr"
        this.model.functionDescription = "VIBE Status Report";
        this.model.searchByIdRegex="[A-Z]{3}\d{10}";
        break;
    case "pfDuns":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input DUNS if the result returned with a cc > 6";
        this.model.selectedSearchFunction="pfDuns";
        console.log(this.model.searchById);
        this.duns.emit(this.model.searchById);
        
      break;
    case "pfBA":
      this.model.functionDescription = "3-year USCIS previous filings associated with the input Business Name/Address if the result returned with a cc > 6";
      this.model.selectedSearchFunction="pfBA";
      break;
    case "pfFein":
      this.model.functionDescription = "3-year USCIS previous filings associated with the input FEIN based on the C3 data";
      this.model.selectedSearchFunction="pfFein";
      break;
    case "pfEta":
      this.model.functionDescription = "USCIS filings associated with the input ETA case Number (Except for ETA9089)";
      this.model.selectedSearchFunction="pfEta";
      break;

    default:
      this.model.functionDescription = "Receipt Number";
      this.model.selectedSearchFunction="vsr";
      break;
      this.setFocus();
    }
  }

  refresh(): void {

  }

}
