import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { SearchTypes } from './search-types';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { SmartSearchService } from '../smart-search.service';  
import { SmartSearchModel } from '../shared/smart-search-model'; 
import { ClrForm } from '@clr/angular';
import { stringify } from '@angular/core/src/render3/util';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';



@Component({
  selector: 'app-smart-search-box',
  templateUrl: './smart-search-box.component.html',
  styleUrls: ['./smart-search-box.component.css']
})
export class SmartSearchBoxComponent implements OnInit {

  model: SmartSearchModel;
  pfAddress: VSRResubmitAddress;
  appsAlert = "";
  searchTypes: SearchTypes[];
  appRouter: Router;
  showModal: boolean = true; 

  newMessage(){
    console.log("sending new message");
    this.model.searchById = this.model.searchById.toUpperCase();
    this.data.changeMessage(this.model);
  }

  @ViewChild("inputBox") _el: ElementRef;

  constructor(private router: Router, private data: SmartSearchService) {
    this.appRouter =router;  //save router handle so we can switch pages based on function selection

    console.log("in ssb constructor");

    //select he default secondary search function based on the first dropdown 
    this.router.events.subscribe((event: Event) => {

      if (event instanceof NavigationStart) {
        // Show loading indicator
        console.log("loading url=" + event.url);

        if (event.url.startsWith('/vsr')) {
          console.log("VSR URL LOADED");
          this.model.selectedSearchType = "vsr";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "receiptNumber";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error="";

        } else if (event.url.startsWith('/previous-filings')) {
          console.log("PREVIOUS FILINGS URL LOADED");
          this.model.selectedSearchType = "previousFilings";
          this.model.selectedSearchTypeIndex = 1;
          this.model.selectedSearchFunction = "pfDuns";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error="";

        } else if (event.url.startsWith('/previous-eta-filings')) {
          console.log("PREVIOUS ETA FILINGS URL LOADED");
          this.model.selectedSearchType = "prevEtaFilings";
          this.model.selectedSearchTypeIndex = 2;
          this.model.selectedSearchFunction = "pfEta";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error="";

        } else if (event.url.startsWith('/dol-eta-lookup')) {
          console.log("DOL ETA SEARCH LOADED");
          this.model.selectedSearchType = "dolEtaLookup";
          this.model.selectedSearchTypeIndex = 3;
          this.model.selectedSearchFunction = "dolEta";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error="";
          
        } else {
          //by default 
          this.model.selectedSearchType = "vsr";
          this.model.selectedSearchTypeIndex = 0;
          this.model.selectedSearchFunction = "receiptNumber";
          this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
          this.model.searchById = "";
          this.model.error="";
        }

      }

      if (event instanceof NavigationEnd) {
        // Hide loading indicator
        console.log("done loading");
      }

      if (event instanceof NavigationError) {
        // Hide loading indicator
        console.log("loading error");
        // Present error to user
        console.log(event.error);
      }
    });

  }

  pfAddressSearchEventHandler(address){
    console.log("Search received address");
    console.log(address);
    this.model.selectedSearchType = "previousFilings";
    this.model.selectedSearchFunction="pfBA";
    this.model.searchById="";
    this.model.address=address;
    this.newMessage();

  }

  setFocus() {
    //this._el.nativeElement.focus();
  }
  ngAfterViewInit() {
    //this._el.nativeElement.focus();
  }



  ngOnInit() {

   // this.pfAddressSearched = pfAddressSearched();
    this.data.currentMessage.subscribe(message => this.model = message); 
    console.log("in ssb ngInit");
    this.searchTypes = [
      { id: "vsr", display: "VSR", functions: [{ id: "receiptNumber", display: "Receipt Number", description: "VIBE Status Report Search" }] },
      {
        id: "previousFilings", display: "Previous Filings", functions: [{ id: "pfDuns", display: "DUNS Number", description: "3-year USCIS previous filings associated with the input DUNS if the result returned with a cc > 6" },
        { id: "pfFein", display: "FEIN Number", description: "3-year USCIS previous filings associated with the input FEIN based on the C3 data" },
        { id: "pfBA", display: "Business Name and Address", description: "3-year USCIS previous filings associated with the input Business Name/Address if the result returned with a cc > 6" },
        ]
      },
      { id: "prevEtaFilings", display: "DOL Previous ETA Filings", functions: [{ id: "pfEta", display: "DOL ETA Case Number", description: "USCIS filings associated with the input ETA case Number (Except for ETA9089)" }] },
      { id: "dolEtaLookup", display: "DOL ETA Lookups", functions: [{ id: "dolEta", display: "DOL ETA Case Number", description: "DOL ETA Search" }] }
    ];

    //this.functionDescription = this.searchCriteriaDescriptions[fn.selectedIndex];
    this.setFocus();
  }


  //executed when the first search drop down changes 
  onSearchTypeSelect(selectedOption) {
    console.log("searchType=" + selectedOption.target.value);
    switch (selectedOption.target.value) {
      case "vsr":
        this.model.selectedSearchType = "vsr";
        this.model.selectedSearchTypeIndex = 0;
        this.model.selectedSearchFunction = "receiptNumber";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/vsr']); 
        break;
      case "previousFilings":
        console.log("in prev filings");
        this.model.selectedSearchType = "previousFilings";
        this.model.selectedSearchTypeIndex = 1;
        this.model.selectedSearchFunction = "pfDuns";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/previous-filings']); 
        break;
      case "prevEtaFilings":
        this.model.selectedSearchType = "prevEtaFilings";
        this.model.selectedSearchTypeIndex = 2;
        this.model.selectedSearchFunction = "pfEta";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/previous-eta-filings']); 
        break;
      case "dolEtaLookup":
        this.model.selectedSearchType = "dolEtaLookup";
        this.model.selectedSearchTypeIndex = 3;
        this.model.selectedSearchFunction = "dolEta";
        this.model.functionDescription = this.searchTypes[this.model.selectedSearchTypeIndex].functions[0].description;
        this.appRouter.navigate(['/dol-eta-lookup']); 
        break;
      default:

        break;

    }

    this.setFocus();
    this.model.searchById = "";
  }


  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  searchButtonClicked(event): void {
    
    console.log("Search button clicked: " + JSON.stringify(this.model));
    switch (this.model.selectedSearchFunction) {
      case "receiptNumber":
        if (this.validateReceiptNumber(this.model.searchById)) this.newMessage();
      break;
      case "pfDuns":
        if (this.validateDuns(this.model.searchById)) this.newMessage();
        break;
      case "pfBA":
        if (this.validateAddress(this.model.address)) this.newMessage();
        break;
      case "pfFein":
        if (this.validateFein(this.model.searchById)) this.newMessage();
        break;

      case "pfEta":
        this.newMessage();
        break;

      case "dolEta":
        if (this.validateEtaCaseNumber(this.model.searchById)) this.newMessage();
        break;

        default:
        this.newMessage();
        break;
        this.setFocus();
    }
  }

  onSelectFunction(event): void {
    
    console.log("Search function selected: " + JSON.stringify(this.model));
    switch (this.model.selectedSearchFunction) {
      case "receiptNumber":
        this.model.functionDescription = "vsr"
        this.model.functionDescription = "VIBE Status Report";
      break;
      case "pfDuns":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input DUNS if the result returned with a cc > 6";
        this.model.selectedSearchFunction = "pfDuns";
        break;
      case "pfBA":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input Business Name/Address if the result returned with a cc > 6";
        this.model.selectedSearchFunction = "pfBA";
        break;
      case "pfFein":
        this.model.functionDescription = "3-year USCIS previous filings associated with the input FEIN based on the C3 data";
        this.model.selectedSearchFunction = "pfFein";
        break;

        case "pfEta":
        this.model.functionDescription = "USCIS filings associated with the input ETA case Number (Except for ETA9089)";
        this.model.selectedSearchFunction = "pfEta";
        break;

      case "dolEta":
        this.model.functionDescription = "DOL ETA Search";
        this.model.selectedSearchFunction = "dolEta";
        break;

        default:
        this.model.functionDescription = "Receipt Number";
        this.model.selectedSearchFunction = "vsr";
        break;
        this.setFocus();
    }
  }



  validateEtaCaseNumber(etaCaseId: string): boolean{
    var etaCaseId = etaCaseId.trim().replace(/-/g,"").toUpperCase();
    if ((etaCaseId != '') && (etaCaseId.length == 15) && (etaCaseId.indexOf("H")==0) && (Number(etaCaseId.substring(1)))){
      console.log("valid dol case #");
      this.model.error="";
      return true;  
    } else {
      console.log("invalid dol case #");
      this.model.error="Required format: H-000-00000-000000 (For ETA 9142 Only)";
      return false;
    }
  }


  validateDuns(duns: string): boolean{
    duns = duns.trim(); 
    
    if (duns.length == 9 && duns.match(/\d{9}/g)){
      console.log("valid duns #");
      this.model.error="";
      return true;
    }
    console.log("invalid duns #");
    this.model.error="A valid DUNS Number format is 9 digits.";
  
    return false;
  }

  validateAddress(address:VSRResubmitAddress): boolean{
    return true;
  }
  
  validateFein(fein: string): boolean{
    fein = fein.trim(); 
    
    if (fein.length == 9 && fein.match(/\d{9}/g)){
      console.log("valid fein #");
      this.model.error="";
      return true;
    }
    console.log("invalid fein #");
    this.model.error="A valid fein Number format is 9 digits.";
  
    return false;
  }


  
  validateReceiptNumber(receiptNumber: string): boolean{
    receiptNumber = receiptNumber.trim(); 

    if (receiptNumber.length ==13 && receiptNumber.match(/[A-Z]{3}\d{10}/g)){
      this.model.error="";
      return true;
    }
    console.log("invalid receipt #");
    this.model.error="Receipt Number format is 3 letters followed by 10 numerals (no more than 13 characters).";
    return false;
  }

  refresh(): void {

  }

}
