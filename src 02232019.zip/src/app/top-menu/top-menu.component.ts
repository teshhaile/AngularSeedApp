import { Component, OnInit } from '@angular/core';
import {TopMenuService} from './top-menu.service'
import { UserProfile } from '../shared/user-profile';
import { UserProfileService } from '../user-profile.service';



@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css'], 
  providers: [TopMenuService]
})

export class TopMenuComponent implements OnInit {


  userProfile: UserProfile; 
  myTabs : any; 

  private myUserProfileService : UserProfileService; 

  constructor(private userProfileService: UserProfileService) {
    this.myUserProfileService = userProfileService;
    this.myUserProfileService.getUserProfile().subscribe(
      data => {
        if (data) {
          this.userProfile = data;
          this.myTabs = data.topLevelNavigationBasedOnUserRole; 
          
          console.log("data="+JSON.stringify(data)); 
          
        }
        else {
          console.log("No user profile data");           
        }
      },
      error => {
        (async () => {
          console.log("User Not logged in"); 
          //this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC + ", " + JSON.stringify(error);
        })();
      }
    );

   }

  ngOnInit() {
    
  }

}
