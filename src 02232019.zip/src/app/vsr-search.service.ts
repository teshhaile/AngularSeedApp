import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { VsrProxy } from './shared/vsr-proxy';
import { AppSettings } from './shared/app-settings';
import { throwError } from 'rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/Observable/throw';

@Injectable({
  providedIn: 'root'
})

export class VsrSearchService {

  private vsrUrl = AppSettings.VSR_URL;
  constructor(private http: HttpClient) { }

  getVSR(receiptNumber: string): Observable<VsrProxy> {
    const url = `${this.vsrUrl}/${receiptNumber}`;
    return this.http.get<VsrProxy>(url).pipe(
      tap(_ => 
        this.log(`get VSR receipt #=${receiptNumber}`)
      )
      // ,     catchError(this.handleError<VsrProxy>(`error get VSR receipt # ${receiptNumber}`))     
      , catchError(this.handleErrorObservable)
      // ,     catchError(this.handleErrorObservable))
    );
  }
  getVSRHistory(receiptNumber: string): Observable<VsrProxy> {
    const url = `${this.vsrUrl}/${receiptNumber}/ALL`;
   // console.log("The url is: " + url) ;
    return this.http.get<VsrProxy>(url).pipe(
      tap(_ => this.log(`get VSR receipt #=${receiptNumber}`))
      // ,     catchError(this.handleError<VsrProxy>(`error get VSR receipt # ${receiptNumber}`))     
      , catchError(this.handleErrorObservable)
      // ,     catchError(this.handleErrorObservable))
    );
  }

  private handleErrorObservable(error: Response | any) {
    console.error("the error thrown is: " + (error.message));
    let statusMessage: string = "";
    // return Observable.throw(error.message || error);
    //return Observable.throw(new Error(error.status));
    let status: string = JSON.stringify(error.status);
    switch (status) {
      case '400':
        statusMessage = AppSettings.HTTP_STATUS_400;
        break;
      case '404':
        statusMessage = AppSettings.HTTP_STATUS_404;
        break;
      case '500':
        statusMessage = AppSettings.HTTP_STATUS_500;
        break;
      case '503':
        statusMessage = AppSettings.HTTP_STATUS_503;
        break;
      case '502':
        statusMessage = AppSettings.HTTP_STATUS_502;
        break;
      case '599':
        statusMessage = AppSettings.HTTP_STATUS_599;
        break;
      case '408':
        statusMessage = AppSettings.HTTP_STATUS_408;
        break;
      default:
        statusMessage = AppSettings.HTTP_STATUS_UNKNOWN;
  }
    return throwError(statusMessage);
  }

  getVSRFromFile(receiptNumber: string): Observable<VsrProxy> {

    const url = AppSettings.DOL_INFORMATION_JSON;
    return this.http.get<VsrProxy>(url).pipe(
      tap(data =>
        this.log("The fetched VsrResubmitResponse SourceTransactionID is: " + data.VsrGetResponse.SourceTransactionID)
      ));
  }

  
  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  private log(message: string) {
   // console.log(`VSR: ${message}`);

  }
}
