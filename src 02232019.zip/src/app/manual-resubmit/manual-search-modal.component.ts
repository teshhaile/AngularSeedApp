import { Component, EventEmitter, Output, ViewChild, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgModule, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Vsr, PetitionInformation, VsrGetResponse } from '../shared/vsr';
import { VsrManualSearchService } from '../vsr-manual-search.service';
import { VSRResubmitRequest, VSRResubmitAddress, VsrResubmitResponse, VsrResubmit, VsrRecordEntity } from '../shared/vsr-resubmit';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AppSettings } from '../shared/app-settings';
import { ClrFormsNextModule } from '@clr/angular';

function dunsValidator(control: FormControl): { [key: string]: any } {
    const value: string = control.value || '';
    const valid = value.match(/^\d{9}$/);
    return valid ? null : { duns: true };
}


async function delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

@Component({
    selector: 'manual-search-modal',
    templateUrl: './manual-search-modal.component.html',
    styleUrls: ['./manual-search.component.css'],
})
export class ManualSearchModalComponent implements OnInit, OnChanges {
    vsrResubmitRequest: VSRResubmitRequest

    @Input() vsrResponse: VsrRecordEntity;
    @Input() showFormModal: boolean = false;
    @Output() resubmitBegin: EventEmitter<string> = new EventEmitter<string>();
    @Output() resubmitComplete: EventEmitter<string> = new EventEmitter<string>();
    @Output() showModalChange: EventEmitter<boolean> = new EventEmitter<boolean>();

    countries: CountryStatesProvinces[];
    defaultCountry: string = "United States"
    endUserID: string;
    formResubmit;
    loading: boolean = false;
    petitioner: PetitionInformation;
    receiptNumber: string;
    resubmitDetails: Array<ResubmitDetails>;
    resubmitStatusType: string = ""
    selectedCountry: CountryStatesProvinces;
    selectedProvince: CountryStatesProvinces;
    sourceSystemID;
    sourceTransactionID;
    statesOrProvinces: CountryStatesProvinces[];
    statusMessage: string = "in progress";
    vsrResubmitResponse: VsrResubmitResponse;

    constructor(private httpService: HttpClient, private router: Router,
        private fb: FormBuilder, private vsrManualSearchService: VsrManualSearchService) {
    }

    ngOnChanges(changes: SimpleChanges) {
        // console.log("change is happening.")
    }
    ngOnInit() {

        this.resubmitDetails = [];
        this.sourceSystemID = AppSettings.SOURCE_SYSTEM_ID;
        this.sourceTransactionID = AppSettings.SOURCE_TRANSACTION_ID;
        this.endUserID = AppSettings.END_USER_ID;
        this.petitioner = this.vsrResponse.PetitionInformation;
        this.receiptNumber = this.petitioner.ReceiptNumber;
        this.initFormResubmit();



    }

    private initFormResubmit() {
        this.statusMessage = "";
        this.formResubmit = this.fb.group({
            index: [{ value: null, disabled: true }],
            ReceiptNumber: [""],
            PetitionVisaType: [""],
            ReceiptDate: [""],
            RecordTimeStamp: [""],
            OrganizationDataSource: [""],
            OrganizationName: ["", Validators.required],
            StreetFullText: ["", Validators.required],
            LocationCityName: [""],
            LocationStateName: ["", Validators.required],
            LocationPostalCode: [""],
            DunsNumber: ["", dunsValidator],
            AddressCountry: [""]
        });
        this.populateCountries();
        this.populateStates();        
        
        this.formResubmit.controls["AddressCountry"].value = "UNITED STATES";
        this.formResubmit.controls["LocationStateName"].value = null;
       // this.formResubmit.reset() // reset editable form fields to empty
    }
    private disableControl(fieldName) {
        let retVal: boolean = false;
        if (fieldName === "DunsNumber") {
            let ctrlOrganizationName = this.formResubmit.controls["OrganizationName"];
            let ctrlStreetFullText = this.formResubmit.controls["StreetFullText"];
            let ctrlLocationCityName = this.formResubmit.controls["LocationCityName"];
            let ctrlLocationPostalCode = this.formResubmit.controls["LocationPostalCode"];
            let ctrlLocationStateName = this.formResubmit.controls["LocationStateName"];
            if (
                this.controlIsNotEmpty(ctrlOrganizationName) ||
                this.controlIsNotEmpty(ctrlStreetFullText) ||
                this.controlIsNotEmpty(ctrlLocationCityName) ||
                this.controlIsNotEmpty(ctrlLocationPostalCode) ||
                this.controlIsNotEmpty(ctrlLocationStateName)) {
                //this.formResubmit.controls["DunsNumber"].value = "qqqqq" ;
                retVal = true;
            }
            else
                retVal = false;
        }
        else if (this.controlIsNotEmpty(this.formResubmit.controls["DunsNumber"]))
            retVal = true;
        else retVal = false;

        return retVal;
    }

    private controlIsNotEmpty(ctrl: any) {
        if (ctrl && ctrl.value !== "" && ctrl.value !== null)
            return true;
        else
            return false;
    }

    private populateStates() {
        const url = AppSettings.US_STATES_JSON;
        this.httpService.get(url).subscribe(
            data => {
                this.statesOrProvinces = data as CountryStatesProvinces[];
            }
        );
    }

    private populateProvinces() {
        const url = AppSettings.PROVINCES_JSON;
        this.httpService.get(url).subscribe(
            data => {
                if (data)
                    this.statesOrProvinces = data as CountryStatesProvinces[];
                else
                    this.statesOrProvinces = [];
            }
        );
    }

    private populateCountries() {
        const url = AppSettings.COUNTRIES_JSON;
        this.httpService.get(url).subscribe(
            data => {
                this.countries = data as CountryStatesProvinces[];

            }
        );
    }

    private onSelect(countryId: string) {
        if (countryId.toUpperCase() == "CANADA")
            this.populateProvinces();
        else if (countryId.toUpperCase() == "UNITED STATES")
            this.populateStates();
        else
            this.statesOrProvinces = [];
        this.formResubmit.controls["LocationStateName"].value = null;

    }

    private onResubmit(e) {
        this.loading = true;
        let index = this.formResubmit.getRawValue().index
        if (index != null) {
            this.resubmitDetails[index] = this.formResubmit.value;
            this.prepareResubmitRequest(index);
        }
        else {
            this.resubmitDetails.push(this.formResubmit.value)
            this.prepareResubmitRequest(0);
        }
        sessionStorage.setItem("resubmitDetails", JSON.stringify(this.resubmitDetails));
        this.statusMessage = "";
        this.resubmitQuery();
    }

    private prepareResubmitRequest(ind): VSRResubmitRequest {
        let curIndex: number = 0;
        if (curIndex == 0)
            curIndex = this.resubmitDetails.length - 1;
        else
            curIndex = ind;
        this.vsrResubmitRequest = new VSRResubmitRequest();
        this.vsrResubmitRequest.sourceSystemID = this.sourceSystemID;
        this.vsrResubmitRequest.sourceTransactionID = this.sourceTransactionID;
        this.vsrResubmitRequest.receiptNumber = this.petitioner.ReceiptNumber;
        this.vsrResubmitRequest.duns = this.resubmitDetails[curIndex].DunsNumber;
        this.vsrResubmitRequest.endUserID = this.endUserID;
        this.vsrResubmitRequest.address = this.getAddress(curIndex);
        return this.vsrResubmitRequest;
    }

    private getAddress(curIndex: number): VSRResubmitAddress {
        let addr: VSRResubmitAddress = new VSRResubmitAddress();
        addr.organizationName = this.resubmitDetails[curIndex].OrganizationName;
        addr.streetFull = this.resubmitDetails[curIndex].StreetFullText;
        addr.city = this.resubmitDetails[curIndex].LocationCityName;
        addr.state = this.resubmitDetails[curIndex].LocationStateName;
        addr.postalCode = this.resubmitDetails[curIndex].LocationPostalCode;
        addr.country = this.resubmitDetails[curIndex].AddressCountry;
        return addr;
    }

    private resubmitCancelClick() {
        this.showModalChange.emit(false);
        this.loading = false;
        this.initFormResubmit();
        this.showFormModal = false;
    }


    private resubmitQueryFromFile() {
        const url = AppSettings.RESUBMIT_RESPONSE_JSON;
        this.vsrManualSearchService.getResubmitFromFile(url).subscribe(
            data => {
                this.returnResubmitResponse(data);
            }
        );
    }
    private resubmitQuery(): void {
        // console.log("the request is: " + JSON.stringify(this.vsrResubmitRequest));
        this.vsrManualSearchService.resubmitVSRRequestInJson(this.vsrResubmitRequest)
            .subscribe(resubmitResponse => {
                this.returnResubmitResponse(resubmitResponse);
            },
                error => {
                    (async () => {
                        //await delay(10000); // to be used for simulating service timeout or long running query
                        //console.log('after delay');

                        console.log("error is thrown: " + error);
                        this.showFormModal = true;
                        this.statusMessage = AppSettings.VSR_STATUS_CODE_003_DESC;
                        this.resubmitStatusType = "warning";
                    })();

                    this.loading = false;
                }
            );
    }

    private returnResubmitResponse(resubmitResponse: VsrResubmit) {

        //  console.log("the vsrResubmitResponse is: " + JSON.stringify(resubmitResponse));
        if (resubmitResponse != null && !JSON.stringify(resubmitResponse).includes("Error")) {
            this.vsrResubmitResponse = resubmitResponse.VsrResubmitResponse;
            if (this.vsrResubmitResponse && this.vsrResubmitResponse.ResponseStatusMessage != null) {
                if (this.vsrResubmitResponse.ResponseStatusMessage.StatusCode === AppSettings.VSR_STATUS_CODE_002) {
                    this.statusMessage = AppSettings.VSR_STATUS_CODE_002_DESC;

                    console.log("the status message is: " + this.statusMessage);
                    this.loading = false;
                    this.resubmitComplete.emit(this.statusMessage);
                    this.hideModalForm();
                }
                if (this.vsrResubmitResponse.ResponseStatusMessage.StatusCode === AppSettings.VSR_STATUS_CODE_001) {
                    this.showFormModal = true;
                    this.loading = false;
                    this.statusMessage = AppSettings.VSR_STATUS_CODE_001_DESC;
                    console.log("the status message is: " + this.statusMessage);
                    this.resubmitStatusType = "warning";
                }
            }
            else {

                (async () => { await delay(3000); })();
                console.log("the status message is: nothing so assume success");
                this.statusMessage = AppSettings.VSR_STATUS_CODE_002;
                this.resubmitComplete.emit(AppSettings.VSR_STATUS_CODE_002);
                this.hideModalForm();
            }
        }
        else {

            console.log("something happens, the response is null or has error. ");
            this.showFormModal = true;
            this.loading = false;
            if (JSON.stringify(resubmitResponse).includes("Error"))
                this.statusMessage = "Error:- internal error occurs while processing the request.";
            else
                this.statusMessage = AppSettings.VSR_STATUS_CODE_004_DESC;
            this.resubmitStatusType = "warning";
        }
    }

    private hideModalForm() {
        this.loading = false;
        this.showModalChange.emit(false);
        this.initFormResubmit();
    }
}

export class CountryStatesProvinces {
    name: string;
    abbreviation: string;
}

export class ResubmitDetails {
    ReceiptNumber: string;
    PetitionVisaType: string;
    ReceiptDate: string;
    RecordTimeStamp: string;
    OrganizationDataSource: string;
    OrganizationName: string;
    AddressCountry: string;
    StreetFullText: string;
    LocationCityName: string;
    LocationStateName: string;
    LocationPostalCode: string;
    DunsNumber: string;
}