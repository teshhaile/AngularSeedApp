import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolEtaFormV1Component } from './dol-eta-form-v1.component';

describe('DolEtaFormV1Component', () => {
  let component: DolEtaFormV1Component;
  let fixture: ComponentFixture<DolEtaFormV1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolEtaFormV1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolEtaFormV1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
