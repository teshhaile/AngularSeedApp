import { Component, OnInit, Input, NgModule } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridSortOrder } from '@clr/angular';
import {GetDolDetailByPetitionIDResponse,DolData, DOLDATA, DOLETACLOB} from '../shared/9035v1_interfaces'
import { DOLDATAProxy} from '../shared/dolPetitionResponse_proxy'
import { AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import { SmartSearchService }  from "../smart-search.service"
import { SmartSearchModel }  from "../shared/smart-search-model"
import { Subscription } from 'rxjs';
import { NumberTransformRoman } from './dol-eta-form-v1.pipe'


@Component({
  selector: 'app-dol-eta-form-v1',
  templateUrl: './dol-eta-form-v1.component.html',
  styleUrls: ['./dol-eta-form-v1.component.css'],
  providers: [ NumberTransformRoman ]
})
export class DolEtaFormV1Component implements OnInit {
  @Input() petitionId: string = "";//"147973101";
  @Input() dolEtaFormType: string = "";
  @Input() dolEtaFormVersion: string = "";
  testn = 1;
  showDol = false
  loading = false
  showEmployers = false
  showWorkSites = false
  showAddendum = false
  showSummary = false
  searchSubscription: Subscription;
  showStatemnts = false
  showStatemnts2 = false
  root: GetDolDetailByPetitionIDResponse;
  dol: DolData
  dolEta: DOLDATA
  DolEtaResult: DOLETACLOB;
  descSort = ClrDatagridSortOrder.DESC
  ascSort = ClrDatagridSortOrder.ASC
  appsAlert: string
  model = {
    DolEtaResults: [],
    caseNumber: '', //H30014321198839
    petitionNumber: '' //146845314
  }
  private dolSvc: DolEtaSearchService;
  constructor(private dolSearchService: DolEtaSearchService, private ssb: SmartSearchService, private router: Router, private toRomanNumeral: NumberTransformRoman) {
    this.dolSvc = dolSearchService

     //integration point with SSB
     this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      console.log("in dol form listner");
      console.log("search box: " + JSON.stringify(message));
      //this.getDolSearchByPetitionID(this.petitionId); 
      // if ((message.selectedSearchType=="dolEtaLookup") && 
      //     (message.selectedSearchFunction=="dolEta") && 
      //     (message.searchById!="") && 
      //     (message.searchById!=undefined)){
      //       this.model.caseNumber = message.searchById
      //       console.log("this.model.caseNumber="+this.model.caseNumber); 
      //       this.getDolSearchByCaseID(this.model.caseNumber);
      //       message.searchById="";

      // }
    }
    );
    
  }

  ngOnInit() 
  {
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEmployers = false
    this.model.petitionNumber = this.petitionId;
    console.log(this.petitionId)
  
    if(this.petitionId !== "" && this.dolEtaFormType !== ""){
    this.getDolSearchByPetitionID(this.model.petitionNumber);
    }


  }
  ngOnDestroy(){this.searchSubscription.unsubscribe();}

  getDolSearchByPetitionID(petitionNumber: string) {
    this.showSummary = false;
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEmployers = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByPettitionId9035v1(petitionNumber).subscribe(data => {
      console.log(data)
      // console.log(data.DolJsonData)
      // this.root = data;
      // console.log(this.root.DolJsonData)
      this.dol = <DolData>JSON.parse(data.GetDolDetailByPetitionIDResponse.DolJsonData)
      console.log(this.dol)
      this.dolEta = <DOLDATA> this.dol.DOL_DATA
      
      //this.dolEta = <DOLDATA> this.dol
      console.log(this.dolEta.DOL_ETA_CLOB)
      console.log("Is it an array: " + Array.isArray(this.dolEta.DOL_ETA_WORKSITES))
      if (Array.isArray(this.dolEta.DOL_ETA_WORKSITES)) {
        
        this.showWorkSites = true
      }
      
      if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
        this.showEmployers = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {
        this.model.DolEtaResults = []
        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          this.loading = false
          this.showDol = true
        } else {
            if(this.dolEta.DOL_ETA_CLOB.CASE_NUMBER == "remove"){
              this.loading = false
              this.showDol = false
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              
            }else {
              this.DolEtaResult = this.dolEta.DOL_ETA_CLOB;
              this.dolEta.DOL_ETA_CLOB = [];
              this.dolEta.DOL_ETA_CLOB.push(this.DolEtaResult)
              this.loading = false;
              this.showDol = true
            }
          
        }
        
      }
      //For Loading Animation
    this.showAddendum = this.showEmployers||this.showWorkSites 
    this.showSummary = true     
      this.loading=false
    },
    error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        //console.log('after delay');
        this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC + ", " + JSON.stringify(error);
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorkSites = false
        this.showEmployers = false
        this.showSummary = false;
      })();
      }
    )

  }

  toggleStmnts(){
    this.showStatemnts = !this.showStatemnts
  }
  toggleStmnts2(){
    this.showStatemnts2 = !this.showStatemnts2
  }
}
