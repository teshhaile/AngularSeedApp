import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Observable, of, from } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { ResponseContentType } from '@angular/http';
import { VsrComponent } from './vsr/vsr.component';
import { AppModule } from './app.module'
import { AppComponent } from './app.component';
import { GoogleMapsAPIWrapper, AgmCoreModule } from '@agm/core';
import { AppSettings } from './shared/app-settings'

@Injectable()
export class GeocodeService {

    constructor(private http: HttpClient) {
        
    }
 

    getLatLongForAddress(address = "111 Massachusetts Ave NW Washington, DC 20529") {


        var endpoint = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${AppSettings.API_KEY}`;
        //var endpoint = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}`;

       // console.log("endpoint="+endpoint)
        return this.http.get(endpoint).pipe(map(data => data))

    }

    getStreetViewForLatLong(latlong = "38.8977643,-77.0106754"){
        var endpoint  = `https://maps.googleapis.com/maps/api/streetview?size=400x400&location=${latlong}&fov=90&heading=235&pitch=10&key=${AppSettings.API_KEY}`
        //var endpoint  = `https://maps.googleapis.com/maps/api/streetview?size=400x400&location=${latlong}&fov=90&heading=235&pitch=10`//&key=AIzaSyCJhyfiijJ1tv36ZmiKTLvumGisY0QRcdg`
        return endpoint
        
        }
    
    getFullMapForLatLong(latlong = "38.8977643,-77.0106754"){
        var endpoint = "http://www.google.com/maps/place/" + latlong
        return endpoint
    }
    

    /*
    getVSR(receiptNumber: string): Observable<VsrProxy> {
        const url = `${this.vsrUrl}/${receiptNumber}`;
        return this.http.get<VsrProxy>(url).pipe(
          tap(_ => this.log(`get VSR receipt #=${receiptNumber}`)),
          catchError(this.handleError<VsrProxy>(`error get VSR receipt # ${receiptNumber}`))
        );
      }
*/
}

