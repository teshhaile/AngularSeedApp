import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VsrComponent } from "./vsr/vsr.component";
import { AdminComponent } from "./admin/admin.component";
import { HelpfulLinksComponent } from "./helpful-links/helpful-links.component";
import { RedReportsComponent } from "./red-reports/red-reports.component";
import { DolEtaSearchComponent } from "./dol-eta-search/dol-eta-search.component";
import { ImqComponent } from "./imq/imq.component";
import { PreviousFilingsComponent } from './previous-filings/previous-filings.component';
import { UserProfilesComponent } from './user-profile/user-profile.component';

//For testing only
import { TestComponent } from './test/test.component';

const routes: Routes = [
  {path: '', redirectTo: 'vsr', pathMatch: 'full'},

  //admin 
  {path: 'admin', component: AdminComponent},

  //user profile
  {path: 'user-profile', component: UserProfilesComponent},

  //helpful links
  {path: 'helpful-links', component: HelpfulLinksComponent},

  //test
  {path: 'test', component: TestComponent},

  //vsr
  {path: 'vsr', component: VsrComponent},
  {path: 'vsr/receipt/:id', component: VsrComponent },

  //red report
  {path: 'red-reports', component: RedReportsComponent},


  

  {path: 'dol-eta-lookup', component: DolEtaSearchComponent },

  {path: 'previous-eta-filings', component: PreviousFilingsComponent},
  {path: 'previous-eta-filings/petition/receipt/:id', component: DolEtaSearchComponent },

  {path: 'previous-filings', component: ImqComponent},
  {path: 'previous-filings/dolcase/:id', component: PreviousFilingsComponent},
  {path: 'previous-filings/duns/:id/:id2/:id3', component: PreviousFilingsComponent},
  {path: 'previous-filings/duns/:id', component: PreviousFilingsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
