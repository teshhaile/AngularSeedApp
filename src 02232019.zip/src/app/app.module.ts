import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { AgmCoreModule } from '@agm/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClarityModule, ClrFormsNextModule } from '@clr/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TopMenuComponent } from './top-menu/top-menu.component';
import { TopAlertsComponent } from './top-alerts/top-alerts.component';
import { SideNavigationComponent } from './side-navigation/side-navigation.component';
import { VsrComponent } from './vsr/vsr.component';
import { ScoreCardComponent } from './score-card/score-card.component';
import { AdminComponent } from './admin/admin.component';
import { RedReportsComponent } from './red-reports/red-reports.component';
import { GoogleMapsComponent } from './google-maps/google-maps.component';
import { DolEtaSearchComponent } from './dol-eta-search/dol-eta-search.component';
import { HttpModule } from '@angular/http';
import { ManualSearchModalComponent } from './manual-resubmit/manual-search-modal.component';
import { vsrCompareFormComponent } from './vsr/vsr-compare-form/vsr-compare-form.component';
import { DateFormatPipe } from './shared/dateFormat-pipe';
import { PreviousFilingsComponent } from './previous-filings/previous-filings.component';
import { VsrHistoryComponent } from './vsr/vsr-history/vsr-history.component';
import { vsrPrimaryFormComponent } from './vsr/vsr-primary-form/vsr-primary-form.component';
import { FouoComponent } from './fouo/fouo.component';
import { UserProfilesComponent } from './user-profile/user-profile.component';

import { SmartSearchBoxComponent } from './smart-search-box/smart-search-box.component';
import { HtmlEditorComponent } from './html-editor/html-editor.component';
import { HelpfulLinksComponent } from './helpful-links/helpful-links.component';
import { QuillModule } from 'ngx-quill';
import { TestComponent } from './test/test.component';
import { ImqComponent } from './imq/imq.component';
import { WaitSpinnerComponent } from './wait-spinner/wait-spinner.component';
import { AddressInputFormComponent } from './address-input-form/address-input-form.component';
import { GeocodeService } from './geocode.service';
import { UserInRoleService } from './user-profile/user-in-role.service';
import { DolEtaFormV1Component } from './dol-eta-form-v1/dol-eta-form-v1.component';
import { NumberTransformRoman } from './dol-eta-form-v1/dol-eta-form-v1.pipe';
// import { ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
@NgModule({
  declarations: [
    AppComponent,
    ManualSearchModalComponent,
    TopMenuComponent,
    TopAlertsComponent,
    SideNavigationComponent,
    VsrComponent,
    ScoreCardComponent,
    AdminComponent,
    VsrHistoryComponent,
    RedReportsComponent,
    GoogleMapsComponent,
    DolEtaSearchComponent,
    vsrCompareFormComponent, 
    vsrPrimaryFormComponent,
    DateFormatPipe, 
    PreviousFilingsComponent, 
    SmartSearchBoxComponent, 
    HtmlEditorComponent, 
    HelpfulLinksComponent,
    FouoComponent,
    UserProfilesComponent,
    TestComponent,
    ImqComponent,
    WaitSpinnerComponent,
    AddressInputFormComponent,DolEtaFormV1Component, NumberTransformRoman
    
   
    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    ClarityModule,
    ClrFormsNextModule,
    BrowserAnimationsModule,
    HttpClientModule,
    QuillModule
    // ScrollToModule.forRoot(),
    
  ],
 
  providers: [Title, GeocodeService, UserInRoleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
