import { Component, OnInit, Input } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridSortOrder } from '@clr/angular';
import { DolData, DOLDATA, DOLETACLOBEntity} from '../shared/dol_interfaces'
import { DolData as DolData2, DOLDATA  as DOLDATA2} from '../shared/dolPetitionResponse_interfaces'
import { DOLDATAProxy} from '../shared/dolPetitionResponse_proxy'
import { AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import { SmartSearchService }  from "../smart-search.service"
import { SmartSearchModel }  from "../shared/smart-search-model"
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-dol-eta-search',
  templateUrl: './dol-eta-search.component.html',
  styleUrls: ['./dol-eta-search.component.css']
})
export class DolEtaSearchComponent implements OnInit {

  private dolEtaUrl = '/vibe-plus/rest/dol/petition-id/';
  @Input() petitionId: string = "";

  showDol = false
  loading = false
  showEmployers = false
  showWorkSites = false
  showAddendum = false
  showSummary = false
  searchSubscription: Subscription;
  dol: any
  dolEta: any
  DolEtaResult: DOLETACLOBEntity;
  descSort = ClrDatagridSortOrder.DESC
  ascSort = ClrDatagridSortOrder.ASC
  appsAlert: string
  model = {
    DolEtaResults: [],
    caseNumber: '', //H30014321198839
    petitionNumber: '' //146845314
  }
  private dolSvc: DolEtaSearchService;
  constructor(private dolSearchService: DolEtaSearchService, private ssb: SmartSearchService, private router: Router) {
    this.dolSvc = dolSearchService

     //integration point with SSB
     this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      console.log("in dol eta listner");
      console.log("search box: " + JSON.stringify(message)); 
      if ((message.selectedSearchType=="dolEtaLookup") && 
          (message.selectedSearchFunction=="dolEta") && 
          (message.searchById!="") && 
          (message.searchById!=undefined)){
            this.model.caseNumber = message.searchById
            console.log("this.model.caseNumber="+this.model.caseNumber); 
            this.getDolSearchByCaseID(this.model.caseNumber);
            message.searchById="";

      }
    }
    );
    
  }

  ngOnInit() 
  {
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEmployers = false
    this.model.petitionNumber = this.petitionId;
    console.log(this.petitionId)
  
    if(this.petitionId !== ""){
    this.getDolSearchByPetitionID(this.model.petitionNumber);
    }


  }
  getDolEtaSearchButtonClicked(): void {
    this.getDolSearchByCaseID(this.model.caseNumber);
  }

  ngOnDestroy(){this.searchSubscription.unsubscribe();}
  getDolSearchByCaseID(caseNumber: string) {
    this.showSummary = false
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEmployers = false
    this.loading = true
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByCaseId(this.model.caseNumber.replace(/-/g, '')).subscribe(data => {
      console.log(data)
       this.dol = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData);
      // console.log(this.dol)
      //this.dolEta = this.dol.DOL_DATA
      
      this.dolEta = <DOLDATA>this.dol.DOL_DATA
      console.log(this.dolEta)
      console.log("Is it an array: " + Array.isArray(this.dolEta.DOL_ETA_WORKSITES))
      if (Array.isArray(this.dolEta.DOL_ETA_WORKSITES)) {
        
        this.showWorkSites = true
      }
      
      if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
        this.showEmployers = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {
        this.model.DolEtaResults = []
        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          this.loading = false
          this.showDol = true
        } else {
            if(this.dolEta.DOL_ETA_CLOB.RESPONSECODE){
              this.loading = false
              this.showDol = false
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              
            }else {
              this.DolEtaResult = this.dolEta.DOL_ETA_CLOB;
              this.dolEta.DOL_ETA_CLOB = [];
              this.dolEta.DOL_ETA_CLOB.push(this.DolEtaResult)
              this.showDol = true
            }
            this.model.DolEtaResults.push(this.dolEta.DOL_ETA_CLOB)
          
        }
        
      }
      //For Loading Animation
    this.showAddendum = this.showEmployers||this.showWorkSites      
    this.loading=false
    
    },
      error => {
        (async () => {
          //await delay(10000);  //when simulating a long delay or timeout from a service.
          //console.log('after delay');
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC + ", " + JSON.stringify(error);
          this.showDol = false;
          this.loading = false;
          this.showAddendum = false
          this.showWorkSites = false
          this.showEmployers = false
          this.showSummary = false;
        })();
      }
    )



  }
  getDolSearchByPetitionID(petitionNumber: string) {
    this.showSummary = false;
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEmployers = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByPettitionId(petitionNumber).subscribe(data => {
      console.log(data)
       this.dol = <DolData2> JSON.parse((data.GetDolDetailByPetitionIDResponse.DolJsonData).toString());
       console.log(this.dol)
      //this.dolEta = this.dol.DOL_DATA
      
      this.dolEta = <DOLDATA2> this.dol.DOL_DATA
      console.log(this.dolEta.DOL_ETA_CLOB)
      console.log("Is it an array: " + Array.isArray(this.dolEta.DOL_ETA_WORKSITES))
      if (Array.isArray(this.dolEta.DOL_ETA_WORKSITES)) {
        
        this.showWorkSites = true
      }
      
      if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
        this.showEmployers = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {
        this.model.DolEtaResults = []
        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          this.loading = false
          this.showDol = true
        } else {
            if(this.dolEta.DOL_ETA_CLOB.RESPONSECODE){
              this.loading = false
              this.showDol = false
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              
            }else {
              this.DolEtaResult = this.dolEta.DOL_ETA_CLOB;
              this.dolEta.DOL_ETA_CLOB = [];
              this.dolEta.DOL_ETA_CLOB.push(this.DolEtaResult)
              this.loading = false;
              this.showDol = true
            }
            this.model.DolEtaResults.push(this.dolEta.DOL_ETA_CLOB)
          
        }
        
      }
      //For Loading Animation
    this.showAddendum = this.showEmployers||this.showWorkSites 
    this.showSummary = true     
      this.loading=false
    },
    error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        //console.log('after delay');
        this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC + ", " + JSON.stringify(error);
        this.showDol = false;
        this.loading = false;
        this.showAddendum = false
        this.showWorkSites = false
        this.showEmployers = false
        this.showSummary = false;
      })();
      }
    )

  }


}

