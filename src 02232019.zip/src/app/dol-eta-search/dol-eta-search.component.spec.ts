import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DolEtaSearchComponent } from './dol-eta-search.component';
import {ClarityModule} from '@clr/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TopMenuComponent } from '../top-menu/top-menu.component';
import { TopAlertsComponent } from '../top-alerts/top-alerts.component';
import { AppRoutingModule } from '../app-routing.module';
import { VsrComponent } from '../vsr/vsr.component';
import { VsrHistoryComponent } from '../vsr/vsr-history/vsr-history.component';
import { RedReportsComponent } from '../red-reports/red-reports.component';
import { ReportsComponent } from '../reports/reports.component';
import { AdminComponent } from '../admin/admin.component';
import { ManualSearchModalComponent } from '../manual-resubmit/manual-search-modal.component';
import { GoogleMapsComponent } from '../google-maps/google-maps.component';
import { ScoreCardComponent } from '../score-card/score-card.component';
import { ImqComponent } from '../imq/imq.component';
import { vsrCompareFormComponent } from '../vsr/vsr-compare-form/vsr-compare-form.component';
import { AgmCoreModule } from '@agm/core';
import {APP_BASE_HREF} from '@angular/common'
import { HttpClientTestingModule } from '@angular/common/http/testing';
describe('DolEtaSearchComponent', () => {
  let component: DolEtaSearchComponent;
  let fixture: ComponentFixture<DolEtaSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ClarityModule,
        ReactiveFormsModule, 
        FormsModule,
        AppRoutingModule,
        HttpClientTestingModule,
        AgmCoreModule.forRoot({
          apiKey: 'AIzaSyCJhyfiijJ1tv36ZmiKTLvumGisY0QRcdg'

      })
      ],
      declarations: [
        DolEtaSearchComponent,
        TopMenuComponent,
        TopAlertsComponent,
        VsrComponent,
        VsrHistoryComponent,
        RedReportsComponent,
        ReportsComponent,
        AdminComponent,
        ManualSearchModalComponent,
        GoogleMapsComponent,
         ScoreCardComponent,
        // VsrHistorySingleFormComponent,
        ImqComponent,
        vsrCompareFormComponent,

      ],
      providers: [{provide: APP_BASE_HREF, useValue: '/dol-eta-search'}],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolEtaSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create dol eta page', () => {
    expect(component).toBeTruthy();
  });
});
