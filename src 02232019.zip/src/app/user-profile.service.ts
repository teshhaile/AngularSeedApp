import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppSettings } from './shared/app-settings';
import { UserProfile } from './shared/user-profile';
import { UtilitiesService  } from './shared/utilities.service';
import { catchError, map, tap } from 'rxjs/operators';
import { throwError } from 'rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/Observable/throw';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {

  private profileUrl = AppSettings.USER_PROFILE_URL;
  private utilService; 

  constructor(private http: HttpClient, private utilitiesService: UtilitiesService) {
    this.utilService = utilitiesService; 
  }

  getUserProfile(){
    
    return this.http.get<UserProfile>(this.profileUrl).pipe(
      tap(_ => this.utilService.log(`get user profile`)), catchError(this.utilService.handleErrorObservable)
    );

  }

}
