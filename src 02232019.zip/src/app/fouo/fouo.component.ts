import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-fouo',
  templateUrl: './fouo.component.html',
  styleUrls: ['./fouo.component.css']
})
export class FouoComponent implements OnInit {

  constructor() { }
  showFormModal: boolean = false;
  formAccessibility;
  currentDateTime: Date ;

  ngOnInit() {
    this.formAccessibility = new FormGroup({});    
    this.currentDateTime = new Date();
  }

  toggleFormAccessibility(){
    
    this.showFormModal = !this.showFormModal;
    console.log("this.showFormModal: " + this.showFormModal);
  }
}
