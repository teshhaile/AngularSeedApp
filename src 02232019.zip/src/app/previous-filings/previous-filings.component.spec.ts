import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousFilingsComponent } from './previous-filings.component';

describe('PreviousFilingsComponent', () => {
  let component: PreviousFilingsComponent;
  let fixture: ComponentFixture<PreviousFilingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviousFilingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviousFilingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
