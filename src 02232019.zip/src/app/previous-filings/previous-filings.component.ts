import { Component, OnInit , Input } from '@angular/core';
import {AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';
import {Previousfiling} from '../shared/previous_filings_interfaces'
import {pfDunsResponse} from '../shared/dunsResponse_interfaces'
import { PreviousFilingsService } from '../previous-filings.service';
import { SmartSearchModel }  from "../shared/smart-search-model";
import { SmartSearchBoxComponent } from '../smart-search-box/smart-search-box.component';
import { SmartSearchService } from '../smart-search.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-previous-filings',
  templateUrl: './previous-filings.component.html',
  styleUrls: ['./previous-filings.component.css']
})
export class PreviousFilingsComponent implements OnInit {
  @Input() orgShowSmartMenu: boolean = true;
  @Input() dunsNum: string = "";
  @Input() organizationName:string = "";
  @Input() petitionType: string = "";
  @Input() dolCaseNum: string = "";
  previousFiling: Previousfiling;
  pfDuns: pfDunsResponse;
  pfDunsTemp: pfDunsResponse;
  searchSubscription: Subscription;
  showEta = false;
  showDuns = false;
  showReport = false;
  count = 0;
  showCount = false;
  loading = false;
  loadingeta = false;
  typeTitle = "Petition Type:"
  show129 = false;
  show140 = false;
  masterSelected = true;
  ajudicativeStatus = "";
  timePeriod = "12";
  visaTypes = [];
  resultset = [];
  checkboxes = [
    {
      "name": "1B1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "1B2",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "1B3",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "HSC",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "L1A",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "L1B",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "R1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "TN1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "TN2",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E2",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E3",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "H2A",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "H2B",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },    
    {
      "name": "H3",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "LZ",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "Q1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "CW1",
      "checked": true,
      "visible": true,
      "type": "I-129"
    },
    {
      "name": "E12",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E13",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E21",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E31",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "E32",
      "checked": true,
      "visible": true,
      "type": "I-140"
    },
    {
      "name": "EW3",
      "checked": true,
      "visible": true,
      "type": "I-140"
    }
  ]
  
 
  private pfSvc: PreviousFilingsService;
  constructor(
    private router: Router, 
    private pfSearchSearvice: PreviousFilingsService, 
    private ssb: SmartSearchService) { 
    this.pfSvc = pfSearchSearvice;
    //integration point with SSB
    this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      console.log("search box: " + JSON.stringify(message));
      
      //Check if Duns
      if ((message.selectedSearchType=="previousFilings") && 
          (message.selectedSearchFunction=="pfDuns") && 
          (message.searchById!="") && 
          (message.searchById!=undefined)){
            this.dunsNum = message.searchById
            console.log("this.dunsNum="+this.dunsNum); 
            this.onDuns(this.dunsNum);
            message.searchById="";

      }

        //Check if Dolcase
        if ((message.selectedSearchType=="prevEtaFilings") && 
        (message.selectedSearchFunction=="pfEta") && 
        (message.searchById!="") && 
        (message.searchById!=undefined)){
          this.dolCaseNum = message.searchById
          console.log("this.dolCaseNum ="+this.dolCaseNum); 
          this.getPfByDolcase(this.dolCaseNum);
          message.searchById="";

        }
      


    }
    );

  }

  message: SmartSearchModel; 
  ngOnInit() {


    
    //DolCase
    if (this.router.url.includes('previous-filings/dolcase') || ( this.dolCaseNum && this.dolCaseNum !== "")) {
      this.loadingeta = true;
      console.log("inside prev filings the this.router.url is: " + this.router.url);
      console.log("Inside prev filings the dolcasenum is: " + this.dolCaseNum );
      var urlarr = this.router.url.split("/");
      if (this.dolCaseNum === ""){
      this.dolCaseNum = urlarr[urlarr.length - 1];
      }
      this.pfSvc.getPreviousFilingsByDolcase(this.dolCaseNum.toUpperCase().replace(/-/g, '')).subscribe(
        data => {
          if (data) {
            this.previousFiling = JSON.parse(JSON.stringify(data).replace("PreviousFilings-GetByDolCaseNumberResponse", "PreviousFilingsGetByDolCaseNumberResponse"));
            console.log(this.previousFiling);
            this.showEta = true;
          }
          this.loadingeta = false;
        }
        
      );
      
    } //Duns /previous-filings/duns/I-129/
    if (this.router.url.includes('previous-filings/duns') || (this.dunsNum !== "" && this.petitionType !== "")) {
      var urlarr = this.router.url.split("/");
      if (this.router.url.includes('previous-filings/duns')) {
        this.organizationName = decodeURI(urlarr[urlarr.length - 1]);
        this.dunsNum = urlarr[urlarr.length - 2];
        this.petitionType = urlarr[urlarr.length - 3];
      }
      if (this.petitionType == "I-129") {
        this.checkUncheck(this.petitionType);
        this.show129 = true;
      }else if (this.petitionType == "I-140"){
        this.checkUncheck(this.petitionType);
        this.show140 = true;
      }else if (this.petitionType == "I-485J"){
        this.typeTitle = "Form Type:"
        this.checkUncheck("");
      }
      else {this.checkUncheck("")};
      this.showDuns = true;
    }

  }

  ngOnDestroy(){this.searchSubscription.unsubscribe()}

  async delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
}
  buildReport(){
    this.showEta = false;
    this.count = 0;
    this.loading = true;
    this.showReport = false;
    this.resultset = [];
    this.getCheckedVisas();
    console.log(this.visaTypes);
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(),this.organizationName,this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data)
           {
             this.pfDuns = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response","PreviousFilingsGetByDunsNumberResponse"));
           this.count = this.pfDuns.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
           this.resultset = this.resultset.concat(this.pfDuns.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
           this.showReport = true;
          
          }        
         }
    );
    
    this.showCount = true;
    // this.delay(5000);
     this.loading = false;
  }
  getPfByDolcase(dolCaseNum: string){
    this.showEta = false;
    this.showDuns =false;
    this.loadingeta = true;
      console.log("inside prev filings the this.router.url is: " + this.router.url);
      console.log("Inside prev filings the dolcasenum is: " + dolCaseNum );
      var urlarr = this.router.url.split("/");
      this.dolCaseNum = dolCaseNum;
    
      this.pfSvc.getPreviousFilingsByDolcase(this.dolCaseNum.toUpperCase().replace(/-/g, '')).subscribe(
        data => {
          if (data) {
            this.previousFiling = JSON.parse(JSON.stringify(data).replace("PreviousFilings-GetByDolCaseNumberResponse", "PreviousFilingsGetByDolCaseNumberResponse"));
            console.log(this.previousFiling);
            this.showEta = true;
          }
          this.loadingeta = false;
        }
        
      );
      
  }
  checkUncheck(petitionType){
    for (let box of this.checkboxes){
      if(box.type == petitionType){
        box.checked = true;
        box.visible = true;
      }else {
        box.checked = false;
        box.visible =false;
      }
    }
  }
  checkUncheckAll(){
    for (let box of this.checkboxes){
      if (this.masterSelected && box.visible){
        box.checked = true;
      }else box.checked = false;
    }
  }
  getCheckedVisas(){
    this.visaTypes = []
    for (let box of this.checkboxes){
      if (box.checked && box.visible)
      {this.visaTypes.push(box.name)}
    }
  }
  setAjudicativeStatus(){
    
  }
  onDuns(duns: string) {

    this.resultset = [];
    this.showDuns = true;
    this.show129 = true;
    this.petitionType = "I-129"
    this.ajudicativeStatus = ""
    this.count = 0;
    this.dunsNum = duns;
    this.timePeriod = "12";
    //make I-129 Call
    this.showReport = false;
    this.loading = true;
    this.checkUncheck(this.petitionType)
    this.getCheckedVisas();
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;  
        }
        }
      }
    );
    //make I-140 Call
    this.petitionType = "I-140"
    this.checkUncheck(this.petitionType);
    this.getCheckedVisas();
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;
          this.loading = false;  
        }
        }
      }
    );
    //make I-140 Call

    this.petitionType = "I-485J"
    this.checkUncheck("");
    this.getCheckedVisas();
    this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;
          this.loading = false;  
        }
        }
      }
    
    );
    this.petitionType = "I-360"
    this.checkUncheck("");
    this.getCheckedVisas();
    var res = this.pfSvc.getPreviousFilingsByDuns(this.dunsNum.toUpperCase(), this.organizationName, this.petitionType, this.timePeriod, this.ajudicativeStatus.split(","), this.visaTypes).subscribe(
      data => {
        if (data) {
          this.pfDunsTemp = JSON.parse(JSON.stringify(data).replace("PreviousFilingsGetByDunsNumber-Response", "PreviousFilingsGetByDunsNumberResponse"));
          if (this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
          this.resultset = this.resultset.concat(this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord)
          console.log(this.resultset)
          this.count = this.count + this.pfDunsTemp.PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.totalRecordCount
          this.showReport =true;
          this.loading = false;
          }
        }
      }
    );
    if (this.loading){
      this.loading = false;
    }
    this.showCount = true;
    this.petitionType = "I-129"
    this.show129 = true;
    this.checkUncheck("I-129");
  }
}

