import { Component, EventEmitter, Output, OnInit, Input,  } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppSettings } from '../shared/app-settings';
import { HttpClient } from '@angular/common/http';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';
import { SmartSearchModel } from '../shared/smart-search-model';
import { SmartSearchService } from '../smart-search.service';

@Component({
  selector: 'app-address-input-form',
  templateUrl: './address-input-form.component.html',
  styleUrls: ['./address-input-form.component.css']
})
export class AddressInputFormComponent implements OnInit {

  //@Output() address: EventEmitter<VSRResubmitAddress> = new EventEmitter<VSRResubmitAddress>();
  @Output() pfAddress : EventEmitter<VSRResubmitAddress> = new EventEmitter<VSRResubmitAddress>();
  

  addressInputForm: FormGroup; 
  model: SmartSearchModel = new SmartSearchModel;
  opened = true;

  constructor(private httpService: HttpClient, private fb: FormBuilder,  private data: SmartSearchService) {
    this.populateCountries();
    this.populateStates();

  }


  newMessage(){
    console.log("sending new message, from address search:");
    console.log(this.model);
    this.data.changeMessage(this.model);
  }

  ngOnInit() {
    
  addressInputForm: FormGroup; 
  this.addressInputForm = this.fb.group({
      org: ["", Validators.required],
      street: ["", Validators.required],
      city: [""],
      state: ["", Validators.required],
      zip: [""],
      country: ["", Validators.required]
  });

  }

  selectedProvince: CountryStatesProvinces;
  statesOrProvinces: CountryStatesProvinces[];

  selectedCountry: CountryStatesProvinces;
  countries: CountryStatesProvinces[];

  private populateStates() {
    const url = AppSettings.US_STATES_JSON;
    this.httpService.get(url).subscribe(
      data => {
        this.statesOrProvinces = data as CountryStatesProvinces[];
      }
    );
  }

  private populateProvinces() {
    const url = AppSettings.PROVINCES_JSON;
    this.httpService.get(url).subscribe(
      data => {
        if (data)
          this.statesOrProvinces = data as CountryStatesProvinces[];
        else
          this.statesOrProvinces = [];
      }
    );
  }

  private populateCountries() {
    const url = AppSettings.COUNTRIES_JSON;
    this.httpService.get(url).subscribe(
      data => {
        this.countries = data as CountryStatesProvinces[];

      }
    );
  }

  private cancel(){
    this.opened=false;
  }
  private imqAddressSearch(){
    console.log("imq Search by Address");
    console.log(this.addressInputForm); 
  
    var searchAddress: VSRResubmitAddress = new VSRResubmitAddress;
    
    searchAddress.organizationName=this.addressInputForm.value.org; 
    searchAddress.streetFull=this.addressInputForm.value.street; 
    searchAddress.city=this.addressInputForm.value.city; 
    searchAddress.state=this.addressInputForm.value.state;
    searchAddress.postalCode=this.addressInputForm.value.zip;
    searchAddress.country=this.addressInputForm.value.country.selectedCountry; 

    if (this.validAddress(searchAddress)){
      this.model.address = searchAddress;
      this.pfAddress.emit(searchAddress); 
      this.opened=false;
  
    }else {
      this.model.error="Address fields are required."
    }
    //this.newMessage();
     //   break;
  }
  private onSelect(countryId: string) {
    if (countryId.toUpperCase() == "CANADA")
      this.populateProvinces();
    else if (countryId.toUpperCase() == "UNITED STATES")
      this.populateStates();
    else
      this.statesOrProvinces = [];

  }

  
validAddress(searchAddress: VSRResubmitAddress): boolean {
  if ((searchAddress.organizationName.trim.length!=0) && 
      (searchAddress.streetFull.trim.length!=0) &&
        (searchAddress.state.trim.length!=0) &&
        (searchAddress.country.trim.length!=0)){
        return true; 
      }
  
  return false;
}

}

export class CountryStatesProvinces {
  name: string;
  abbreviation: string;
}

