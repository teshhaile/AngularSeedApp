import { Component, OnInit } from '@angular/core';
import { SmartSearchModel } from "../shared/smart-search-model";
import { SmartSearchBoxComponent } from '../smart-search-box/smart-search-box.component';
import { SmartSearchService } from '../smart-search.service';
import { IndependentManualQueryService } from '../independent-manual-query.service';
import { Router } from '@angular/router';
//import { AddressProxy } from '../shared/vsr-resubmit-proxy';
import { VSRResubmitAddress } from '../shared/vsr-resubmit';
import { IndependentManualQueryResponse1Proxy, AddressProxy } from '../shared/independent-manual-query-response-proxy';
import { PreviousFilingsService } from '../previous-filings.service';
import { Subscription } from 'rxjs';
import { pfDunsResponseProxy } from '../shared/dunsResponseProxies'
import { pfDunsResponse, PreviousFilingRecordEntity } from '../shared/dunsResponse_interfaces'
import { pfFeinResponse } from '../shared/feinResponse_interfaces';


@Component({
  selector: 'app-imq',
  templateUrl: './imq.component.html',
  styleUrls: ['./imq.component.css']
})
export class ImqComponent implements OnInit {

  showpage = false;
  displayManualSearch = false;
  reciptNumber = "EAC1807951580"
  message: SmartSearchModel;
  duns: string = "";
  fein: string = "";
  address: VSRResubmitAddress = new VSRResubmitAddress();
  imqResponse: IndependentManualQueryResponse1Proxy;
  searchSubscription: Subscription;
  loading: boolean = false;
  pfDunsResponse: pfDunsResponse[];
  pfFeinResponse: pfFeinResponse[];


  //selected on the UI
  selectedReceipt;
  resultset: PreviousFilingRecordEntity[] = [];

  constructor(
    private router: Router,
    private imqService: IndependentManualQueryService,
    private prevFilingsService: PreviousFilingsService,
    private ssb: SmartSearchService) {

    //integration point with SSB
    this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      console.log("search box: " + JSON.stringify(message));
      if ((message.selectedSearchType == "previousFilings") &&
        (message.selectedSearchFunction == "pfDuns") &&
        (message.searchById != "") &&
        (message.searchById != undefined)) {
        this.duns = message.searchById
        console.log("this.duns=" + this.duns);

        //call method
        this.searchByDUNS();
        message.searchById = "";

      } else if ((message.selectedSearchType == "previousFilings") &&
        (message.selectedSearchFunction == "pfFein") &&
        (message.searchById != "") &&
        (message.searchById != undefined)) {
        this.fein = message.searchById
        console.log("this.fein=" + this.fein);

        //call method
        this.searchByFFIN();
        message.searchById = "";


      } else if ((message.selectedSearchType == "previousFilings") &&
        (message.selectedSearchFunction == "pfBA")) {
        console.log(this.address);
        console.log(message.address);
        this.address = message.address;
        this.searchByAddress()
      }
    });
  }

  ngOnInit() {

  }

  displayManualSearchButton: boolean = false;
  displayVsr: boolean = true;
  ReceiptNumber: string = "";

  // displayVSR()
  // {
  //   this.displayVsr = !this.displayVsr;
  // }



  ngOnDestroy() { this.searchSubscription.unsubscribe(); }

  searchByDUNS() {
    console.log("search by DUNS");
    this.fein = "";
    this.resultset = [];
    this.showpage = true;

    this.loading = true;
    this.imqService.getImqByDuns(this.duns).subscribe(data => {
      this.imqResponse = data.IndependentManualQueryResponse;
      this.loading = false;
    });
    this.prevFilingsService.getAllByDuns(this.duns)
      .then(data => {
        if (data) {
          this.pfDunsResponse = JSON.parse(JSON.stringify(data));
          console.log(this.pfDunsResponse);


          if (this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
            for (let i of this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }
          /*
          if (this.pfDunsResponse[1].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
            for (let i of this.pfDunsResponse[1].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }

          if (this.pfDunsResponse[2].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
            for (let i of this.pfDunsResponse[2].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }
          if (this.pfDunsResponse[3].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
            for (let i of this.pfDunsResponse[3].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }
        */
        }
      })
      .catch();

  }

  searchByFFIN() {
    console.log("search by FEIN");
    this.duns = "";
    this.loading = true;
    this.showpage = true;
    this.resultset = [];

    this.imqService.getImqByFein(this.fein).subscribe(data => {
      this.imqResponse = data.IndependentManualQueryResponse;
      this.loading = false;
    });

    this.prevFilingsService.getAllByFein(this.fein)
      .then(data => {
        if (data) {
          this.pfFeinResponse = JSON.parse(JSON.stringify(data));
          console.log(this.pfFeinResponse);


          if (this.pfFeinResponse[0].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
            for (let i of this.pfFeinResponse[0].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }

          if (this.pfFeinResponse[1].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
            for (let i of this.pfFeinResponse[1].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }

          if (this.pfFeinResponse[2].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
            for (let i of this.pfFeinResponse[2].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }
          if (this.pfFeinResponse[3].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
            for (let i of this.pfFeinResponse[3].PreviousFilingsGetByFeinNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              console.log(i);
              console.log(this.resultset);
              this.resultset.push(i);
            }
          }

        }
      })
      .catch();

  }

  searchByAddress() {
    console.log("in searchByAddress");
    this.fein = "";
    this.duns = "";
    this.resultset = [];
    this.showpage = true;
    this.loading = true;

    this.imqService.getImqByAddress(this.address).subscribe(data => {
      this.imqResponse = data.IndependentManualQueryResponse;
      this.loading = false;

      if (this.imqResponse.DunsNumber==undefined){
        this.message.error="No record matches for this company name/address.";
      }else if (this.imqResponse.DunsNumber!=undefined){

        this.prevFilingsService.getAllByDuns(this.imqResponse.DunsNumber)
        .then(data => {
          if (data) {
            this.pfDunsResponse = JSON.parse(JSON.stringify(data));
            console.log(this.pfDunsResponse);
  
  
            if (this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
              for (let i of this.pfDunsResponse[0].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord) {
                console.log(i);
                console.log(this.resultset);
                this.resultset.push(i);
              }
            }
            /*
            if (this.pfDunsResponse[1].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
              for (let i of this.pfDunsResponse[1].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
                console.log(i);
                console.log(this.resultset);
                this.resultset.push(i);
              }
            }
  
            if (this.pfDunsResponse[2].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
              for (let i of this.pfDunsResponse[2].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
                console.log(i);
                console.log(this.resultset);
                this.resultset.push(i);
              }
            }
            if (this.pfDunsResponse[3].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
              for (let i of this.pfDunsResponse[3].PreviousFilingsGetByDunsNumberResponse.PreviousFilingsResultSet.PreviousFilingRecord){
                console.log(i);
                console.log(this.resultset);
                this.resultset.push(i);
              }
            }
          */
          }
        })
        .catch();
   
      }
      console.log(this.imqResponse.DunsNumber);

   });
   
  }

  getAddress(address: AddressProxy): String {
    let addressStr: string = "";

    if (address != undefined) {
      if (address.StreetFullText.trim.length) {
        addressStr = address.StreetFullText.trim();
      }

      if (address.LocationCityName.trim.length) {
        addressStr = address + ", " + address.LocationCityName.trim();
      }

      if (address.LocationStateName.trim.length) {
        addressStr = address + ", " + address.LocationStateName.trim();
      }

      if (address.LocationPostalCode.trim.length) {
        addressStr = address + ", " + address.LocationPostalCode.trim();
      }

      if (address.LocationCountryName.trim.length) {
        addressStr = address + ", " + address.LocationCountryName.trim();
      }
    }
    return addressStr;

  }
}
