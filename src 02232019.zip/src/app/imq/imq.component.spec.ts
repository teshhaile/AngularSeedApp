import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImqComponent } from './imq.component';

describe('ImqComponent', () => {
  let component: ImqComponent;
  let fixture: ComponentFixture<ImqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
