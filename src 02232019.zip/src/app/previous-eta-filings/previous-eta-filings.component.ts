import { Component, OnInit } from '@angular/core';
import { keyframes } from '@angular/animations';
import { DolEtaSearchService } from '../dol-eta-search.service';
import { ClrDatagridComparatorInterface, ClrDatagridSortOrder, DatagridPropertyComparator } from '@clr/angular';
import { DolData, Dol, DOLDATA, DOLETAWORKSITESEntity, DOLETAEMPLOYERSEntity } from '../shared/dol_interfaces'
import {AppSettings } from '../shared/app-settings'
import { Router } from '@angular/router';

@Component({
  selector: 'app-previous-eta-filings',
  templateUrl: './previous-eta-filings.component.html',
  styleUrls: ['./previous-eta-filings.component.css']
})
export class PreviousEtaFilingsComponent implements OnInit {

  private dolEtaUrl = '/vibe-plus/rest/dol/petition-id/';
  showDol = false
  loading = false
  showEmployers = false
  showWorkSites = false
  showAddendum = false
  dol: DolData
  dolEta: DOLDATA
  descSort = ClrDatagridSortOrder.DESC
  ascSort = ClrDatagridSortOrder.ASC
  appsAlert: string
  model = {
    DolEtaResults: [],
    caseNumber: 'H30014321198839',
    petitionNumber: '146845314'
  }
  private dolSvc: DolEtaSearchService;
  constructor(private dolSearchService: DolEtaSearchService,private router: Router) {
    this.dolSvc = dolSearchService
    
  }

  ngOnInit() 
  {
    if (this.router.url.includes('petition')){
      var urlarr = this.router.url.split("/");
      this.model.caseNumber = urlarr[urlarr.length-1];
      this.getDolEtaSearchButtonClicked();
    }

  }
  getDolEtaSearchButtonClicked(): void {
    this.loading = true
    this.showDol = false
    this.showAddendum = false
    this.showWorkSites = false
    this.showEmployers = false
    this.appsAlert = ""
    //Start service Call
    this.dolSvc.getDolByCaseId(this.model.caseNumber.replace(/-/g, '')).subscribe(data => {
      console.log("In Service")
       this.dol = JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData);
      this.dolEta = this.dol.DOL_DATA
      console.log(this.dolEta)
      console.log("Is it an array: " + Array.isArray(this.dolEta.DOL_ETA_WORKSITES))
      if (Array.isArray(this.dolEta.DOL_ETA_WORKSITES)) {
        
        this.showWorkSites = true
      }
      //console.log(this.dolEta.DOL_ETA_EMPLOYERS)
      if (Array.isArray(this.dolEta.DOL_ETA_EMPLOYERS)) {
        this.showEmployers = true
      }
      if (this.dolEta.DOL_ETA_CLOB) {
        this.model.DolEtaResults = []
        if (Array.isArray(this.dolEta.DOL_ETA_CLOB)) {
          this.loading = false
          this.showDol = true
        } else {
            if(this.dolEta.DOL_ETA_CLOB.RESPONSECODE){
              this.loading = false
              this.showDol = false
              this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
              
            }else {
              this.showDol = true
            }
            this.model.DolEtaResults.push(this.dolEta.DOL_ETA_CLOB)
          
        }
        
      }
      //For Loading Animation
    this.showAddendum = this.showEmployers||this.showWorkSites      
      this.loading=false
    },
      error => {
        (async () => {
          //await delay(10000);  //when simulating a long delay or timeout from a service.
          //console.log('after delay');
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC + ", " + JSON.stringify(error);
          this.showDol = false;
          this.loading = false;
        })();
      }
    )



  }

  getDolSearchByCaseID(caseNumber: string) {
    this.dolSvc.getDolByCaseId(caseNumber.replace("-", "")).subscribe(data => {
      return data
    })

  }
  getDolSearchByPetitionID(petitionNumber: string) {
    this.dolSvc.getDolByPettitionId(petitionNumber).subscribe(data => {
      return data
    })

  }

}

