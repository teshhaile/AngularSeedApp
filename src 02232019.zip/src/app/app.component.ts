import { Component, OnInit  } from '@angular/core';
import { UserProfileService } from './user-profile.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, Event, NavigationStart } from '@angular/router';
import { UserInRoleService } from './user-profile/user-in-role.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], 
  providers: [UserProfileService]
})
export class AppComponent {
  display : boolean =true; 
  title = 'VIBE PLUS';
  notification: string;
  showNotification: boolean;
  displayName = ""; 
  showFormModal: boolean = false;
  formAccessibility;
  currentDateTime: Date ;

  private myUserProfileService : UserProfileService; 

  constructor(private userProfileService: UserProfileService, private router: Router, private userInRoleService: UserInRoleService) {
    this.myUserProfileService = userProfileService;
    this.myUserProfileService.getUserProfile().subscribe(
      data => {
        if (data) {
          this.displayName = data.displayName;
          this.userInRoleService.userInRole = data;

          console.log("ac:  data="+JSON.stringify(data)); 
          
        }
        else {
          console.log("ac: No user profile data");           
        }
      },
      error => {
        (async () => {
          console.log("ac: User Not logged in"); 
          window.location.href="/vibe-plus";

          //this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC + ", " + JSON.stringify(error);
        })();
      }
    );

    //This controls where the SSB is displayed 
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        console.log("event.url="+event.url)
        if (event.url.match('/') ||
            event.url.startsWith('/vsr') || 
            event.url.startsWith('/previous-filings') || 
            event.url.startsWith('/previous-eta-filings') || 
            event.url.startsWith('/dol-eta-lookup')) {
          console.log("show search box"); 
          this.display=true;
        }else {
          this.display=false;
          console.log("hide search box"); 
        }
      } 
    });


   }
  
  ngOnInit() {
    this.formAccessibility = new FormGroup({});    
    this.currentDateTime = new Date();
  }

  toggleFormAccessibility(){
    
    this.showFormModal = !this.showFormModal;
    console.log("this.showFormModal: " + this.showFormModal);
  }
}
