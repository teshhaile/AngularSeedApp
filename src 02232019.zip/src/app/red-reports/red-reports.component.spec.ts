import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RedReportsComponent } from './red-reports.component';

describe('RedReportsComponent', () => {
  let component: RedReportsComponent;
  let fixture: ComponentFixture<RedReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RedReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RedReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
