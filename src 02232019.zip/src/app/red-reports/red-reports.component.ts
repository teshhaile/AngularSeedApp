import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AppSettings } from '../shared/app-settings';

@Component({
  selector: 'app-red-reports',
  templateUrl: './red-reports.component.html',
  styleUrls: ['./red-reports.component.css']
})
export class RedReportsComponent implements OnInit {

  constructor(private titleService: Title) {
  }

 
 
  public setTitle( newTitle: string) {
    this.titleService.setTitle( newTitle );
  }

  ngOnInit() {
    this.titleService.setTitle( AppSettings.RED_REPORT_TITLE );
  }

}
