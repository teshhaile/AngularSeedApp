import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DolEtaSearchService } from './dol-eta-search.service';

describe('DolEtaSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    
    declarations: [],
    imports: [HttpClientTestingModule],
    providers: [DolEtaSearchService]
  }));

  it('should be created', () => {
    const service: DolEtaSearchService = TestBed.get(DolEtaSearchService);
    expect(service).toBeTruthy();
  });
});
