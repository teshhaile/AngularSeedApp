export interface VsrResubmit {
    VsrResubmitResponse: VsrResubmitResponse;
  }
export class VsrResubmitResponse {
    SourceSystemID: string;
    SourceTransactionID: string;
    ServiceRequestTimestamp: string;
    ServiceResponseTimestamp: string;
    AuditCorrelationID: string;
    ResponseStatusMessage: ResponseStatusMessage;
    VsrResultSet: VsrResultSet;
  }
  export interface ResponseStatusMessage {
    StatusCode: string;
    Status: string;
  }
  export interface VsrResultSet {
    lastRecordIndex: number;
    recordCountInThisResultSet: number;
    totalRecordCount: number;
    VsrRecord?: (VsrRecordEntity)[] | null;
  }
  export interface VsrRecordEntity {
    ScoreID: string;
    AdjudicativeStatus: string;
    ReceiptNumber: string;
    PetitionInformation: PetitionInformation;
    VIBEScoreResult: VIBEScoreResult;
    DNBMatchedBranchInformation?: DNBMatchedBranchInformation | null;
    DNBMatchedCompanyInformation: DNBMatchedCompanyInformation;
    DNBDetailedCompanyInformation: DNBDetailedCompanyInformation;
    DNBCompanyExecutiveBio: DNBCompanyExecutiveBio;
    DNBCompanyFinancialInformation: DNBCompanyFinancialInformation;
    DOLSummary: DOLSummary;
    ManualSearchInfo?: ManualSearchInfo | null;
  }
  export interface PetitionInformation {
    ReceiptNumber: string;
    PetitionVisaType: string;
    PetitionType: string;
    ReceiptDate: string;
    RecordTimeStamp: string;
    OrganizationDataSource: string;
    OrganizationName: string;
    Address: Address;
    DolEtaCaseNumber: string;
  }
  export interface Address {
    AddressID: string;
    StreetFullText: string;
    StreetExtensionText: string;
    LocationCityName: string;
    LocationPostalCode: string;
    LocationStateName: string;
    LocationCountryName: LocationCountryNameOrStreetExtensionText;
  }
  export interface LocationCountryNameOrStreetExtensionText {
    nil: boolean;
  }
  export interface VIBEScoreResult {
    Score: string;
    ScoreRunTimeStamp: string;
    Matched: string;
    ConfidenceFactor: string;
    I129CountInLast12Month?: number | null;
  }
  export interface DNBMatchedBranchInformation {
    AgnID: string;
    Address: Address1;
    OrganizationDUNSNumber: string;
  }
  export interface Address1 {
    AddressID: string;
    OrganizationName: string;
    TelephoneNumberFullID: string;
    StreetFullText: string;
    StreetExtensionText: LocationCountryNameOrStreetExtensionText;
    LocationCityName: string;
    LocationPostalCode: string;
    LocationStateName: string;
    LocationCountryName: string;
  }
  export interface DNBMatchedCompanyInformation {
    OrganizationName: string;
    Address: Address2;
    LocationType: string;
    OrganizationPhone: OrganizationPhone;
    OrganizationDUNSNumber: string;
    GlobalUltimateDUNSNumber: string;
    GlobalUltimateCompanyName: string;
    RelationshipToGlobal: string;
    ForeignRelationshipIndicator: string;
    OwnershipStatus: string;
    TaxExemptIndicator:string;
  }
  export interface Address2 {
    AddressID: string;
    StreetFullText: string;
    StreetExtensionText: LocationCountryNameOrStreetExtensionText;
    LocationCityName: string;
    LocationPostalCode: string;
    LocationStateName: string;
    LocationCountryName: string;
  }
  export interface OrganizationPhone {
    TelephoneNumberFullID: string;
  }
  export interface DNBDetailedCompanyInformation {
    CEOName: string;
    LegalStatusCode: string;
    ImportExport: string;
    NumberOfRelatedEntities: number;
    NumberOfCorroboratingSources: number;
    TotalTradePayments: number;
    NumberOfEmployeesInUSA: string;
    NumberOfEmployeesWorldWide: string;
    YearEstablished: number;
    ManagementControlYear: number;
    SevereRisk: string;
    HistoryType: string;
    OutOfBusinessIndicator: boolean;
    NAICCodes: NAICCodes;
    TradeStyleCodes?: null;
    NonProfitIndicator?: string | null;
  }
  export interface NAICCodes {
    NAIC1: string;
    NAIC2?: string | null;
    NAIC3?: null;
    NAIC4?: null;
    NAIC5?: null;
    NAIC6?: null;
  }
  export interface DNBCompanyExecutiveBio {
    Executive1: string;
    Executive2?: string | null;
    Executive3?: string | null;
  }
  export interface DNBCompanyFinancialInformation {
    GrossAnualIncome: string;
    FinancialStressScore: number;
  }

  export interface DOLSummary {
    PetitionID: string;
    EtaStatus: string;
    EtaCaseNumber: string;
    FilingDate: string;
    EtaVisaType: string;
    EmployerName: string;
    Fein: string;
    JobTitle: string;
    TotalWorkerPositions: string;
    ValidStartDate: string;
    ValidEndDate: string;
    PreviousEtaFilings: string;
}



  export interface ManualSearchInfo {
    OrganizationName: string;
    Address: Address2;
    RelatedToPetitioner: boolean;
  }


  
export class VSRResubmitRequest {
  sourceSystemID: string;
  sourceTransactionID: string;
  endUserID: string;
  receiptNumber: string;
  duns: string;
  address: VSRResubmitAddress;
}
export class VSRResubmitAddress {
  organizationName: string;
  streetFull: string;
  telephoneNumber: string;
  streetExtension: string;
  city: string;
  postalCode: string;
  state: string;
  country: string;
}