export class AppSettings {
    public static VSR_RESPNSE_JSON = './assets/receipt-search-response.json';
    public static RESUBMIT_RESPONSE_JSON = './assets/resubmitResponse.json';
    public static US_STATES_JSON = './assets/us-states.json';
    public static PROVINCES_JSON = './assets/provinces.json';
    public static COUNTRIES_JSON = './assets/countries.json';
    public static DOL_INFORMATION_JSON = './assets/DOL-Information.json';
    //public static DOL_DATA_JSON = './assets/H30017178227081-dol-data.json';
    public static DOL_DATA_JSON = './assets/H30014321198839.json';
    public static DOL_DISPLAY_RECEIPT_FROM_DATE = "2017-10-01";
    public static PREVIOUS_FILING_RESPONSE = './assets/previousfilingsResponseDuns.json'
    //Page Titles
    public static VSR_TITLE = 'VIBE PLUS - Status Report';
    public static RED_REPORT_TITLE = 'VIBE PLUS - Red Report';
    public static ETA_TITLE = 'VIBE PLUS - DOL ETA Case Detail';
    public static INDEPENDENT_MANUAL_TITLE = 'VIBE PLUS - Independent Manual Query';    
    public static TSVVP_REPORT_TITLE = 'VIBE PLUS - TSVVP Report';
    public static PREDEFINED_INFO_TITLE = 'VIBE PLUS - Predefined Information'; 
    public static DATA_INQUIRY_TITLE = 'VIBE PLUS - Data Inquiry ';
    public static REPORTS_TITLE = 'VIBE PLUS - Reports ';
    
    
    //Service URLS
    public static VSR_URL = '/vibe-plus/rest/vsr/receipt';
    public static SCORE_CARD_URL = '/vibe-plus/rest/score/scorecard';
    public static USER_PROFILE_URL = '/vibe-plus/rest/login/user';


    public static SOURCE_SYSTEM_ID = "vsr-resubmit";
    public static SOURCE_TRANSACTION_ID = "resubmit-12345678";
    public static END_USER_ID = "vsr user";


    //VIBE Status codes
    public static VSR_STATUS_CODE_001 = "ESB-VIBE.STATUS.001";
    public static VSR_STATUS_CODE_002 = "ESB-VIBE.STATUS.002";
    public static VSR_STATUS_CODE_003 = "ESB-VIBE.STATUS.003";
    public static VSR_STATUS_CODE_004 = "ESB-VIBE.STATUS.004";
    public static VSR_EXCEPTION_CODE_0108 = "ESB-VIBE-VIBE-0108";
    public static VSR_STATUS_CODE_001_DESC = "No search results could be found for this query.";
    public static VSR_STATUS_CODE_002_DESC = "Operation Successful";
    public static VSR_STATUS_CODE_003_DESC = "Operation Not Successful.";
    public static VSR_STATUS_CODE_004_DESC = "VIBE returned a blank VSR for receipt's petition address.";

    //ERROR Codes
    public static HTTP_STATUS_400 = "400 - Bad Request.";
    public static HTTP_STATUS_404 = "404 - Not found.";
    public static HTTP_STATUS_500 = "500 - Internal Server Error.";
    public static HTTP_STATUS_503 = "503 - Service unavailable.";
    public static HTTP_STATUS_502 = "502 - Proxy Error.";
    public static HTTP_STATUS_599 = "599 - Network connect timeout error.";
    public static HTTP_STATUS_408 = "408 - Request timedout.";
    public static HTTP_STATUS_UNKNOWN = "UNKNOWN ERROR";
    public static VSR_EXCEPTION_CODE_0108_DESC = "Receipt number not found.";
    public static SYSTEM_EXCEPTION = "A system exception was encountered while executing your request. Please contact your system administrator.";
    public static GOOGLEMAPS_NO_STREETVIEW = "Google street view is not available for this address,  a satellite view is provided for accessibility."
    public static GOOGLEMAPS_NO_MAP = "Google street view and satellite view are not available for this address."
    public static PO_BOX_STREET_VIEW_NOT_AVAILABLE = 'Google street view is not available for P.O. Box addresses.  Please conduct a manual search using the petitioner’s physical address for Google street view.';
   
    public static MAX_RECORDS_TO_COMPARE_WARNING = 'A maximum of two records may be selected and viewed at the same time.'
    public static MAX_RECORDS_TO_COMPARE_PROMPT = 'Select one record to view that VSR. Select up to two records for a side by side comparison.';
    //SETTINGS
    public static PAGINATION_COUNT = "20";
    public static API_KEY = "AIzaSyCJhyfiijJ1tv36ZmiKTLvumGisY0QRcdg";
}