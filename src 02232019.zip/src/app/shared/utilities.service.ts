import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppSettings } from './app-settings';
import { throwError } from 'rxjs';

import { of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UtilitiesService {

  constructor() { }

  

  public log(message: string) {
    console.log(`${message}`);

  }

    
  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
public handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  
  public handleErrorObservable(error: Response | any) {
    console.error("the error thrown is: " + (error.message));
    let statusMessage: string = "";
    // return Observable.throw(error.message || error);
    //return Observable.throw(new Error(error.status));
    let status: string = JSON.stringify(error.status);
    switch (status) {
      case '400':
        statusMessage = AppSettings.HTTP_STATUS_400;
        break;
      case '404':
        statusMessage = AppSettings.HTTP_STATUS_404;
        break;
      case '500':
        statusMessage = AppSettings.HTTP_STATUS_500;
        break;
      case '503':
        statusMessage = AppSettings.HTTP_STATUS_503;
        break;
      case '502':
        statusMessage = AppSettings.HTTP_STATUS_502;
        break;
      case '599':
        statusMessage = AppSettings.HTTP_STATUS_599;
        break;
      case '408':
        statusMessage = AppSettings.HTTP_STATUS_408;
        break;
      default:
        statusMessage = AppSettings.HTTP_STATUS_UNKNOWN;
  }
    return throwError(statusMessage);
  }
}
