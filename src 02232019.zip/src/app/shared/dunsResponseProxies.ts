// Stores the currently-being-typechecked object for error messages.
let obj: any = null;
export class pfDunsResponseProxy {
  public readonly PreviousFilingsGetByDunsNumberResponse: PreviousFilingsGetByDunsNumberResponseProxy;
  public static Parse(d: string): pfDunsResponseProxy {
    return pfDunsResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): pfDunsResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    d.PreviousFilingsGetByDunsNumberResponse = PreviousFilingsGetByDunsNumberResponseProxy.Create(d.PreviousFilingsGetByDunsNumberResponse, field + ".PreviousFilingsGetByDunsNumberResponse");
    return new pfDunsResponseProxy(d);
  }
  private constructor(d: any) {
    this.PreviousFilingsGetByDunsNumberResponse = d.PreviousFilingsGetByDunsNumberResponse;
  }
}

export class PreviousFilingsGetByDunsNumberResponseProxy {
  public readonly SourceSystemID: string;
  public readonly SourceTransactionID: string;
  public readonly ServiceRequestTimestamp: string;
  public readonly ServiceResponseTimestamp: string;
  public readonly AuditCorrelationID: string;
  public readonly PreviousFilingsResultSet: PreviousFilingsResultSetProxy;
  public static Parse(d: string): PreviousFilingsGetByDunsNumberResponseProxy {
    return PreviousFilingsGetByDunsNumberResponseProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PreviousFilingsGetByDunsNumberResponseProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkString(d.SourceSystemID, false, field + ".SourceSystemID");
    checkString(d.SourceTransactionID, false, field + ".SourceTransactionID");
    checkString(d.ServiceRequestTimestamp, false, field + ".ServiceRequestTimestamp");
    checkString(d.ServiceResponseTimestamp, false, field + ".ServiceResponseTimestamp");
    checkString(d.AuditCorrelationID, false, field + ".AuditCorrelationID");
    d.PreviousFilingsResultSet = PreviousFilingsResultSetProxy.Create(d.PreviousFilingsResultSet, field + ".PreviousFilingsResultSet");
    return new PreviousFilingsGetByDunsNumberResponseProxy(d);
  }
  private constructor(d: any) {
    this.SourceSystemID = d.SourceSystemID;
    this.SourceTransactionID = d.SourceTransactionID;
    this.ServiceRequestTimestamp = d.ServiceRequestTimestamp;
    this.ServiceResponseTimestamp = d.ServiceResponseTimestamp;
    this.AuditCorrelationID = d.AuditCorrelationID;
    this.PreviousFilingsResultSet = d.PreviousFilingsResultSet;
  }
}

export class PreviousFilingsResultSetProxy {
  public readonly totalRecordCount: number;
  public readonly lastRecordIndex: number;
  public readonly recordCountInThisResultSet: number;
  public readonly PreviousFilingRecord: PreviousFilingRecordEntityProxy[] | null;
  public static Parse(d: string): PreviousFilingsResultSetProxy {
    return PreviousFilingsResultSetProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PreviousFilingsResultSetProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkNumber(d.totalRecordCount, false, field + ".totalRecordCount");
    checkNumber(d.lastRecordIndex, false, field + ".lastRecordIndex");
    checkNumber(d.recordCountInThisResultSet, false, field + ".recordCountInThisResultSet");
    checkArray(d.PreviousFilingRecord, field + ".PreviousFilingRecord");
    if (d.PreviousFilingRecord) {
      for (let i = 0; i < d.PreviousFilingRecord.length; i++) {
        d.PreviousFilingRecord[i] = PreviousFilingRecordEntityProxy.Create(d.PreviousFilingRecord[i], field + ".PreviousFilingRecord" + "[" + i + "]");
      }
    }
    if (d.PreviousFilingRecord === undefined) {
      d.PreviousFilingRecord = null;
    }
    return new PreviousFilingsResultSetProxy(d);
  }
  private constructor(d: any) {
    this.totalRecordCount = d.totalRecordCount;
    this.lastRecordIndex = d.lastRecordIndex;
    this.recordCountInThisResultSet = d.recordCountInThisResultSet;
    this.PreviousFilingRecord = d.PreviousFilingRecord;
  }
}

export class PreviousFilingRecordEntityProxy {
  public readonly PetitionID: number;
  public readonly ReceiptNumber: string;
  public readonly AdjudicativeStatus: string;
  public readonly DateAdded: string;
  public readonly ReceiptDate: string;
  public readonly VisaType: string;
  public readonly ConfidenceFactor: string;
  public readonly OrganizationName: null;
  public static Parse(d: string): PreviousFilingRecordEntityProxy {
    return PreviousFilingRecordEntityProxy.Create(JSON.parse(d));
  }
  public static Create(d: any, field: string = 'root'): PreviousFilingRecordEntityProxy {
    if (!field) {
      obj = d;
      field = "root";
    }
    if (d === null || d === undefined) {
      throwNull2NonNull(field, d);
    } else if (typeof(d) !== 'object') {
      throwNotObject(field, d, false);
    } else if (Array.isArray(d)) {
      throwIsArray(field, d, false);
    }
    checkNumber(d.PetitionID, false, field + ".PetitionID");
    checkString(d.ReceiptNumber, false, field + ".ReceiptNumber");
    checkString(d.AdjudicativeStatus, false, field + ".AdjudicativeStatus");
    checkString(d.DateAdded, false, field + ".DateAdded");
    checkString(d.ReceiptDate, false, field + ".ReceiptDate");
    checkString(d.VisaType, false, field + ".VisaType");
    checkString(d.ConfidenceFactor, false, field + ".ConfidenceFactor");
    checkNull(d.OrganizationName, field + ".OrganizationName");
    if (d.OrganizationName === undefined) {
      d.OrganizationName = null;
    }
    return new PreviousFilingRecordEntityProxy(d);
  }
  private constructor(d: any) {
    this.PetitionID = d.PetitionID;
    this.ReceiptNumber = d.ReceiptNumber;
    this.AdjudicativeStatus = d.AdjudicativeStatus;
    this.DateAdded = d.DateAdded;
    this.ReceiptDate = d.ReceiptDate;
    this.VisaType = d.VisaType;
    this.ConfidenceFactor = d.ConfidenceFactor;
    this.OrganizationName = d.OrganizationName;
  }
}

function throwNull2NonNull(field: string, d: any): never {
  return errorHelper(field, d, "non-nullable object", false);
}
function throwNotObject(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function throwIsArray(field: string, d: any, nullable: boolean): never {
  return errorHelper(field, d, "object", nullable);
}
function checkArray(d: any, field: string): void {
  if (!Array.isArray(d) && d !== null && d !== undefined) {
    errorHelper(field, d, "array", true);
  }
}
function checkNumber(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'number' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "number", nullable);
  }
}
function checkString(d: any, nullable: boolean, field: string): void {
  if (typeof(d) !== 'string' && (!nullable || (nullable && d !== null && d !== undefined))) {
    errorHelper(field, d, "string", nullable);
  }
}
function checkNull(d: any, field: string): void {
  if (d !== null && d !== undefined) {
    errorHelper(field, d, "null or undefined", false);
  }
}
function errorHelper(field: string, d: any, type: string, nullable: boolean): never {
  if (nullable) {
    type += ", null, or undefined";
  }
  throw new TypeError('Expected ' + type + " at " + field + " but found:\n" + JSON.stringify(d) + "\n\nFull object:\n" + JSON.stringify(obj));
}
