import { Component, OnInit, SimpleChanges, OnChanges, Input } from '@angular/core';
import { ClrDatagridSortOrder } from '@clr/angular';
import { delay } from 'rxjs/operators';
import { VsrRecordEntity } from '../../shared/vsr';
import { VsrSearchService } from '../../vsr-search.service';
import { VsrProxy } from '../../shared/vsr-proxy';
import { AppSettings } from '../../shared/app-settings';

@Component({
  selector: 'app-vsr-history',
  templateUrl: './vsr-history.component.html',
  styleUrls: ['./vsr-history.component.css']
})
export class VsrHistoryComponent implements OnInit, OnChanges {
  @Input() vsrRecords: VsrRecordEntity[];
  vsrSelectedRecords: VsrRecordEntity[] = [];
  vsrSortedRecords: VsrRecordEntity[] = [];
  appsAlert: string = "";
  loading: boolean = false;
  viewMode: boolean = false;
  showHistory: boolean = true;
  rowSelection: boolean =  true;
  compareMessage: string = AppSettings.MAX_RECORDS_TO_COMPARE_WARNING;  
  maxRecordsToComparePrompt: string = AppSettings.MAX_RECORDS_TO_COMPARE_PROMPT;

  displayManualSearchButton: boolean =  false;
  model = {
    receiptNumber: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: 38.8977643,
    long: -77.0106754,
    streetView: '',
    fullMap: ''
  }

  vsrRows: any[] = [];


  constructor(private vsrSearchService: VsrSearchService) { }

  ngOnInit() {
    this.model.receiptNumber = sessionStorage.getItem("receiptNumber-key");
    if (this.model.receiptNumber !== "" || !this.vsrRecords || this.vsrRecords.length < 1) {
      this.displayManualSearchButton = false;
      this.refresh();
    }
    else
      if (this.vsrRecords.length > 0) {
        this.getVsrHistoryInfoFromInputData();
        console.log("no receipt.");
      }

    for (let i = 0; i < this.vsrRecords.length; i++) {
      let vsrRow = {
        disabled: false
      };
      this.vsrRows.push(vsrRow);


    }
  }

  ngOnChanges(changes: SimpleChanges) {
  }


  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private refresh(): void {
    this.model.receiptNumber = sessionStorage.getItem("receiptNumber-key");
    if (
      ((!this.vsrRecords || this.vsrRecords.length < 1) && (this.model.receiptNumber !== ""))
      ||
      ((this.vsrRecords.length >= 1) && (this.model.receiptNumber !== ""))

    )
      this.getVsrHistoryInfoFromService();
    else
      this.getVsrHistoryInfoFromInputData();
  }

  private getVsrHistoryInfoFromService() {

    (async () => {
      this.loading = true;
      await this.delay(5000);  //when simulating a long delay or timeout from a service.       

      // console.log('Inside vsr-history component, fetching history data after 5 sec delay');

      if (
        ((!this.vsrRecords || this.vsrRecords.length < 1) && (this.model.receiptNumber !== ""))
        ||
        ((this.vsrRecords.length >= 1) && (this.model.receiptNumber !== ""))

      ) {
        this.vsrSearchService.getVSRHistory(this.model.receiptNumber.toUpperCase()).subscribe(
          mainData => {
            if (mainData) {
              console.log("inside vsr-history - getting vsr history data from service.");
              this.vsrRecords = mainData.VsrGetResponse.VsrResultSet.VsrRecord;
              this.reverseSortVSRrecords();
            }
            else {
              this.appsAlert = "No records found matching this receipt number.";
              this.loading = false;

              sessionStorage.setItem("receiptNumber-key", "");
            }
          }, error => {
          });
      }
      else if ((this.vsrRecords && this.vsrRecords.length > 1) && (this.model.receiptNumber !== "")) {
        this.reverseSortVSRrecords();
        this.loading = false;
      }
    })();


  }

  private reverseSortVSRrecords() {
    let ind = this.vsrRecords.length - 1;
    for (let i: number = 0; i < this.vsrRecords.length; i++) {
      this.vsrSortedRecords.push(this.vsrRecords[ind]);
      ind -= 1;
    }
    this.loading = false;
    sessionStorage.setItem("receiptNumber-key", "");
    this.vsrSelectedRecords[0] =  this.vsrSortedRecords[this.vsrRecords.length - 1];
  }
  private selectionChanged($event) {
    // this.vsrSortedRecords.forEach((u, i)=>{
    //   console.log("the selection length is: " + this.vsrSelectedRecords.length);
    //   if (this.vsrSelectedRecords.length == 2) {
    //     console.log("selection = 2" + this.vsrSelectedRecords.length)
    //     if(this.vsrSelectedRecords.indexOf(u) == 0 || this.vsrSelectedRecords.indexOf(u) == 1)
    //     {
    //     this.vsrRows[i] = false;
    //   }
    //     else
    //     {        
    //       this.vsrRows[i] = true;
    //       console.log("this record is disabled:  " + this.vsrRows[i]);
    //     }
    //   }
    //   else{
    //     console.log("we are here...")        
    //     this.vsrRows[i] = false;
    //   }
    // });


    // if (this.vsrSelectedRecords.length > 2) {
    //     this.vsrSelectedRecords[2] = null;
    //     this.vsrSelectedRecords.splice(2, 1);
    //     console.log("we are here." + this.vsrSelectedRecords.length);
    // }
  }
  private getVsrHistoryInfoFromInputData() {

    if (this.vsrRecords && this.vsrRecords.length > 0) {
      console.log("the number of records retrieved from the input data is: " + this.vsrRecords.length);
      this.reverseSortVSRrecords();
    }
    this.loading = false;
    sessionStorage.setItem("receiptNumber-key", "");

  }
  private getScorecardStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return {  color: 'black','background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return {  color: 'black','background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return {  color: 'black','background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return {  color: 'white','background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }

  disableRows() {
    // if(this.vsrSelectedRecords.length > 2) this.vsrSelectedRecords.pop(this.vsrSelectedRecords[2]);

    //   for (let i = 0; i < this.vsrRecords.length - 1; i++) {
    //     if (this.vsrRecords.indexOf(this.vsrSelectedRecords[0]) == i ||
    //       this.vsrRecords.indexOf(this.vsrSelectedRecords[1]) == i
    //     ) {
    //       console.log("matching index: the vsrRecords.index is: " + i);

    //     }
    //     else {
    //       let vsrRow = {
    //         id: i,
    //         disabled: true
    //       };
    //       this.vsrRows.push(vsrRow);
    //     }

    //   }
    // 
  }

}



