import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VsrComponent } from './vsr.component';

describe('VsrComponent', () => {
  let component: VsrComponent;
  let fixture: ComponentFixture<VsrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VsrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VsrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
