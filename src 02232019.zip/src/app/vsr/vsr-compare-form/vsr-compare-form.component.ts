import { Component, OnInit, Input } from '@angular/core';
import { VsrRecordEntity, Vsr } from 'src/app/shared/vsr';
import { AppSettings } from '../../shared/app-settings';
@Component({
  selector: 'vsr-compare-form',
  templateUrl: './vsr-compare-form.component.html',
  styleUrls: ['./vsr-compare-form.component.css']
})


export class vsrCompareFormComponent implements OnInit {
  //private vsrUrl = '/vibe-plus/rest/vsr/receipt/';
  
  @Input() vsrSelected: VsrRecordEntity[] = [];
  @Input() vsrRecords: VsrRecordEntity[];
  adjudicativeStatusStyle: string = "success-standard";
  adjudicativeStatusStyle2: string = "success-standard";
  appsAlert;
  branchInfoAvailable: boolean = false;
  dolInformationAvailable: boolean;
  displayManualAddress: boolean = false;
  displayDOLCaseNumber: boolean = false;
  relatedToPetitioner1: string = "";
  relatedToPetitioner2: string = "";
  hasGrossAnualIncome: boolean;
  grossAnualIncome: string;
  grossAnualIncome2: string;
  outOfBusinessIndicator: boolean;
  outOfBusinessIndicator2: boolean;
  preDefinedScoreAvailable: boolean;
  Record1Exec1: string = "empty";
  Record2Exec1: string = "empty";
  resubmitShowModal: boolean = false;
  scoreCardID1: string;
  scoreCardID2: string;
  showForm = false;
  tradeStyle1: string = "";
  tradeStyle2: string = "";
  tradeStyle3: string = "";
  ValidEndDate: string = "Valid End Date:"
  ValidStartDate: string = "Valid Start Date:"
  vibePreDefinedCompanyScore: string;
  VIBEScoreResult_Score: string;
  VIBEScoreResult_Score2: string;
  vsrRecord1: VsrRecordEntity;
  vsrRecord1Index: string;
  vsrRecord2: VsrRecordEntity;
  vsrRecord2Index: string;

  model = {
    receiptNumber: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: 38.8977643,
    long: -77.0106754,
    streetView: '',
    fullMap: ''
  }

  constructor() {
  }

  ngOnInit() {
    this.refresh();
  }

  refresh(): void {
  //  console.log("refesh has started");    
    this.InitBooleans();

    if (this.vsrSelected && this.vsrSelected.length == 2) {
      this.showForm = true;
      this.appsAlert = "";
      this.scoreCardID1 = this.vsrSelected[0].ScoreID;
      this.scoreCardID2 = this.vsrSelected[1].ScoreID;

      this.vsrRecord1 = this.vsrSelected[0];
      this.vsrRecord2 = this.vsrSelected[1];


      this.vsrRecord1Index = "VSR " + (this.vsrRecords.indexOf(this.vsrRecord1) + 1);
      this.vsrRecord2Index = "VSR " + (this.vsrRecords.indexOf(this.vsrRecord2) + 1);
    //  console.log("vsrrecord1Index is: " + this.vsrRecord1Index);
     
      this.outOfBusinessIndicator = this.vsrRecord1.DNBDetailedCompanyInformation.OutOfBusinessIndicator;
      this.outOfBusinessIndicator2 = this.vsrRecord2.DNBDetailedCompanyInformation.OutOfBusinessIndicator;
      this.VIBEScoreResult_Score = this.vsrRecord1.VIBEScoreResult.Score;
      this.VIBEScoreResult_Score2 = this.vsrRecord2.VIBEScoreResult.Score;
      this.adjudicativeStatusStyle = this.getAdjudicativeStatusStyle(this.vsrRecord1.AdjudicativeStatus);
      this.adjudicativeStatusStyle2 = this.getAdjudicativeStatusStyle(this.vsrRecord2.AdjudicativeStatus);
    
    
     // console.log("before bindbusinessrule");
 this.bindBusinessRules();
 
 // console.log("after bindbusinessrule");
    
    }
    else {
      this.appsAlert = "No records found matching this receipt number.";
    }

  }

  private bindBusinessRules() {
    let receiptFromDate = new Date(AppSettings.DOL_DISPLAY_RECEIPT_FROM_DATE);
    let receiptDate1 = new Date(this.vsrRecord1.PetitionInformation.ReceiptDate.substr(0, 10));
    let receiptDate2 = new Date(this.vsrRecord2.PetitionInformation.ReceiptDate.substr(0, 10));

   // console.log("before checkForPredefinedInfo");
    this.checkForPredefinedInfo();

   // console.log("before checkForDNBCompanyFinancialInformation");
    this.checkForDNBCompanyFinancialInformation();


   // console.log("before checkFordolInformationAvailable");
    this.checkFordolInformationAvailable();

   // console.log("before checkForDisplayManualAddress");
    this.checkForDisplayManualAddress();

   // console.log("before checkForBranchInfoAvailable");
    this.checkForBranchInfoAvailable();   

   // console.log("before checkForExec1Available");
    this.checkForExec1Available();
    
   // console.log("before checkForPredefinedInfo");
    this.setDisplayDOLCaseNumber(this.vsrRecord1, receiptDate1, receiptFromDate);
    this.setDisplayDOLCaseNumber(this.vsrRecord2, receiptDate1, receiptFromDate);
   
   
  }
  private setDisplayDOLCaseNumber(vsrRcord:VsrRecordEntity, receiptDate1: Date, receiptFromDate: Date) {
    if (vsrRcord.PetitionInformation.DolEtaCaseNumber) {
      if ((this.vsrRecord1.PetitionInformation.PetitionVisaType === "1B1" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "E3" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "HSC" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "H2A" ||
        vsrRcord.PetitionInformation.PetitionVisaType === "H2B") &&
        (receiptDate1 >= receiptFromDate)
        &&
        (vsrRcord.DOLSummary))
        this.displayDOLCaseNumber = true;
        // console.log("setDisplayDOLCaseNumber is : " + this.displayDOLCaseNumber);
    }
  }


  private checkForExec1Available() {
    if (this.vsrRecord1.DNBCompanyExecutiveBio.Executive1 != null)
      this.Record1Exec1 = this.vsrRecord1.DNBCompanyExecutiveBio.Executive1;
    if (this.vsrRecord2.DNBCompanyExecutiveBio.Executive1 != null)
      this.Record2Exec1 = this.vsrRecord2.DNBCompanyExecutiveBio.Executive1;
  }

  private checkForBranchInfoAvailable() {
    if (this.vsrRecord1.DNBMatchedBranchInformation ||
      this.vsrRecord2.DNBMatchedBranchInformation)
      this.branchInfoAvailable = true;
  }

  private checkForDisplayManualAddress() {
    if (this.vsrRecord1.PetitionInformation.OrganizationDataSource === "Manual") {
      this.displayManualAddress = true;
      if (this.vsrRecord1.ManualSearchInfo.RelatedToPetitioner === true)
        this.relatedToPetitioner1 = "Y";
      else
        this.relatedToPetitioner1 = "N";
    }

    
    if (this.vsrRecord2.PetitionInformation.OrganizationDataSource === "Manual") {
      this.displayManualAddress = true;
      if (this.vsrRecord2.ManualSearchInfo.RelatedToPetitioner === true)
        this.relatedToPetitioner2 = "Y";
      else
        this.relatedToPetitioner2 = "N";
    }
  }

  private checkFordolInformationAvailable() {
    if (this.vsrRecord1.DOLSummary || this.vsrRecord2.DOLSummary) {
      this.dolInformationAvailable = true;
    }
    else
      this.dolInformationAvailable = false;
  }

  
  private checkForDNBCompanyFinancialInformation() {
    if (this.vsrRecord1.DNBCompanyFinancialInformation && this.vsrRecord1.DNBCompanyFinancialInformation.GrossAnualIncome) {
      this.hasGrossAnualIncome = true;
      let strGrossAnualIncome = this.vsrRecord1.DNBCompanyFinancialInformation.GrossAnualIncome;
      this.grossAnualIncome =
        parseInt(strGrossAnualIncome.substr(0, strGrossAnualIncome.indexOf('|')).trim(), 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,")
        + " " + (strGrossAnualIncome.substr(strGrossAnualIncome.indexOf('|') + 1)).trim();
      this.grossAnualIncome = this.grossAnualIncome.replace(".00", "");
      // console.log("gross anual income" + this.grossAnualIncome);
    }
    else
      this.hasGrossAnualIncome = false;

      if (this.vsrRecord2.DNBCompanyFinancialInformation && this.vsrRecord2.DNBCompanyFinancialInformation.GrossAnualIncome) {
        this.hasGrossAnualIncome = true;
        let strGrossAnualIncome2 = this.vsrRecord2.DNBCompanyFinancialInformation.GrossAnualIncome;
        this.grossAnualIncome2 =
          parseInt(strGrossAnualIncome2.substr(0, strGrossAnualIncome2.indexOf('|')).trim(), 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,")
          + " " + (strGrossAnualIncome2.substr(strGrossAnualIncome2.indexOf('|') + 1)).trim();
        this.grossAnualIncome2 = this.grossAnualIncome2.replace(".00", "");
        // console.log("gross anual income" + this.grossAnualIncome);
      }
      else
        this.hasGrossAnualIncome = false;
  }

  private checkForPredefinedInfo() {
    if (this.vsrRecord1.VibePreDefinedCompanyScore) {
      this.preDefinedScoreAvailable = true;
      this.vibePreDefinedCompanyScore = this.vsrRecord1.VibePreDefinedCompanyScore.OverrideScore;
    }
    else if (this.vsrRecord2.VibePreDefinedCompanyScore) {
      this.preDefinedScoreAvailable = true;
      this.vibePreDefinedCompanyScore = this.vsrRecord2.VibePreDefinedCompanyScore.OverrideScore;
    }
    else
      this.preDefinedScoreAvailable = false;
  }

  private InitBooleans() {
    this.branchInfoAvailable = false;
    this.displayManualAddress = false;
    this.dolInformationAvailable = false;
    this.hasGrossAnualIncome = false;
    this.outOfBusinessIndicator = false;
    this.preDefinedScoreAvailable = false;
    this.resubmitShowModal = false;
  }

  private getCompareFieldsStyle(fieldName: string): any {
    if (fieldName !== '') {
      let parameters: any[] = [];
      parameters = fieldName.split('.');
      let childNodes: number = 0;
      if (fieldName.includes('.'))
        childNodes = parameters.length;

      else {
        // this.vsrRecord1.DNBDetailedCompanyInformation.TradeStyleCodes.
        childNodes = 1;
      }
      //  parameters[0] = 'PetitionInformation';
      //  parameters[1] = 'OrganizationDataSource';
      let valueDifferent: boolean = false;

      try {

        switch (childNodes) {
          case 1:
            if (
              JSON.stringify(this.vsrRecord1[parameters[0]]) !== '{"nil":true}' &&
              JSON.stringify(this.vsrRecord2[parameters[0]]) !== '{"nil":true}'
            ) {
              if ((this.vsrRecord1[parameters[0]]) && (this.vsrRecord2[parameters[0]]) && (this.vsrRecord1[parameters[0]] != this.vsrRecord2[parameters[0]])) {
                return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
              }
            }

          case 2:
            if (
              JSON.stringify(this.vsrRecord1[parameters[0]][parameters[1]]) !== '{"nil":true}' &&
              JSON.stringify(this.vsrRecord2[parameters[0]][parameters[1]]) !== '{"nil":true}'
            ) {
              if (this.vsrRecord1[parameters[0]][parameters[1]] != this.vsrRecord2[parameters[0]][parameters[1]]) {
                return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
              }
            }
          case 3:
            if (fieldName === "PetitionInformation.Address.StreetFullText") {
              if (
                this.vsrRecord1.PetitionInformation.Address.StreetFullText !== this.vsrRecord2.PetitionInformation.Address.StreetFullText ||
                this.vsrRecord1.PetitionInformation.Address.LocationCityName !== this.vsrRecord2.PetitionInformation.Address.LocationCityName ||
                this.vsrRecord1.PetitionInformation.Address.LocationStateName !== this.vsrRecord2.PetitionInformation.Address.LocationStateName ||
                this.vsrRecord1.PetitionInformation.Address.LocationPostalCode !== this.vsrRecord2.PetitionInformation.Address.LocationPostalCode) {
                return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
              }
            }
            else if (fieldName === "DNBMatchedCompanyInformation.Address.StreetFullText") {
              if (
                this.vsrRecord1.DNBMatchedCompanyInformation.Address.StreetFullText !== this.vsrRecord2.DNBMatchedCompanyInformation.Address.StreetFullText ||
               // this.vsrRecord1.DNBMatchedCompanyInformation.Address.LocationCountryName !== this.vsrRecord2.DNBMatchedCompanyInformation.Address.LocationCountryName ||
                this.vsrRecord1.DNBMatchedCompanyInformation.Address.LocationCityName !== this.vsrRecord2.DNBMatchedCompanyInformation.Address.LocationCityName ||
                this.vsrRecord1.DNBMatchedCompanyInformation.Address.LocationStateName !== this.vsrRecord2.DNBMatchedCompanyInformation.Address.LocationStateName ||
                this.vsrRecord1.DNBMatchedCompanyInformation.Address.LocationPostalCode !== this.vsrRecord2.DNBMatchedCompanyInformation.Address.LocationPostalCode) {
                return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
              }
            }
            else if (fieldName === "ManualSearchInfo.Address.StreetFullText") {
              if (
                this.vsrRecord1.ManualSearchInfo.Address.StreetFullText !== this.vsrRecord2.ManualSearchInfo.Address.StreetFullText ||
                //this.vsrRecord1.ManualSearchInfo.Address.LocationCountryName !== this.vsrRecord2.ManualSearchInfo.Address.LocationCountryName ||
                this.vsrRecord1.ManualSearchInfo.Address.LocationCityName !== this.vsrRecord2.ManualSearchInfo.Address.LocationCityName ||
                this.vsrRecord1.ManualSearchInfo.Address.LocationStateName !== this.vsrRecord2.ManualSearchInfo.Address.LocationStateName ||
                this.vsrRecord1.ManualSearchInfo.Address.LocationPostalCode !== this.vsrRecord2.ManualSearchInfo.Address.LocationPostalCode) {
                return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
              }
            }
            else
              if (
                (childNodes !== 1 && this.vsrRecord1[parameters[0]][parameters[1]][parameters[2]])
                && (this.vsrRecord2[parameters[0]][parameters[1]][parameters[2]])
                && (this.vsrRecord1[parameters[0]][parameters[1]][parameters[2]] != this.vsrRecord2[parameters[0]][parameters[1]][parameters[2]])) {
                return { color: 'blue', 'background-color': 'turquoise', 'font-weight': 'bold' };
              }
          default: {
            valueDifferent = true;

            return {};
          }
        }
      } catch (error) {
        return {};
      }



    }
  }

  private getScoreResultStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { color: 'black', 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { color: 'black', 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { color: 'black', 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { color: 'white', 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }

  }

 
  getAdjudicativeStatusStyle(status:string): any {
    let statusIcon: string = "";
    switch (status) {
      case 'APPROVED':
        // return "success-standard";
        return "assets/approved.png";
      case 'PENDING':
        return "assets/pending.png";
      case 'DENIED':
        return "assets/denied.png";
      case 'DENIED FRAUD':
        return "assets/deniedFraud.png";
      case 'REJECTED':
        return "assets/rejected.png";
      case 'CLOSED':
        return "assets/closed.png";
      default:
        return "assets/unknown.png";
    }
  }
}
