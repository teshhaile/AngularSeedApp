import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { VsrGetResponseProxy } from '../shared/vsr-proxy';
import { VsrGetResponse } from '../shared/vsr';
import { VsrSearchService } from '../vsr-search.service';
import { Vsr } from '../shared/vsr';
import { Observable, of, Subscription } from 'rxjs';
import { GeocodeService } from '../geocode.service';
import { AppSettings } from '../shared/app-settings';
import { strictEqual } from 'assert';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { VsrRecordEntity } from '../shared/vsr-resubmit';
import { Dol, DOLDATA } from '../shared/dol_interfaces';
import { Previousfiling } from '../shared/previous_filings_interfaces';
import { SmartSearchBoxComponent } from '../smart-search-box/smart-search-box.component';
import { SmartSearchService } from '../smart-search.service';


@Component({
  selector: 'app-vsr',
  templateUrl: './vsr.component.html',
  styleUrls: ['./vsr.component.css'],
  providers: [GeocodeService]
})

export class VsrComponent implements OnInit {
  //private vsrUrl = '/vibe-plus/rest/vsr/receipt/';
  loading = false;
  searchBy: string = "Receipt Number";
  showVsr: boolean = false;
  show9142: boolean = false;
  dolInformationAvailable: boolean = false;
  showDOL_ETAPreviousFilings: boolean = false;
  showUSCISPreviousFilings: boolean = false;
  appsAlert: string = "";
  noVsrHistory: boolean = false;
  showVsrHistory: boolean = true;
  vsrHistoryActive: boolean = true;
  historyLoadingState: boolean = false;
  vsrActive: boolean = false;
  showDOL_ETA: boolean = false;
  DOL_ETA_Active: boolean = false;
  DOL_ETAPreviousFilingsActive: boolean = false;
  USCISPreviousFilingsActive: boolean = false;
  pfDunsNum: string = "";
  pfOrganizationName: string = "";
  pfPetitionType: string = "";
  etaDOLCaseNum: string = "";
  vsr: Vsr;
  vsrDOL: DOLDATA;
  pfsShowSmartMenu: boolean = false;
  previousFiling: Previousfiling;
  etaPetitionId: string = "";
  etaFormType: string = "";
  etaFormVersion: string = "";
  selectedVsrRecord: VsrRecordEntity;
  vsrHistoryRecords: VsrRecordEntity[];
  displayManualSearchButton: boolean = true;
  searchSubscription: Subscription;
  model = {
    searchById: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: 38.8977643,
    long: -77.0106754,
    streetView: '',
    fullMap: ''

  }



  private vsrSvc: VsrSearchService;

  searchTypes = ["VSR", "USCIS Previous Filings", "DOL Previous ETA Filings", "DOL ETA Lookup"];
  searchCriteria = ["Receipt Number"];

  constructor(
    private vsrSearchService: VsrSearchService,
    private geocodeService: GeocodeService,
    private ssb: SmartSearchService,
    private router: Router) {
    this.vsrSvc = vsrSearchService;

    //integration point with SSB
    this.searchSubscription = this.ssb.currentMessage.subscribe(message => {
      //console.log("search box: " + JSON.stringify(message)); 
      if ((message.selectedSearchType == "vsr") &&
        (message.selectedSearchFunction == "receiptNumber") &&
        (message.searchById != "") &&
        (message.searchById != undefined)) {
        this.model.searchById = message.searchById
        //console.log("this.model.searchById="+this.model.searchById); 
        this.getVsrButtonClicked();
        message.searchById = "";

      }
    }
    );
  }



  ngOnInit() {




    if (this.router.url.includes('receipt')) {
      var urlarr = this.router.url.split("/");
      this.model.searchById = urlarr[urlarr.length - 1];
      this.initProperties()
      this.refresh();

    }

    // console.log("the search id from the router link id is: " + this.model.searchById);
    if (this.model.searchById !== "") {
      console.log("starting to get vsr history data in the background...");
      this.getVsrHistoryInfoFromService();
    }
  }

  ngOnDestroy() {
    this.searchSubscription.unsubscribe();
  }
  private initProperties() {
    this.showVsrHistory = true;
    this.dolInformationAvailable = false;
    this.showDOL_ETAPreviousFilings = false;
    this.showUSCISPreviousFilings = false;
    this.noVsrHistory = false;
    this.vsrHistoryActive = false;
    this.vsrActive = false;
    this.showDOL_ETA = false;
    this.DOL_ETA_Active = false;
    this.DOL_ETAPreviousFilingsActive = false;
    this.USCISPreviousFilingsActive = false;
    this.pfDunsNum = "";
    this.pfOrganizationName = "";
    this.pfPetitionType = "";
    this.etaDOLCaseNum = "";
    this.etaPetitionId = "";

  }


  private onSearchTypeSelect(searchType) {
    switch (searchType.trim()) {
      case "VSR":
        this.searchCriteria = ["Receipt Number"];
        this.searchBy = "Receipt Number";
        break;
      case "USCIS Previous Filings":
        this.searchCriteria = ["DUNS Number", "Business Name and Address", "FEIN Number"];
        this.searchBy = "DUNS Number";
        break;
      case "DOL Previous ETA Filings":
        this.searchCriteria = ["DOL ETA Case Number"];
        this.searchBy = "DOL ETA Case Number";
        break;
      case "DOL ETA Lookup":
        this.searchCriteria = ["DOL ETA Case Number"];
        this.searchBy = "DOL ETA Case Number";
        break;
      default:
        this.searchCriteria = ["Receipt Number"];
        break;
    }

    this.model.searchById = "";
  }

  private displayHistory() {
    //console.log("there are " + this.vsrHistoryRecords.length + "history records.");
    this.showVsrHistory = true;
    this.historyLoadingState = false;
  }

  private vsrTabClicked() {
    this.vsrActive = true;

  }

  private onSelect(category) {
    this.searchBy = category;
    this.model.searchById = "";

  }

  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private onEtaSearchComplete(pvf: string[]) {
    if (pvf) {
      console.log("there is dol inside vsr.");
      this.etaPetitionId = pvf[0];
      this.etaFormType = pvf[1];
      this.etaFormVersion = pvf[2];
      if (this.etaFormType == "9142")
        this.show9142 = true;
      else
        this.show9142 = false;
      this.showDOL_ETA = true;
      this.DOL_ETA_Active = true;
      this.vsrActive = false;
    }
  }

  private onPFSSearchBegin(pvf: string[]) {
    if (pvf) {
      console.log("there is previous filing data inside vsr. the etadolcasenum is: " + pvf[3] + "pvf0 is: " + pvf[0]);
      this.pfDunsNum = pvf[0];
      this.pfOrganizationName = pvf[1];
      this.pfPetitionType = pvf[2];
      this.etaDOLCaseNum = pvf[3];
      if (this.etaDOLCaseNum && this.etaDOLCaseNum !== "") {
        this.DOL_ETAPreviousFilingsActive = true;
        this.showDOL_ETAPreviousFilings = true;
      }
      else if (this.pfDunsNum && this.pfDunsNum !== "") {
        this.USCISPreviousFilingsActive = true;
        this.showUSCISPreviousFilings = true;
      }


      this.vsrActive = false;
    }
  }

  private getVsrButtonClicked(): void {
    this.appsAlert = "";
    this.initProperties();
    // console.log("inside getVsrButtonClicked this.model.searchById" + this.model.searchById);
    if (this.model.searchById !== "") {
      this.refresh();
    }
    else {
      this.appsAlert = "Please enter a valid Search Id Number.";
      this.loading = false;
      this.showVsr = false;
    }

  }

  refresh(): void {
    this.vsrHistoryRecords = [];
    this.showVsr = false;
    this.dolInformationAvailable = false;
    this.loading = true;

    this.vsrSvc.getVSR(this.model.searchById.toUpperCase()).subscribe(
      data => {
        if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes("ESB2Exception")) {
          this.vsr = data;
          // console.log(JSON.stringify(this.vsr));
          this.selectedVsrRecord = this.vsr.VsrGetResponse.VsrResultSet.VsrRecord[0] as VsrRecordEntity;
          this.appsAlert = "";
          this.loading = false;
          this.showVsr = true;
          if (this.selectedVsrRecord.DOLSummary) {
            console.log("the caseNumber in dolsummary is:  " + this.selectedVsrRecord.DOLSummary.EtaCaseNumber);
            this.dolInformationAvailable = true;
          }
          sessionStorage.setItem("receiptNumber-key", this.selectedVsrRecord.ReceiptNumber);

          (async () => {
            // this.loading = false;
            //await this.delay(5000);  //when simulating a long delay or timeout from a service.
            // console.log('fetching history data after 5 sec delay');
            this.getVsrHistoryInfoFromService();
          })();
        }
        else {
          if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
            this.appsAlert = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
          else
            this.appsAlert = AppSettings.VSR_STATUS_CODE_004_DESC;
          this.loading = false;
          this.noVsrHistory = true;
        }
      }, error => {
        (async () => {
          // await this.delay(1000);  //when simulating a long delay or timeout from a service.

          this.appsAlert = JSON.stringify(error);

          this.loading = false;
        })();
      }
    );
    this.model.searchById = "";
  }

  private switchTabs() {
    this.pfDunsNum = "";
    this.pfOrganizationName = "";
    this.pfPetitionType = "";
    this.vsrDOL = null;
    this.etaPetitionId = "";
    this.etaDOLCaseNum = "";
    //this.vsrHistoryActive = true;
  }
  private switchActiveTabs() {
    this.switchTabs();
    this.showDOL_ETA = false;
    this.showDOL_ETAPreviousFilings = false;
    this.showUSCISPreviousFilings = false;
    //this.vsrHistoryActive = true;
  }

  private getVsrHistoryInfoFromService() {
    this.historyLoadingState = true;
    this.vsrSearchService.getVSRHistory(sessionStorage.getItem("receiptNumber-key").toUpperCase()).subscribe(mainData => {
      if (mainData) {

        this.vsrHistoryRecords = mainData.VsrGetResponse.VsrResultSet.VsrRecord;
        this.loading = false;
        this.historyLoadingState = false;
        sessionStorage.setItem("receiptNumber-key", "");
        if (this.vsrHistoryRecords.length > 1)
          this.displayHistory();
          else
          this.showVsrHistory = false;
      }
      else {
        this.loading = false;
        this.noVsrHistory = true;
        console.log("no history data. the this.model.searchById.toUpperCase() is: " + this.model.searchById.toUpperCase());
      }
    }, error => {
      (async () => {
        //await delay(10000);  //when simulating a long delay or timeout from a service.
        console.log('error hapened.');
        this.loading = false;

      })();
    });
  }


}
