
import { GeocodeService } from 'src/app/geocode.service';
import { Component, Input, OnInit, Output, SimpleChanges, EventEmitter } from '@angular/core';
import { VsrRecordEntity, Vsr } from 'src/app/shared/vsr';
import { AppSettings } from '../../shared/app-settings';
import { VsrSearchService } from '../../vsr-search.service';
import { PreviousFilingsService } from '../../previous-filings.service';
import { previousfilingProxy } from '../../shared/previous_filings_proxy';

import { Previousfiling } from '../../shared/previous_filings_interfaces';
import { DolEtaSearchService } from '../../dol-eta-search.service';
import { DolData, DOLDATA } from '../../shared/dol_interfaces';
import { load, urlSettings } from 'google-maps-promise';
import { UserInRoleService } from '../../user-profile/user-in-role.service';
@Component({
  selector: 'vsr-primary-form',
  templateUrl: './vsr-primary-form.component.html',
  styleUrls: ['./vsr-primary-form.component.css']
})


export class vsrPrimaryFormComponent implements OnInit {
  @Input() vsrRecord: VsrRecordEntity;
  @Input() displayManualSearch: boolean = true;
  @Input() vsrReceipt: string = "";
  @Output() etaSearchComplete: EventEmitter<string[]> = new EventEmitter<string[]>();
  @Output() pfsSearchComplete: EventEmitter<Previousfiling> = new EventEmitter<Previousfiling>();
  @Output() pfsSearchBegin: EventEmitter<string[]> = new EventEmitter<string[]>();
  showForm: boolean = false;
  showMap: boolean = true;
  showPetitionerAlert: boolean = false;
  showIIPAlert: boolean = false;
  showManualAlert: boolean = false;
  alertMessage = AppSettings.GOOGLEMAPS_NO_STREETVIEW;
  loadingmap: boolean = false;
  dolEta: any
  adjucativeStatusStyle: string = "success-standard";
  appsAlert;
  companyAddress = "";
  branchInfoAvailable: boolean = false;
  etaPetitionId: string = "";
  etaCaseIdNum: string = "";
  dolAlertMessage: string = "";
  dolInformationAvailable: boolean = false;
  displayManualAddress: boolean = false;
  displayDOLCaseNumber: boolean = false;
  DOLManualSearchModal: boolean = false;
  relatedToPetitioner: string = "";
  etaCaseNumbeLength: number = 15;
  exec1: string = "empty";
  hasGrossAnualIncome: boolean = false;
  grossAnualIncome: string;
  loading: boolean = false;
  multipleDolEta: string[] = [];
  outOfBusinessIndicator: string = "";
  preDefinedScoreAvailable: boolean = false;
  resubmitShowModal: boolean = false;
  scoreCardID: string;
  searchBy: string = "Receipt Number";
  selectedEtaNumber: string = "";
  showCard: boolean = true;
  showVsr: boolean = false;
  showDOLdates: boolean = true;
  userInRoeleDol: boolean = false;
  ValidEndDate: string = "Valid End Date:"
  ValidStartDate: string = "Valid Start Date:"
  vibePreDefinedCompanyScore: string;
  VIBEScoreResult_Score: string;
  vsr: Vsr;

  private dolSvc: DolEtaSearchService;
  dol: DolData;
  previousFiling: Previousfiling;
  showEta: boolean = false;

  model = {
    searchById: "", //"WAC1802550980" //WAC1419550371 - no DOL,
    lat: -0.0,
    long: -0.0,
    streetView: '',
    fullMap: ''
  }

  private vsrSvc: VsrSearchService;
  private geocodeSvc: GeocodeService;
  geoInfo = [];
  orgs: string[];


  constructor(
    private vsrSearchService: VsrSearchService, private geocodeService: GeocodeService,
    private dolEtaService: DolEtaSearchService, private pfSvc: PreviousFilingsService, private userInRoleService: UserInRoleService) {
    this.vsrSvc = vsrSearchService;
    this.geocodeSvc = geocodeService;
  }

  ngOnInit() {
    if (this.userInRoleService.userInRole.dolUser) this.userInRoeleDol = true;
    console.log("does the user have a DOL role? " + this.userInRoeleDol);
    if (this.vsrReceipt && this.vsrReceipt !== "") {
      console.log("inside ngOnInit");
      this.refreshFromService(this.vsrReceipt)
    }
    else
      this.refresh();
  }

  private ngOnChanges(changes: SimpleChanges) {
    console.log("change is happening in vsr, so refreshing starts ...");
    if (this.vsrReceipt && this.vsrReceipt !== "") {
      this.refreshFromService(this.vsrReceipt)
    }
    else
      this.refresh();
  }

  private onSelect(category) {
    this.searchBy = category;
    this.model.searchById = "";
  }

  refresh(): void {
    this.InitBooleans();
    if (this.vsrRecord) {
      // console.log("inside refresh, starting to refresh data.");
      // console.log("the vsrRecord is: " + JSON.stringify(this.vsrRecord));
      this.bindBusinessRules();
      this.appsAlert = "";
      this.companyAddress = this.vsrRecord.PetitionInformation.Address.StreetFullText + " " +
        this.vsrRecord.PetitionInformation.Address.LocationCityName + " " +
        this.vsrRecord.PetitionInformation.Address.LocationStateName + " " +
        this.vsrRecord.PetitionInformation.Address.LocationPostalCode;

      // this.getGeoLocationForAddress(this.companyAddress)
      var latlong = this.model.lat + "," + this.model.long
      // this.model.fullMap = this.geocodeService.getFullMapForLatLong(latlong)
      if (this.vsrRecord.DNBDetailedCompanyInformation) {
        if (this.vsrRecord.DNBDetailedCompanyInformation.OutOfBusinessIndicator)
          this.outOfBusinessIndicator = "Record is inactive";
        else this.outOfBusinessIndicator = "Record is active";
      }
      if (this.vsrRecord.VIBEScoreResult)
        // this.showVibeScoreResult = true;
        this.VIBEScoreResult_Score = this.vsrRecord.VIBEScoreResult.Score;
      this.adjucativeStatusStyle = this.getAdjudicativeStatusStyle();
      this.scoreCardID = this.vsrRecord.ScoreID;
      this.showForm = true;
      this.showVsr = true;

    }
    else {
      this.appsAlert = "No receipts found matching this receipt number.";
      this.loading = false;
      this.showVsr = false;
    }
    this.loading = false;
  }

  private bindBusinessRules() {
    let receiptFromDate = new Date(AppSettings.DOL_DISPLAY_RECEIPT_FROM_DATE);
    let receiptDate = new Date(this.vsrRecord.PetitionInformation.ReceiptDate.substr(0, 10));


    this.checkForPredefinedInfo();



    this.checkForDNBCompanyFinancialInformation();


    this.checkFordolInformationAvailable();
    // console.log("the dol information available: " + this.dolInformationAvailable);


    this.checkForDisplayManualAddress();

    this.checkForBranchInfoAvailable();


    this.checkForExec1Available();

    this.checkForDisplayDOLCaseNumber(receiptDate, receiptFromDate);
  }

  private checkForDisplayDOLCaseNumber(receiptDate: Date, receiptFromDate: Date) {
    if (this.vsrRecord.PetitionInformation.DolEtaCaseNumber) {
      if ((this.vsrRecord.PetitionInformation.PetitionVisaType === "1B1" ||
        this.vsrRecord.PetitionInformation.PetitionVisaType === "E3" ||
        this.vsrRecord.PetitionInformation.PetitionVisaType === "HSC" ||
        this.vsrRecord.PetitionInformation.PetitionVisaType === "H2A" ||
        this.vsrRecord.PetitionInformation.PetitionVisaType === "H2B") &&
        (receiptDate >= receiptFromDate)
        &&
        (this.vsrRecord.DOLSummary))
        this.displayDOLCaseNumber = true;
    }
  }

  private checkForExec1Available() {
    if (this.vsrRecord.DNBCompanyExecutiveBio && this.vsrRecord.DNBCompanyExecutiveBio.Executive1 != null)
      this.exec1 = this.vsrRecord.DNBCompanyExecutiveBio.Executive1;
  }

  private checkForBranchInfoAvailable() {
    if (this.vsrRecord.DNBMatchedBranchInformation)
      this.branchInfoAvailable = true;
  }

  private checkForDisplayManualAddress() {
    if (this.vsrRecord.PetitionInformation.OrganizationDataSource === "Manual") {
      this.displayManualAddress = true;
      if (this.vsrRecord.ManualSearchInfo.RelatedToPetitioner === true)
        this.relatedToPetitioner = "Y";
      else
        this.relatedToPetitioner = "N";
    }
    else
      this.displayManualAddress = false;
  }
  private checkFordolInformationAvailable() {
    if (this.vsrRecord.DOLSummary) {
      this.multipleDolEta = this.vsrRecord.PetitionInformation.DolEtaCaseNumber.split(',');
      if (this.multipleDolEta.length > 0)
        this.selectedEtaNumber = this.vsrRecord.DOLSummary.EtaCaseNumber;
      else
        this.selectedEtaNumber = this.vsrRecord.PetitionInformation.DolEtaCaseNumber;
      if (this.vsrRecord.PetitionInformation.PetitionVisaType === "1B1" ||
        this.vsrRecord.PetitionInformation.PetitionVisaType === "E3" ||
        this.vsrRecord.PetitionInformation.PetitionVisaType === "HSC") {        
          this.ValidStartDate = "Intended Employment Begin Date:";
          this.ValidEndDate = "Intended Employment End Date";    

        if (this.vsrRecord.DOLSummary.DolEtaFormType == "9035") {
          this.display9035DOLSummary();
        }
      }
      // console.log("this.selectedEtaNumber: " + this.selectedEtaNumber);
      if (this.selectedEtaNumber && this.selectedEtaNumber.includes("-"))
        this.etaCaseNumbeLength = 18;
      if (this.selectedEtaNumber && this.selectedEtaNumber.length > 0)
        this.dolInformationAvailable = true;
    }
    else
      this.dolInformationAvailable = false;
  }
  private display9035DOLSummary() {
    if (this.vsrRecord.DOLSummary.EtaStatus == 'CERTIFIED'
      || this.vsrRecord.DOLSummary.EtaStatus == 'Certified-Withdrawn'
      || this.vsrRecord.DOLSummary.EtaStatus == 'CERTIFIED-WITHDRAWN') {
      this.ValidStartDate = "Certification Valid From:";
      this.ValidEndDate = "Certification Valid To:";
    }
    else
      this.showDOLdates = false;
  }

  private checkForDNBCompanyFinancialInformation() {
    if (this.vsrRecord.DNBCompanyFinancialInformation && this.vsrRecord.DNBCompanyFinancialInformation.GrossAnualIncome) {
      this.hasGrossAnualIncome = true;
      let strGrossAnualIncome = this.vsrRecord.DNBCompanyFinancialInformation.GrossAnualIncome;
      this.grossAnualIncome =
        parseInt(strGrossAnualIncome.substr(0, strGrossAnualIncome.indexOf('|')).trim(), 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,")
        + " " + (strGrossAnualIncome.substr(strGrossAnualIncome.indexOf('|') + 1)).trim();
      this.grossAnualIncome = this.grossAnualIncome.replace(".00", "");
      // console.log("gross anual income" + this.grossAnualIncome);
    }
    else
      this.hasGrossAnualIncome = false;
  }

  private checkForPredefinedInfo() {
    if (this.vsrRecord.VibePreDefinedCompanyScore) {
      this.preDefinedScoreAvailable = true;
      this.vibePreDefinedCompanyScore = this.vsrRecord.VibePreDefinedCompanyScore.OverrideScore;
    }
    else
      this.preDefinedScoreAvailable = false;
  }

  private InitBooleans() {
    this.loading = true;
    this.branchInfoAvailable = false;
    this.displayManualAddress = false;
    this.dolInformationAvailable = false;
    this.hasGrossAnualIncome = false;
    this.outOfBusinessIndicator = "";
    this.preDefinedScoreAvailable = false;
    this.resubmitShowModal = false;
    this.showDOLdates = true;
  }

  private onResubmitComplete(resubmitStatus: string): void {
    console.log("onResubmitComplete called. the status is: " + resubmitStatus);
    let vsrUrl = '/vsr/receipt';// + "WAC1804550499" ; //this.vsrRecord.ReceiptNumber;
    let receipt = this.vsrRecord.ReceiptNumber;
    this.refreshFromService(receipt);


  }

  private refreshFromService(receiptNumber): void {
    this.vsrSvc.getVSR(receiptNumber.toUpperCase()).subscribe(
      data => {
        if (data) {
          this.vsr = data;
          this.vsrRecord = this.vsr.VsrGetResponse.VsrResultSet.VsrRecord[0] as VsrRecordEntity;
          sessionStorage.setItem("receiptNumber-key", this.vsrRecord.ReceiptNumber.toUpperCase());
          this.refresh();
        }
      }, error => {
        console.log("error happens while retrieving data from the service. " + JSON.stringify(error));
      }
    );
  }
  private async  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  onShowModalChange(showModal: boolean): void {

    //console.log("onShowModalChange called. the display status is: " + showModal);

    (async () => {
      await this.delay(5000);
    });

    this.loading = false;
    this.resubmitShowModal = false
  }

  private onResubmitBegin(resubmitStatus: string): void {

    // console.log("onResubmitBegin called. the status is: " + resubmitStatus);
    this.updateVSRStatus(resubmitStatus);
  }

  private updateVSRStatus(resubmitStatus: string) {
    // console.log("updateVSRStatus called. the status is: " + resubmitStatus);
    if (resubmitStatus === AppSettings.VSR_STATUS_CODE_002) {
      this.loading = false;
      this.resubmitShowModal = false;
      this.showVsr = true;
    }
    else if (resubmitStatus === "in progress") {
      this.loading = true;
      this.showVsr = true;
    }
    else {
      switch (resubmitStatus) {
        case AppSettings.VSR_STATUS_CODE_001:
          this.appsAlert = AppSettings.VSR_STATUS_CODE_001_DESC;
          break;
        case AppSettings.VSR_STATUS_CODE_004:
          this.appsAlert = AppSettings.VSR_STATUS_CODE_004_DESC;
          break;
        default:
          this.appsAlert = AppSettings.VSR_STATUS_CODE_003_DESC;
          break;
      }
      this.showVsr = false;
      this.loading = false;
      this.resubmitShowModal = false;
    }
  }

  private showScoreCard() {
    this.scoreCardID = this.vsrRecord.ScoreID;
  }

  private locateOnMapClick() {
    var latlong = this.model.lat + "," + this.model.long
    this.model.fullMap = this.geocodeService.getFullMapForLatLong(latlong)
    window.open(this.model.fullMap, "_blank");

  }
  private getGeoMapAddress(addressType): any {
    let address: string = "";
    switch (addressType) {
      case 'PETITION':
        // if (this.vsrRecord.PetitionInformation.Address != null)
        address = this.vsrRecord.PetitionInformation.Address.StreetFullText + " " +
          this.vsrRecord.PetitionInformation.Address.LocationCityName + " " +
          this.vsrRecord.PetitionInformation.Address.LocationStateName + " " +
          this.vsrRecord.PetitionInformation.Address.LocationPostalCode;
        break;

      case 'IIP':
        if (this.vsrRecord.DNBMatchedCompanyInformation.Address)
          address = this.vsrRecord.DNBMatchedCompanyInformation.Address.StreetFullText + ', ' +
            this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCityName + ', ' +
            this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationStateName + ', ' +
            this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationPostalCode + ' ' +
            this.vsrRecord.DNBMatchedCompanyInformation.Address.LocationCountryName;
        break;

      case 'MANUAL':
        if (this.vsrRecord.ManualSearchInfo)
          address = this.vsrRecord.ManualSearchInfo.Address.StreetFullText + ', ' +
            this.vsrRecord.ManualSearchInfo.Address.LocationCityName + ', ' +
            this.vsrRecord.ManualSearchInfo.Address.LocationStateName + ', ' +
            this.vsrRecord.ManualSearchInfo.Address.LocationPostalCode + ' ' +
            this.vsrRecord.ManualSearchInfo.Address.LocationCountryName;
        break;

      default:
        address = "";
        break;

    }
    console.log("the address typeis: " + addressType);
    console.log("the address is: " + address);
    this.getGeoLocationForAddress(address, addressType);
    console.log("the latitude is: " + this.model.lat);
    console.log("the longitude is: " + this.model.long);
  }


  getGeoLocationForAddress(address: string, addressType: string) {
    this.showMap = true;
    this.showPetitionerAlert = false;
    this.showIIPAlert = false;
    this.showManualAlert = false;
    if (address.toUpperCase().includes('P.O.BOX') ||
      address.toUpperCase().includes('PO BOX')) {
      console.log('address contains p.o.box');
      this.showMap = false;
      this.alertMessage = AppSettings.PO_BOX_STREET_VIEW_NOT_AVAILABLE;
      this.setWarnings(addressType);
    }
    else {
      try {
        this.geocodeService.getLatLongForAddress(address).subscribe(data => {

          if (data) {
            this.model.lat = JSON.parse(JSON.stringify(data)).results[0].geometry.location.lat;
            this.model.long = JSON.parse(JSON.stringify(data)).results[0].geometry.location.lng;
            var latlong = this.model.lat + "," + this.model.long;
            this.model.fullMap = this.geocodeService.getFullMapForLatLong(latlong);
            console.log("calling to load streetview.");
            this.loadStreetView(addressType);
          } else {
            this.model.lat = 0.0;
            this.model.long = 0.0;
          }
        });
      } catch (error) {
        this.model.lat = 0.0;
        this.model.long = 0.0;
      }
    }
  }
  private setWarnings(addressType) {
    switch (addressType) {
      case 'PETITION':

        this.showPetitionerAlert = true;
        break;

      case 'IIP':
        this.showIIPAlert = true;
        break;

      case 'MANUAL':
        this.showManualAlert = true;
        break;

      default:
        /// to clear warnings
        this.showPetitionerAlert = false;
        this.showIIPAlert = false;
        this.showManualAlert = false;
        break;

    }
  }

  async loadStreetView(addressType): Promise<void> {
    // if (document.getElementById('street-view').innerHTML) {
    //   return;
    // }
    this.showMap = true;
    this.setWarnings("");
    urlSettings.key = AppSettings.API_KEY;
    urlSettings.version = null;
    const Maps = await load();


    console.log(this.model.lat + this.model.long)
    var latlong = new Maps.LatLng(this.model.lat, this.model.long);
    // Or you can use `new google.maps.Map` instead
    var svService = new Maps.StreetViewService();
    var panoRequest = {
      location: latlong,
      preference: google.maps.StreetViewPreference.NEAREST,
      radius: 50,
      source: google.maps.StreetViewSource.OUTDOOR
    };


    new Maps.Map(document.getElementById('map'), {
      center: new Maps.LatLng(0.0, 0.0),
      zoom: 14
    });
    var self = this
    var something = svService.getPanorama(panoRequest, function (panoData, status) {
      console.log(panoData);
      console.log(status)

      if (status.toString() == 'OK') {

        new Maps.StreetViewPanorama(
          document.getElementById('map'),
          {
            pano: panoData.location.pano,
            pov: { heading: 280, pitch: 0 },
          });

      } else {
        console.log(addressType);
        self.setWarnings(addressType);
        self.alertMessage = AppSettings.GOOGLEMAPS_NO_STREETVIEW;
        console.log(self.showPetitionerAlert)


        try {
          var map = new Maps.Map(document.getElementById('map'), {
            center: latlong,
            zoom: 14
          });
          var marker = new Maps.Marker({
            position: latlong,
            map: map,
            title: "Location"
          });

        }
        catch (error) {
          console.log(error)
          self.showMap = false;
          self.alertMessage = AppSettings.GOOGLEMAPS_NO_MAP;
        }

        // this.showMap = true;
        //Handle other statuses here

      }
    });


    //  var pano = new Maps.StreetViewPanorama(
    //     document.getElementById('pano2'), {
    //       position: latlong,
    //       pov: {
    //         heading: 260,
    //         pitch: 0
    //       }
    //     });
    //     pano.getPhotographerPov();

  }

  private manualSearchClick() {
    this.resubmitShowModal = true;
  }

  private DOLManualSearchModalCancelled() {
    this.DOLManualSearchModal = false;
    this.dolAlertMessage = "";
  }
  private DOLManualSearchShowModal() {
    this.etaCaseIdNum = "";
    this.dolAlertMessage = "";
    this.DOLManualSearchModal = true;
  }
  private displayCurrentDolInfo() {

  }

  private updateDolPetitionInfo(etaCaseId: string) {

    let dolEtaSearchParams: string[] = [];
    if (etaCaseId && etaCaseId !== "" && etaCaseId !== null) {
      this.etaPetitionId = this.vsrRecord.DOLSummary.PetitionID;
    }
    dolEtaSearchParams.push(this.etaPetitionId);
    dolEtaSearchParams.push(this.vsrRecord.DOLSummary.DolEtaFormType);
    dolEtaSearchParams.push(this.vsrRecord.DOLSummary.DolEtaFormVersion);
    this.etaSearchComplete.emit(dolEtaSearchParams);
  }

  private getDolCaseData(etaCaseId: string) {
    if (etaCaseId && etaCaseId !== "" && etaCaseId !== null) {
      console.log("the etacase number is: " + etaCaseId);
      this.loading = true;


      this.dolEtaService.getDolByCaseId(etaCaseId.toUpperCase().replace(/-/g, '')).subscribe(
        data => {
          try {

            this.dol = <DolData>JSON.parse(data.GetDolDetailByEtaCaseNumberResponse.DolJsonData);
            this.dolEta = <DOLDATA>this.dol.DOL_DATA
            if (this.dolEta.DOL_ETA_CLOB) {
              if (this.dolEta.DOL_ETA_CLOB.RESPONSECODE !== "NO_DATA" &&
                data && !JSON.stringify(data).includes("Error") &&
                !JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108)) {
                console.log("some data returned. " + JSON.stringify(data));
                console.log("the dol data is : " + JSON.stringify(this.dol));
                this.etaPetitionId = this.vsrRecord.DOLSummary.PetitionID;
                this.loading = false;
                this.DOLManualSearchModal = false;
                this.updateDolPetitionInfo(etaCaseId);
              }
              else {
                console.log("JSON.stringify(data) is " + JSON.stringify(data));
                if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
                  this.dolAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
                else
                  this.dolAlertMessage = "DOL case not found.";
                this.loading = false;
              }
            }
            else {
              console.log("JSON.stringify(data) is " + JSON.stringify(data));
              if (JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108))
                this.dolAlertMessage = AppSettings.VSR_EXCEPTION_CODE_0108_DESC;
              else
                this.dolAlertMessage = "DOL case not found.";
              this.loading = false;
            }


          } catch (error) {
            console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
            this.dolAlertMessage = JSON.stringify(error);
            this.loading = false;
          }
        },
        error => {
          console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
          this.dolAlertMessage = JSON.stringify(error);
          this.loading = false;
        }
      );
      this.etaCaseIdNum = "";
    }
    else this.dolAlertMessage = "Please enter a valid DOL Case Number.";
  }

  private getPreviousFilingsByDunsAndOrgName(prevsdunsNum: string, prevsOrgName, prevsPetitionType, dolCaseNum) {

    try {
      let pfsParams: string[] = [];
      pfsParams.push(prevsdunsNum);
      pfsParams.push(prevsOrgName);
      pfsParams.push(prevsPetitionType);
      pfsParams.push(dolCaseNum);

      console.log("starting to process previous filings." + pfsParams[0] + ",  " + pfsParams[1] + ",  " + pfsParams[2] + pfsParams[3])
      this.pfsSearchBegin.emit(pfsParams);
    } catch (error) {
      console.log("error while processing previous filings.")
    }

    // 
  }
  private getPreviousFilingsByDolCase(dolCaseNum: string) {
    if (dolCaseNum && dolCaseNum !== "" && dolCaseNum !== null) {
      console.log("the dolCaseNum number is: " + dolCaseNum);
      this.loading = true;

      this.pfSvc.getPreviousFilingsByDolcase(dolCaseNum.toUpperCase().replace(/-/g, '')).subscribe(
        data => {
          try {
            if (data && !JSON.stringify(data).includes("Error") && !JSON.stringify(data).includes(AppSettings.VSR_EXCEPTION_CODE_0108)) {
              console.log("preivious filings data returned. " + JSON.stringify(data));
              this.previousFiling = JSON.parse(JSON.stringify(data).replace("PreviousFilings-GetByDolCaseNumberResponse", "PreviousFilingsGetByDolCaseNumberResponse"));
              this.showEta = true;
              this.loading = false;
              this.pfsSearchComplete.emit(this.previousFiling);
            }
            else {
              console.log("JSON.stringify(data) is " + JSON.stringify(data));
              this.loading = false;
            }
          } catch (error) {
            console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
            this.loading = false;
          }
        },
        error => {
          console.log("error happens while retrieving dol data from the service. " + JSON.stringify(error));
          this.dolAlertMessage = JSON.stringify(error);
          this.loading = false;
        }
      );
    }
    else this.dolAlertMessage = "Please enter a valid DOL Case Number.";
  }
  private getScoreResultStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }

  private getAdjudicativeStatusStyle(): any {
    let status = this.vsrRecord.AdjudicativeStatus;
    switch (status) {
      case 'APPROVED':
        // return "success-standard";
        return "assets/approved.png";
      case 'PENDING':
        return "assets/pending.png";
      case 'DENIED':
        return "assets/denied.png";
      case 'DENIED FRAUD':
        return "assets/deniedFraud.png";
      case 'REJECTED':
        return "assets/rejected.png";
      case 'CLOSED':
        return "assets/closed.png";
      default:
        return "assets/unknown.png";
    }
  }

}
