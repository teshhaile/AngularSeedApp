import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../shared/user-profile';
import { UserIcamProfile } from '../shared/user-icam-profile';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfilesComponent implements OnInit {


  userProfile: UserProfile; 
  userIcamProfile: UserIcamProfile; 

  constructor() {
   }

  ngOnInit() {
  }

}
