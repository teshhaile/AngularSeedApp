import { Injectable } from '@angular/core';
import { UserProfile } from '../shared/user-profile';

@Injectable()
export class UserInRoleService {
  userInRole:UserProfile;
}
