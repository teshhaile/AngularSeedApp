import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError, map, tap } from'rxjs/operators';
import { Observable } from 'rxjs';
import { ScoreCard } from '../shared/score-card';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type':'Application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class ScoreCardService {
  constructor(private http:HttpClient) { }

  public getCards(url):Observable <ScoreCard>{
    return this.http.get<ScoreCard>(url).pipe(
        tap(data => {
          if(data)
          this.log(
            "fetched score card SourceTransactionID is: " + data.ScoreCardGetResponse.SourceTransactionID
            )
        }
        ));    
    }     
  
    private log(message:string){
      //console.log(message)
    }
}
