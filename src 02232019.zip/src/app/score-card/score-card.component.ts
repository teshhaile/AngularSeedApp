import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ScoreCard, ScoreCardRecordEntity } from '../shared/score-card';
import { ScoreCardService } from './score-card.service';
import { AppSettings } from '../shared/app-settings';

@Component({
  selector: 'app-score-card',
  templateUrl: './score-card.component.html',
  styleUrls: ['./score-card.component.css']
})
export class ScoreCardComponent implements OnInit, OnChanges {

  @Input() scoreCardID: any;
  private scoreCardUrl = AppSettings.SCORE_CARD_URL;
  // private scoreCardUrl = "https://esb2ui.esb2-dev.devtecc.uscis.dhs.gov/vibe-plus/rest/SCORE/scorecard";
  scoreCard: ScoreCard;
  scRecords: ScoreCardRecordEntity[];

  constructor(private http: HttpClient, private scoreCardService: ScoreCardService) {
  }
  

  ngOnChanges(changes: SimpleChanges) {
    if (this.scoreCardID)

    this.getScoreCardById(this.scoreCardID);
  }

  ngOnInit() {
    if (this.scoreCardID)
      this.getScoreCardById(this.scoreCardID);
      
    else
      this.getScoreCardById("1253120");// to be used only in DEV environment for debugging, otherwise set the value to null.
  }


    
  private getScoreCardById(scoreCardId: any) {
    const url = `${this.scoreCardUrl}/${scoreCardId}`;
    // console.log("the card url is: " + url);
    // const url = `/vibe-plus/rest/score/scorecard/1253100`;
    this.scoreCardService.getCards(url).subscribe(data => {    

      if (data != null) {
        this.scoreCard = data;
      this.scRecords = this.scoreCard.ScoreCardGetResponse.ScoreCardResultSet.ScoreCardRecord;
      this.scRecords.forEach(element => {
        if((element.BusinessRuleName==="Legal Status Code") )
        this.scRecords.splice(this.scRecords.indexOf(element),1);  
      });

      this.scRecords.forEach(element => {
        if(element.BusinessRuleName==="Foreign Affiliate Indicator" && element.Score==="N/A")             
      this.scRecords.splice(this.scRecords.indexOf(element),1); 
      });
      }
    });
  }

  private getStartTimeStyle(ScoreCodeType): any {
    switch (ScoreCodeType) {
      case 'GREEN':
        return { color: 'white', 'background-color': 'green', 'font-weight': 'bold' };
      case 'RED':
        return { 'background-color': 'red', 'font-weight': 'bold' };
      case 'ORANGE':
        return { 'background-color': 'orange', 'font-weight': 'bold' };
      case 'YELLOW':
        return { 'background-color': 'yellow', 'font-weight': 'bold' };
      case 'BLUE':
        return { 'background-color': 'blue', 'font-weight': 'bold' };
      default:
        return {};
    }
  }
}
