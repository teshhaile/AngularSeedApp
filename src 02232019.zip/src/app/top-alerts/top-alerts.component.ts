import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-top-alerts',
  templateUrl: './top-alerts.component.html',
  styleUrls: ['./top-alerts.component.css']
})
export class TopAlertsComponent implements OnInit {

  @Input() topLevelAlert:string = "";
  constructor() { 
    //this.topLevelAlert = "System is going down"; 
  }
 
  ngOnInit() {
  }

 
}
