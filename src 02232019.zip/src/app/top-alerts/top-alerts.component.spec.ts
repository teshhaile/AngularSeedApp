import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopAlertsComponent } from './top-alerts.component';

describe('TopAlertsComponent', () => {
  let component: TopAlertsComponent;
  let fixture: ComponentFixture<TopAlertsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopAlertsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopAlertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
